
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00008117          	auipc	sp,0x8
    80000004:	93010113          	addi	sp,sp,-1744 # 80007930 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	04a000ef          	jal	80000060 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000022:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000026:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002a:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    8000002e:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000032:	577d                	li	a4,-1
    80000034:	177e                	slli	a4,a4,0x3f
    80000036:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80000038:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003c:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000040:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000044:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    80000048:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004c:	000f4737          	lui	a4,0xf4
    80000050:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000054:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000056:	14d79073          	csrw	stimecmp,a5
}
    8000005a:	6422                	ld	s0,8(sp)
    8000005c:	0141                	addi	sp,sp,16
    8000005e:	8082                	ret

0000000080000060 <start>:
{
    80000060:	1141                	addi	sp,sp,-16
    80000062:	e406                	sd	ra,8(sp)
    80000064:	e022                	sd	s0,0(sp)
    80000066:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000068:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    8000006c:	7779                	lui	a4,0xffffe
    8000006e:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffddbc7>
    80000072:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000074:	6705                	lui	a4,0x1
    80000076:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    8000007c:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000080:	00001797          	auipc	a5,0x1
    80000084:	dfe78793          	addi	a5,a5,-514 # 80000e7e <main>
    80000088:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    8000008c:	4781                	li	a5,0
    8000008e:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000092:	67c1                	lui	a5,0x10
    80000094:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80000096:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009a:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    8000009e:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a2:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000a6:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000aa:	57fd                	li	a5,-1
    800000ac:	83a9                	srli	a5,a5,0xa
    800000ae:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b2:	47bd                	li	a5,15
    800000b4:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000b8:	f65ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000bc:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c0:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c2:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c4:	30200073          	mret
}
    800000c8:	60a2                	ld	ra,8(sp)
    800000ca:	6402                	ld	s0,0(sp)
    800000cc:	0141                	addi	sp,sp,16
    800000ce:	8082                	ret

00000000800000d0 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d0:	7119                	addi	sp,sp,-128
    800000d2:	fc86                	sd	ra,120(sp)
    800000d4:	f8a2                	sd	s0,112(sp)
    800000d6:	f4a6                	sd	s1,104(sp)
    800000d8:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while(i < n){
    800000da:	06c05a63          	blez	a2,8000014e <consolewrite+0x7e>
    800000de:	f0ca                	sd	s2,96(sp)
    800000e0:	ecce                	sd	s3,88(sp)
    800000e2:	e8d2                	sd	s4,80(sp)
    800000e4:	e4d6                	sd	s5,72(sp)
    800000e6:	e0da                	sd	s6,64(sp)
    800000e8:	fc5e                	sd	s7,56(sp)
    800000ea:	f862                	sd	s8,48(sp)
    800000ec:	f466                	sd	s9,40(sp)
    800000ee:	8aaa                	mv	s5,a0
    800000f0:	8b2e                	mv	s6,a1
    800000f2:	8a32                	mv	s4,a2
  int i = 0;
    800000f4:	4481                	li	s1,0
    int nn = sizeof(buf);
    if(nn > n - i)
    800000f6:	02000c13          	li	s8,32
    800000fa:	02000c93          	li	s9,32
      nn = n - i;
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    800000fe:	5bfd                	li	s7,-1
    80000100:	a035                	j	8000012c <consolewrite+0x5c>
    if(nn > n - i)
    80000102:	0009099b          	sext.w	s3,s2
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000106:	86ce                	mv	a3,s3
    80000108:	01648633          	add	a2,s1,s6
    8000010c:	85d6                	mv	a1,s5
    8000010e:	f8040513          	addi	a0,s0,-128
    80000112:	1b2020ef          	jal	800022c4 <either_copyin>
    80000116:	03750e63          	beq	a0,s7,80000152 <consolewrite+0x82>
      break;
    uartwrite(buf, nn);
    8000011a:	85ce                	mv	a1,s3
    8000011c:	f8040513          	addi	a0,s0,-128
    80000120:	778000ef          	jal	80000898 <uartwrite>
    i += nn;
    80000124:	009904bb          	addw	s1,s2,s1
  while(i < n){
    80000128:	0144da63          	bge	s1,s4,8000013c <consolewrite+0x6c>
    if(nn > n - i)
    8000012c:	409a093b          	subw	s2,s4,s1
    80000130:	0009079b          	sext.w	a5,s2
    80000134:	fcfc57e3          	bge	s8,a5,80000102 <consolewrite+0x32>
    80000138:	8966                	mv	s2,s9
    8000013a:	b7e1                	j	80000102 <consolewrite+0x32>
    8000013c:	7906                	ld	s2,96(sp)
    8000013e:	69e6                	ld	s3,88(sp)
    80000140:	6a46                	ld	s4,80(sp)
    80000142:	6aa6                	ld	s5,72(sp)
    80000144:	6b06                	ld	s6,64(sp)
    80000146:	7be2                	ld	s7,56(sp)
    80000148:	7c42                	ld	s8,48(sp)
    8000014a:	7ca2                	ld	s9,40(sp)
    8000014c:	a819                	j	80000162 <consolewrite+0x92>
  int i = 0;
    8000014e:	4481                	li	s1,0
    80000150:	a809                	j	80000162 <consolewrite+0x92>
    80000152:	7906                	ld	s2,96(sp)
    80000154:	69e6                	ld	s3,88(sp)
    80000156:	6a46                	ld	s4,80(sp)
    80000158:	6aa6                	ld	s5,72(sp)
    8000015a:	6b06                	ld	s6,64(sp)
    8000015c:	7be2                	ld	s7,56(sp)
    8000015e:	7c42                	ld	s8,48(sp)
    80000160:	7ca2                	ld	s9,40(sp)
  }

  return i;
}
    80000162:	8526                	mv	a0,s1
    80000164:	70e6                	ld	ra,120(sp)
    80000166:	7446                	ld	s0,112(sp)
    80000168:	74a6                	ld	s1,104(sp)
    8000016a:	6109                	addi	sp,sp,128
    8000016c:	8082                	ret

000000008000016e <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000016e:	711d                	addi	sp,sp,-96
    80000170:	ec86                	sd	ra,88(sp)
    80000172:	e8a2                	sd	s0,80(sp)
    80000174:	e4a6                	sd	s1,72(sp)
    80000176:	e0ca                	sd	s2,64(sp)
    80000178:	fc4e                	sd	s3,56(sp)
    8000017a:	f852                	sd	s4,48(sp)
    8000017c:	f456                	sd	s5,40(sp)
    8000017e:	f05a                	sd	s6,32(sp)
    80000180:	1080                	addi	s0,sp,96
    80000182:	8aaa                	mv	s5,a0
    80000184:	8a2e                	mv	s4,a1
    80000186:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000188:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    8000018c:	0000f517          	auipc	a0,0xf
    80000190:	7a450513          	addi	a0,a0,1956 # 8000f930 <cons>
    80000194:	27d000ef          	jal	80000c10 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80000198:	0000f497          	auipc	s1,0xf
    8000019c:	79848493          	addi	s1,s1,1944 # 8000f930 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a0:	00010917          	auipc	s2,0x10
    800001a4:	82890913          	addi	s2,s2,-2008 # 8000f9c8 <cons+0x98>
  while(n > 0){
    800001a8:	0b305d63          	blez	s3,80000262 <consoleread+0xf4>
    while(cons.r == cons.w){
    800001ac:	0984a783          	lw	a5,152(s1)
    800001b0:	09c4a703          	lw	a4,156(s1)
    800001b4:	0af71263          	bne	a4,a5,80000258 <consoleread+0xea>
      if(killed(myproc())){
    800001b8:	758010ef          	jal	80001910 <myproc>
    800001bc:	79b010ef          	jal	80002156 <killed>
    800001c0:	e12d                	bnez	a0,80000222 <consoleread+0xb4>
      sleep(&cons.r, &cons.lock);
    800001c2:	85a6                	mv	a1,s1
    800001c4:	854a                	mv	a0,s2
    800001c6:	559010ef          	jal	80001f1e <sleep>
    while(cons.r == cons.w){
    800001ca:	0984a783          	lw	a5,152(s1)
    800001ce:	09c4a703          	lw	a4,156(s1)
    800001d2:	fef703e3          	beq	a4,a5,800001b8 <consoleread+0x4a>
    800001d6:	ec5e                	sd	s7,24(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001d8:	0000f717          	auipc	a4,0xf
    800001dc:	75870713          	addi	a4,a4,1880 # 8000f930 <cons>
    800001e0:	0017869b          	addiw	a3,a5,1
    800001e4:	08d72c23          	sw	a3,152(a4)
    800001e8:	07f7f693          	andi	a3,a5,127
    800001ec:	9736                	add	a4,a4,a3
    800001ee:	01874703          	lbu	a4,24(a4)
    800001f2:	00070b9b          	sext.w	s7,a4

    if(c == C('D')){  // end-of-file
    800001f6:	4691                	li	a3,4
    800001f8:	04db8663          	beq	s7,a3,80000244 <consoleread+0xd6>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    800001fc:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000200:	4685                	li	a3,1
    80000202:	faf40613          	addi	a2,s0,-81
    80000206:	85d2                	mv	a1,s4
    80000208:	8556                	mv	a0,s5
    8000020a:	070020ef          	jal	8000227a <either_copyout>
    8000020e:	57fd                	li	a5,-1
    80000210:	04f50863          	beq	a0,a5,80000260 <consoleread+0xf2>
      break;

    dst++;
    80000214:	0a05                	addi	s4,s4,1
    --n;
    80000216:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    80000218:	47a9                	li	a5,10
    8000021a:	04fb8d63          	beq	s7,a5,80000274 <consoleread+0x106>
    8000021e:	6be2                	ld	s7,24(sp)
    80000220:	b761                	j	800001a8 <consoleread+0x3a>
        release(&cons.lock);
    80000222:	0000f517          	auipc	a0,0xf
    80000226:	70e50513          	addi	a0,a0,1806 # 8000f930 <cons>
    8000022a:	27f000ef          	jal	80000ca8 <release>
        return -1;
    8000022e:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000230:	60e6                	ld	ra,88(sp)
    80000232:	6446                	ld	s0,80(sp)
    80000234:	64a6                	ld	s1,72(sp)
    80000236:	6906                	ld	s2,64(sp)
    80000238:	79e2                	ld	s3,56(sp)
    8000023a:	7a42                	ld	s4,48(sp)
    8000023c:	7aa2                	ld	s5,40(sp)
    8000023e:	7b02                	ld	s6,32(sp)
    80000240:	6125                	addi	sp,sp,96
    80000242:	8082                	ret
      if(n < target){
    80000244:	0009871b          	sext.w	a4,s3
    80000248:	01677a63          	bgeu	a4,s6,8000025c <consoleread+0xee>
        cons.r--;
    8000024c:	0000f717          	auipc	a4,0xf
    80000250:	76f72e23          	sw	a5,1916(a4) # 8000f9c8 <cons+0x98>
    80000254:	6be2                	ld	s7,24(sp)
    80000256:	a031                	j	80000262 <consoleread+0xf4>
    80000258:	ec5e                	sd	s7,24(sp)
    8000025a:	bfbd                	j	800001d8 <consoleread+0x6a>
    8000025c:	6be2                	ld	s7,24(sp)
    8000025e:	a011                	j	80000262 <consoleread+0xf4>
    80000260:	6be2                	ld	s7,24(sp)
  release(&cons.lock);
    80000262:	0000f517          	auipc	a0,0xf
    80000266:	6ce50513          	addi	a0,a0,1742 # 8000f930 <cons>
    8000026a:	23f000ef          	jal	80000ca8 <release>
  return target - n;
    8000026e:	413b053b          	subw	a0,s6,s3
    80000272:	bf7d                	j	80000230 <consoleread+0xc2>
    80000274:	6be2                	ld	s7,24(sp)
    80000276:	b7f5                	j	80000262 <consoleread+0xf4>

0000000080000278 <consputc>:
{
    80000278:	1141                	addi	sp,sp,-16
    8000027a:	e406                	sd	ra,8(sp)
    8000027c:	e022                	sd	s0,0(sp)
    8000027e:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000280:	10000793          	li	a5,256
    80000284:	00f50863          	beq	a0,a5,80000294 <consputc+0x1c>
    uartputc_sync(c);
    80000288:	6a4000ef          	jal	8000092c <uartputc_sync>
}
    8000028c:	60a2                	ld	ra,8(sp)
    8000028e:	6402                	ld	s0,0(sp)
    80000290:	0141                	addi	sp,sp,16
    80000292:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000294:	4521                	li	a0,8
    80000296:	696000ef          	jal	8000092c <uartputc_sync>
    8000029a:	02000513          	li	a0,32
    8000029e:	68e000ef          	jal	8000092c <uartputc_sync>
    800002a2:	4521                	li	a0,8
    800002a4:	688000ef          	jal	8000092c <uartputc_sync>
    800002a8:	b7d5                	j	8000028c <consputc+0x14>

00000000800002aa <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002aa:	1101                	addi	sp,sp,-32
    800002ac:	ec06                	sd	ra,24(sp)
    800002ae:	e822                	sd	s0,16(sp)
    800002b0:	e426                	sd	s1,8(sp)
    800002b2:	1000                	addi	s0,sp,32
    800002b4:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002b6:	0000f517          	auipc	a0,0xf
    800002ba:	67a50513          	addi	a0,a0,1658 # 8000f930 <cons>
    800002be:	153000ef          	jal	80000c10 <acquire>

  switch(c){
    800002c2:	47d5                	li	a5,21
    800002c4:	08f48f63          	beq	s1,a5,80000362 <consoleintr+0xb8>
    800002c8:	0297c563          	blt	a5,s1,800002f2 <consoleintr+0x48>
    800002cc:	47a1                	li	a5,8
    800002ce:	0ef48463          	beq	s1,a5,800003b6 <consoleintr+0x10c>
    800002d2:	47c1                	li	a5,16
    800002d4:	10f49563          	bne	s1,a5,800003de <consoleintr+0x134>
  case C('P'):  // Print process list.
    procdump();
    800002d8:	036020ef          	jal	8000230e <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002dc:	0000f517          	auipc	a0,0xf
    800002e0:	65450513          	addi	a0,a0,1620 # 8000f930 <cons>
    800002e4:	1c5000ef          	jal	80000ca8 <release>
}
    800002e8:	60e2                	ld	ra,24(sp)
    800002ea:	6442                	ld	s0,16(sp)
    800002ec:	64a2                	ld	s1,8(sp)
    800002ee:	6105                	addi	sp,sp,32
    800002f0:	8082                	ret
  switch(c){
    800002f2:	07f00793          	li	a5,127
    800002f6:	0cf48063          	beq	s1,a5,800003b6 <consoleintr+0x10c>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002fa:	0000f717          	auipc	a4,0xf
    800002fe:	63670713          	addi	a4,a4,1590 # 8000f930 <cons>
    80000302:	0a072783          	lw	a5,160(a4)
    80000306:	09872703          	lw	a4,152(a4)
    8000030a:	9f99                	subw	a5,a5,a4
    8000030c:	07f00713          	li	a4,127
    80000310:	fcf766e3          	bltu	a4,a5,800002dc <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000314:	47b5                	li	a5,13
    80000316:	0cf48763          	beq	s1,a5,800003e4 <consoleintr+0x13a>
      consputc(c);
    8000031a:	8526                	mv	a0,s1
    8000031c:	f5dff0ef          	jal	80000278 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000320:	0000f797          	auipc	a5,0xf
    80000324:	61078793          	addi	a5,a5,1552 # 8000f930 <cons>
    80000328:	0a07a683          	lw	a3,160(a5)
    8000032c:	0016871b          	addiw	a4,a3,1
    80000330:	0007061b          	sext.w	a2,a4
    80000334:	0ae7a023          	sw	a4,160(a5)
    80000338:	07f6f693          	andi	a3,a3,127
    8000033c:	97b6                	add	a5,a5,a3
    8000033e:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000342:	47a9                	li	a5,10
    80000344:	0cf48563          	beq	s1,a5,8000040e <consoleintr+0x164>
    80000348:	4791                	li	a5,4
    8000034a:	0cf48263          	beq	s1,a5,8000040e <consoleintr+0x164>
    8000034e:	0000f797          	auipc	a5,0xf
    80000352:	67a7a783          	lw	a5,1658(a5) # 8000f9c8 <cons+0x98>
    80000356:	9f1d                	subw	a4,a4,a5
    80000358:	08000793          	li	a5,128
    8000035c:	f8f710e3          	bne	a4,a5,800002dc <consoleintr+0x32>
    80000360:	a07d                	j	8000040e <consoleintr+0x164>
    80000362:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80000364:	0000f717          	auipc	a4,0xf
    80000368:	5cc70713          	addi	a4,a4,1484 # 8000f930 <cons>
    8000036c:	0a072783          	lw	a5,160(a4)
    80000370:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000374:	0000f497          	auipc	s1,0xf
    80000378:	5bc48493          	addi	s1,s1,1468 # 8000f930 <cons>
    while(cons.e != cons.w &&
    8000037c:	4929                	li	s2,10
    8000037e:	02f70863          	beq	a4,a5,800003ae <consoleintr+0x104>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000382:	37fd                	addiw	a5,a5,-1
    80000384:	07f7f713          	andi	a4,a5,127
    80000388:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000038a:	01874703          	lbu	a4,24(a4)
    8000038e:	03270263          	beq	a4,s2,800003b2 <consoleintr+0x108>
      cons.e--;
    80000392:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000396:	10000513          	li	a0,256
    8000039a:	edfff0ef          	jal	80000278 <consputc>
    while(cons.e != cons.w &&
    8000039e:	0a04a783          	lw	a5,160(s1)
    800003a2:	09c4a703          	lw	a4,156(s1)
    800003a6:	fcf71ee3          	bne	a4,a5,80000382 <consoleintr+0xd8>
    800003aa:	6902                	ld	s2,0(sp)
    800003ac:	bf05                	j	800002dc <consoleintr+0x32>
    800003ae:	6902                	ld	s2,0(sp)
    800003b0:	b735                	j	800002dc <consoleintr+0x32>
    800003b2:	6902                	ld	s2,0(sp)
    800003b4:	b725                	j	800002dc <consoleintr+0x32>
    if(cons.e != cons.w){
    800003b6:	0000f717          	auipc	a4,0xf
    800003ba:	57a70713          	addi	a4,a4,1402 # 8000f930 <cons>
    800003be:	0a072783          	lw	a5,160(a4)
    800003c2:	09c72703          	lw	a4,156(a4)
    800003c6:	f0f70be3          	beq	a4,a5,800002dc <consoleintr+0x32>
      cons.e--;
    800003ca:	37fd                	addiw	a5,a5,-1
    800003cc:	0000f717          	auipc	a4,0xf
    800003d0:	60f72223          	sw	a5,1540(a4) # 8000f9d0 <cons+0xa0>
      consputc(BACKSPACE);
    800003d4:	10000513          	li	a0,256
    800003d8:	ea1ff0ef          	jal	80000278 <consputc>
    800003dc:	b701                	j	800002dc <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003de:	ee048fe3          	beqz	s1,800002dc <consoleintr+0x32>
    800003e2:	bf21                	j	800002fa <consoleintr+0x50>
      consputc(c);
    800003e4:	4529                	li	a0,10
    800003e6:	e93ff0ef          	jal	80000278 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003ea:	0000f797          	auipc	a5,0xf
    800003ee:	54678793          	addi	a5,a5,1350 # 8000f930 <cons>
    800003f2:	0a07a703          	lw	a4,160(a5)
    800003f6:	0017069b          	addiw	a3,a4,1
    800003fa:	0006861b          	sext.w	a2,a3
    800003fe:	0ad7a023          	sw	a3,160(a5)
    80000402:	07f77713          	andi	a4,a4,127
    80000406:	97ba                	add	a5,a5,a4
    80000408:	4729                	li	a4,10
    8000040a:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000040e:	0000f797          	auipc	a5,0xf
    80000412:	5ac7af23          	sw	a2,1470(a5) # 8000f9cc <cons+0x9c>
        wakeup(&cons.r);
    80000416:	0000f517          	auipc	a0,0xf
    8000041a:	5b250513          	addi	a0,a0,1458 # 8000f9c8 <cons+0x98>
    8000041e:	34d010ef          	jal	80001f6a <wakeup>
    80000422:	bd6d                	j	800002dc <consoleintr+0x32>

0000000080000424 <consoleinit>:

void
consoleinit(void)
{
    80000424:	1141                	addi	sp,sp,-16
    80000426:	e406                	sd	ra,8(sp)
    80000428:	e022                	sd	s0,0(sp)
    8000042a:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    8000042c:	00007597          	auipc	a1,0x7
    80000430:	bd458593          	addi	a1,a1,-1068 # 80007000 <etext>
    80000434:	0000f517          	auipc	a0,0xf
    80000438:	4fc50513          	addi	a0,a0,1276 # 8000f930 <cons>
    8000043c:	754000ef          	jal	80000b90 <initlock>

  uartinit();
    80000440:	400000ef          	jal	80000840 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000444:	0001f797          	auipc	a5,0x1f
    80000448:	65c78793          	addi	a5,a5,1628 # 8001faa0 <devsw>
    8000044c:	00000717          	auipc	a4,0x0
    80000450:	d2270713          	addi	a4,a4,-734 # 8000016e <consoleread>
    80000454:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000456:	00000717          	auipc	a4,0x0
    8000045a:	c7a70713          	addi	a4,a4,-902 # 800000d0 <consolewrite>
    8000045e:	ef98                	sd	a4,24(a5)
}
    80000460:	60a2                	ld	ra,8(sp)
    80000462:	6402                	ld	s0,0(sp)
    80000464:	0141                	addi	sp,sp,16
    80000466:	8082                	ret

0000000080000468 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000468:	7139                	addi	sp,sp,-64
    8000046a:	fc06                	sd	ra,56(sp)
    8000046c:	f822                	sd	s0,48(sp)
    8000046e:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80000470:	c219                	beqz	a2,80000476 <printint+0xe>
    80000472:	08054063          	bltz	a0,800004f2 <printint+0x8a>
    x = -xx;
  else
    x = xx;
    80000476:	4881                	li	a7,0
    80000478:	fc840693          	addi	a3,s0,-56

  i = 0;
    8000047c:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    8000047e:	00007617          	auipc	a2,0x7
    80000482:	30260613          	addi	a2,a2,770 # 80007780 <digits>
    80000486:	883e                	mv	a6,a5
    80000488:	2785                	addiw	a5,a5,1
    8000048a:	02b57733          	remu	a4,a0,a1
    8000048e:	9732                	add	a4,a4,a2
    80000490:	00074703          	lbu	a4,0(a4)
    80000494:	00e68023          	sb	a4,0(a3)
  } while((x /= base) != 0);
    80000498:	872a                	mv	a4,a0
    8000049a:	02b55533          	divu	a0,a0,a1
    8000049e:	0685                	addi	a3,a3,1
    800004a0:	feb773e3          	bgeu	a4,a1,80000486 <printint+0x1e>

  if(sign)
    800004a4:	00088a63          	beqz	a7,800004b8 <printint+0x50>
    buf[i++] = '-';
    800004a8:	1781                	addi	a5,a5,-32
    800004aa:	97a2                	add	a5,a5,s0
    800004ac:	02d00713          	li	a4,45
    800004b0:	fee78423          	sb	a4,-24(a5)
    800004b4:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
    800004b8:	02f05963          	blez	a5,800004ea <printint+0x82>
    800004bc:	f426                	sd	s1,40(sp)
    800004be:	f04a                	sd	s2,32(sp)
    800004c0:	fc840713          	addi	a4,s0,-56
    800004c4:	00f704b3          	add	s1,a4,a5
    800004c8:	fff70913          	addi	s2,a4,-1
    800004cc:	993e                	add	s2,s2,a5
    800004ce:	37fd                	addiw	a5,a5,-1
    800004d0:	1782                	slli	a5,a5,0x20
    800004d2:	9381                	srli	a5,a5,0x20
    800004d4:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    800004d8:	fff4c503          	lbu	a0,-1(s1)
    800004dc:	d9dff0ef          	jal	80000278 <consputc>
  while(--i >= 0)
    800004e0:	14fd                	addi	s1,s1,-1
    800004e2:	ff249be3          	bne	s1,s2,800004d8 <printint+0x70>
    800004e6:	74a2                	ld	s1,40(sp)
    800004e8:	7902                	ld	s2,32(sp)
}
    800004ea:	70e2                	ld	ra,56(sp)
    800004ec:	7442                	ld	s0,48(sp)
    800004ee:	6121                	addi	sp,sp,64
    800004f0:	8082                	ret
    x = -xx;
    800004f2:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004f6:	4885                	li	a7,1
    x = -xx;
    800004f8:	b741                	j	80000478 <printint+0x10>

00000000800004fa <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004fa:	7131                	addi	sp,sp,-192
    800004fc:	fc86                	sd	ra,120(sp)
    800004fe:	f8a2                	sd	s0,112(sp)
    80000500:	e8d2                	sd	s4,80(sp)
    80000502:	0100                	addi	s0,sp,128
    80000504:	8a2a                	mv	s4,a0
    80000506:	e40c                	sd	a1,8(s0)
    80000508:	e810                	sd	a2,16(s0)
    8000050a:	ec14                	sd	a3,24(s0)
    8000050c:	f018                	sd	a4,32(s0)
    8000050e:	f41c                	sd	a5,40(s0)
    80000510:	03043823          	sd	a6,48(s0)
    80000514:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    80000518:	00007797          	auipc	a5,0x7
    8000051c:	3ec7a783          	lw	a5,1004(a5) # 80007904 <panicking>
    80000520:	c3a1                	beqz	a5,80000560 <printf+0x66>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000522:	00840793          	addi	a5,s0,8
    80000526:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000052a:	000a4503          	lbu	a0,0(s4)
    8000052e:	28050763          	beqz	a0,800007bc <printf+0x2c2>
    80000532:	f4a6                	sd	s1,104(sp)
    80000534:	f0ca                	sd	s2,96(sp)
    80000536:	ecce                	sd	s3,88(sp)
    80000538:	e4d6                	sd	s5,72(sp)
    8000053a:	e0da                	sd	s6,64(sp)
    8000053c:	f862                	sd	s8,48(sp)
    8000053e:	f466                	sd	s9,40(sp)
    80000540:	f06a                	sd	s10,32(sp)
    80000542:	ec6e                	sd	s11,24(sp)
    80000544:	4981                	li	s3,0
    if(cx != '%'){
    80000546:	02500a93          	li	s5,37
    i++;
    c0 = fmt[i+0] & 0xff;
    c1 = c2 = 0;
    if(c0) c1 = fmt[i+1] & 0xff;
    if(c1) c2 = fmt[i+2] & 0xff;
    if(c0 == 'd'){
    8000054a:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if(c0 == 'l' && c1 == 'd'){
    8000054e:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    80000552:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80000556:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    8000055a:	07000d93          	li	s11,112
    8000055e:	a01d                	j	80000584 <printf+0x8a>
    acquire(&pr.lock);
    80000560:	0000f517          	auipc	a0,0xf
    80000564:	47850513          	addi	a0,a0,1144 # 8000f9d8 <pr>
    80000568:	6a8000ef          	jal	80000c10 <acquire>
    8000056c:	bf5d                	j	80000522 <printf+0x28>
      consputc(cx);
    8000056e:	d0bff0ef          	jal	80000278 <consputc>
      continue;
    80000572:	84ce                	mv	s1,s3
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000574:	0014899b          	addiw	s3,s1,1
    80000578:	013a07b3          	add	a5,s4,s3
    8000057c:	0007c503          	lbu	a0,0(a5)
    80000580:	20050b63          	beqz	a0,80000796 <printf+0x29c>
    if(cx != '%'){
    80000584:	ff5515e3          	bne	a0,s5,8000056e <printf+0x74>
    i++;
    80000588:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i+0] & 0xff;
    8000058c:	009a07b3          	add	a5,s4,s1
    80000590:	0007c903          	lbu	s2,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000594:	20090b63          	beqz	s2,800007aa <printf+0x2b0>
    80000598:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    8000059c:	86be                	mv	a3,a5
    if(c1) c2 = fmt[i+2] & 0xff;
    8000059e:	c789                	beqz	a5,800005a8 <printf+0xae>
    800005a0:	009a0733          	add	a4,s4,s1
    800005a4:	00274683          	lbu	a3,2(a4)
    if(c0 == 'd'){
    800005a8:	03690963          	beq	s2,s6,800005da <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    800005ac:	05890363          	beq	s2,s8,800005f2 <printf+0xf8>
    } else if(c0 == 'u'){
    800005b0:	0d990663          	beq	s2,s9,8000067c <printf+0x182>
    } else if(c0 == 'x'){
    800005b4:	11a90d63          	beq	s2,s10,800006ce <printf+0x1d4>
    } else if(c0 == 'p'){
    800005b8:	15b90663          	beq	s2,s11,80000704 <printf+0x20a>
      printptr(va_arg(ap, uint64));
    } else if(c0 == 'c'){
    800005bc:	06300793          	li	a5,99
    800005c0:	18f90563          	beq	s2,a5,8000074a <printf+0x250>
      consputc(va_arg(ap, uint));
    } else if(c0 == 's'){
    800005c4:	07300793          	li	a5,115
    800005c8:	18f90b63          	beq	s2,a5,8000075e <printf+0x264>
      if((s = va_arg(ap, char*)) == 0)
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
    } else if(c0 == '%'){
    800005cc:	03591b63          	bne	s2,s5,80000602 <printf+0x108>
      consputc('%');
    800005d0:	02500513          	li	a0,37
    800005d4:	ca5ff0ef          	jal	80000278 <consputc>
    800005d8:	bf71                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, int), 10, 1);
    800005da:	f8843783          	ld	a5,-120(s0)
    800005de:	00878713          	addi	a4,a5,8
    800005e2:	f8e43423          	sd	a4,-120(s0)
    800005e6:	4605                	li	a2,1
    800005e8:	45a9                	li	a1,10
    800005ea:	4388                	lw	a0,0(a5)
    800005ec:	e7dff0ef          	jal	80000468 <printint>
    800005f0:	b751                	j	80000574 <printf+0x7a>
    } else if(c0 == 'l' && c1 == 'd'){
    800005f2:	01678f63          	beq	a5,s6,80000610 <printf+0x116>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800005f6:	03878b63          	beq	a5,s8,8000062c <printf+0x132>
    } else if(c0 == 'l' && c1 == 'u'){
    800005fa:	09978e63          	beq	a5,s9,80000696 <printf+0x19c>
    } else if(c0 == 'l' && c1 == 'x'){
    800005fe:	0fa78563          	beq	a5,s10,800006e8 <printf+0x1ee>
    } else if(c0 == 0){
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    80000602:	8556                	mv	a0,s5
    80000604:	c75ff0ef          	jal	80000278 <consputc>
      consputc(c0);
    80000608:	854a                	mv	a0,s2
    8000060a:	c6fff0ef          	jal	80000278 <consputc>
    8000060e:	b79d                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000610:	f8843783          	ld	a5,-120(s0)
    80000614:	00878713          	addi	a4,a5,8
    80000618:	f8e43423          	sd	a4,-120(s0)
    8000061c:	4605                	li	a2,1
    8000061e:	45a9                	li	a1,10
    80000620:	6388                	ld	a0,0(a5)
    80000622:	e47ff0ef          	jal	80000468 <printint>
      i += 1;
    80000626:	0029849b          	addiw	s1,s3,2
    8000062a:	b7a9                	j	80000574 <printf+0x7a>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000062c:	06400793          	li	a5,100
    80000630:	02f68863          	beq	a3,a5,80000660 <printf+0x166>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80000634:	07500793          	li	a5,117
    80000638:	06f68d63          	beq	a3,a5,800006b2 <printf+0x1b8>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    8000063c:	07800793          	li	a5,120
    80000640:	fcf691e3          	bne	a3,a5,80000602 <printf+0x108>
      printint(va_arg(ap, uint64), 16, 0);
    80000644:	f8843783          	ld	a5,-120(s0)
    80000648:	00878713          	addi	a4,a5,8
    8000064c:	f8e43423          	sd	a4,-120(s0)
    80000650:	4601                	li	a2,0
    80000652:	45c1                	li	a1,16
    80000654:	6388                	ld	a0,0(a5)
    80000656:	e13ff0ef          	jal	80000468 <printint>
      i += 2;
    8000065a:	0039849b          	addiw	s1,s3,3
    8000065e:	bf19                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000660:	f8843783          	ld	a5,-120(s0)
    80000664:	00878713          	addi	a4,a5,8
    80000668:	f8e43423          	sd	a4,-120(s0)
    8000066c:	4605                	li	a2,1
    8000066e:	45a9                	li	a1,10
    80000670:	6388                	ld	a0,0(a5)
    80000672:	df7ff0ef          	jal	80000468 <printint>
      i += 2;
    80000676:	0039849b          	addiw	s1,s3,3
    8000067a:	bded                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint32), 10, 0);
    8000067c:	f8843783          	ld	a5,-120(s0)
    80000680:	00878713          	addi	a4,a5,8
    80000684:	f8e43423          	sd	a4,-120(s0)
    80000688:	4601                	li	a2,0
    8000068a:	45a9                	li	a1,10
    8000068c:	0007e503          	lwu	a0,0(a5)
    80000690:	dd9ff0ef          	jal	80000468 <printint>
    80000694:	b5c5                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    80000696:	f8843783          	ld	a5,-120(s0)
    8000069a:	00878713          	addi	a4,a5,8
    8000069e:	f8e43423          	sd	a4,-120(s0)
    800006a2:	4601                	li	a2,0
    800006a4:	45a9                	li	a1,10
    800006a6:	6388                	ld	a0,0(a5)
    800006a8:	dc1ff0ef          	jal	80000468 <printint>
      i += 1;
    800006ac:	0029849b          	addiw	s1,s3,2
    800006b0:	b5d1                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    800006b2:	f8843783          	ld	a5,-120(s0)
    800006b6:	00878713          	addi	a4,a5,8
    800006ba:	f8e43423          	sd	a4,-120(s0)
    800006be:	4601                	li	a2,0
    800006c0:	45a9                	li	a1,10
    800006c2:	6388                	ld	a0,0(a5)
    800006c4:	da5ff0ef          	jal	80000468 <printint>
      i += 2;
    800006c8:	0039849b          	addiw	s1,s3,3
    800006cc:	b565                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint32), 16, 0);
    800006ce:	f8843783          	ld	a5,-120(s0)
    800006d2:	00878713          	addi	a4,a5,8
    800006d6:	f8e43423          	sd	a4,-120(s0)
    800006da:	4601                	li	a2,0
    800006dc:	45c1                	li	a1,16
    800006de:	0007e503          	lwu	a0,0(a5)
    800006e2:	d87ff0ef          	jal	80000468 <printint>
    800006e6:	b579                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 16, 0);
    800006e8:	f8843783          	ld	a5,-120(s0)
    800006ec:	00878713          	addi	a4,a5,8
    800006f0:	f8e43423          	sd	a4,-120(s0)
    800006f4:	4601                	li	a2,0
    800006f6:	45c1                	li	a1,16
    800006f8:	6388                	ld	a0,0(a5)
    800006fa:	d6fff0ef          	jal	80000468 <printint>
      i += 1;
    800006fe:	0029849b          	addiw	s1,s3,2
    80000702:	bd8d                	j	80000574 <printf+0x7a>
    80000704:	fc5e                	sd	s7,56(sp)
      printptr(va_arg(ap, uint64));
    80000706:	f8843783          	ld	a5,-120(s0)
    8000070a:	00878713          	addi	a4,a5,8
    8000070e:	f8e43423          	sd	a4,-120(s0)
    80000712:	0007b983          	ld	s3,0(a5)
  consputc('0');
    80000716:	03000513          	li	a0,48
    8000071a:	b5fff0ef          	jal	80000278 <consputc>
  consputc('x');
    8000071e:	07800513          	li	a0,120
    80000722:	b57ff0ef          	jal	80000278 <consputc>
    80000726:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000728:	00007b97          	auipc	s7,0x7
    8000072c:	058b8b93          	addi	s7,s7,88 # 80007780 <digits>
    80000730:	03c9d793          	srli	a5,s3,0x3c
    80000734:	97de                	add	a5,a5,s7
    80000736:	0007c503          	lbu	a0,0(a5)
    8000073a:	b3fff0ef          	jal	80000278 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    8000073e:	0992                	slli	s3,s3,0x4
    80000740:	397d                	addiw	s2,s2,-1
    80000742:	fe0917e3          	bnez	s2,80000730 <printf+0x236>
    80000746:	7be2                	ld	s7,56(sp)
    80000748:	b535                	j	80000574 <printf+0x7a>
      consputc(va_arg(ap, uint));
    8000074a:	f8843783          	ld	a5,-120(s0)
    8000074e:	00878713          	addi	a4,a5,8
    80000752:	f8e43423          	sd	a4,-120(s0)
    80000756:	4388                	lw	a0,0(a5)
    80000758:	b21ff0ef          	jal	80000278 <consputc>
    8000075c:	bd21                	j	80000574 <printf+0x7a>
      if((s = va_arg(ap, char*)) == 0)
    8000075e:	f8843783          	ld	a5,-120(s0)
    80000762:	00878713          	addi	a4,a5,8
    80000766:	f8e43423          	sd	a4,-120(s0)
    8000076a:	0007b903          	ld	s2,0(a5)
    8000076e:	00090d63          	beqz	s2,80000788 <printf+0x28e>
      for(; *s; s++)
    80000772:	00094503          	lbu	a0,0(s2)
    80000776:	de050fe3          	beqz	a0,80000574 <printf+0x7a>
        consputc(*s);
    8000077a:	affff0ef          	jal	80000278 <consputc>
      for(; *s; s++)
    8000077e:	0905                	addi	s2,s2,1
    80000780:	00094503          	lbu	a0,0(s2)
    80000784:	f97d                	bnez	a0,8000077a <printf+0x280>
    80000786:	b3fd                	j	80000574 <printf+0x7a>
        s = "(null)";
    80000788:	00007917          	auipc	s2,0x7
    8000078c:	88090913          	addi	s2,s2,-1920 # 80007008 <etext+0x8>
      for(; *s; s++)
    80000790:	02800513          	li	a0,40
    80000794:	b7dd                	j	8000077a <printf+0x280>
    80000796:	74a6                	ld	s1,104(sp)
    80000798:	7906                	ld	s2,96(sp)
    8000079a:	69e6                	ld	s3,88(sp)
    8000079c:	6aa6                	ld	s5,72(sp)
    8000079e:	6b06                	ld	s6,64(sp)
    800007a0:	7c42                	ld	s8,48(sp)
    800007a2:	7ca2                	ld	s9,40(sp)
    800007a4:	7d02                	ld	s10,32(sp)
    800007a6:	6de2                	ld	s11,24(sp)
    800007a8:	a811                	j	800007bc <printf+0x2c2>
    800007aa:	74a6                	ld	s1,104(sp)
    800007ac:	7906                	ld	s2,96(sp)
    800007ae:	69e6                	ld	s3,88(sp)
    800007b0:	6aa6                	ld	s5,72(sp)
    800007b2:	6b06                	ld	s6,64(sp)
    800007b4:	7c42                	ld	s8,48(sp)
    800007b6:	7ca2                	ld	s9,40(sp)
    800007b8:	7d02                	ld	s10,32(sp)
    800007ba:	6de2                	ld	s11,24(sp)
    }

  }
  va_end(ap);

  if(panicking == 0)
    800007bc:	00007797          	auipc	a5,0x7
    800007c0:	1487a783          	lw	a5,328(a5) # 80007904 <panicking>
    800007c4:	c799                	beqz	a5,800007d2 <printf+0x2d8>
    release(&pr.lock);

  return 0;
}
    800007c6:	4501                	li	a0,0
    800007c8:	70e6                	ld	ra,120(sp)
    800007ca:	7446                	ld	s0,112(sp)
    800007cc:	6a46                	ld	s4,80(sp)
    800007ce:	6129                	addi	sp,sp,192
    800007d0:	8082                	ret
    release(&pr.lock);
    800007d2:	0000f517          	auipc	a0,0xf
    800007d6:	20650513          	addi	a0,a0,518 # 8000f9d8 <pr>
    800007da:	4ce000ef          	jal	80000ca8 <release>
  return 0;
    800007de:	b7e5                	j	800007c6 <printf+0x2cc>

00000000800007e0 <panic>:

void
panic(char *s)
{
    800007e0:	1101                	addi	sp,sp,-32
    800007e2:	ec06                	sd	ra,24(sp)
    800007e4:	e822                	sd	s0,16(sp)
    800007e6:	e426                	sd	s1,8(sp)
    800007e8:	e04a                	sd	s2,0(sp)
    800007ea:	1000                	addi	s0,sp,32
    800007ec:	84aa                	mv	s1,a0
  panicking = 1;
    800007ee:	4905                	li	s2,1
    800007f0:	00007797          	auipc	a5,0x7
    800007f4:	1127aa23          	sw	s2,276(a5) # 80007904 <panicking>
  printf("panic: ");
    800007f8:	00007517          	auipc	a0,0x7
    800007fc:	82050513          	addi	a0,a0,-2016 # 80007018 <etext+0x18>
    80000800:	cfbff0ef          	jal	800004fa <printf>
  printf("%s\n", s);
    80000804:	85a6                	mv	a1,s1
    80000806:	00007517          	auipc	a0,0x7
    8000080a:	81a50513          	addi	a0,a0,-2022 # 80007020 <etext+0x20>
    8000080e:	cedff0ef          	jal	800004fa <printf>
  panicked = 1; // freeze uart output from other CPUs
    80000812:	00007797          	auipc	a5,0x7
    80000816:	0f27a723          	sw	s2,238(a5) # 80007900 <panicked>
  for(;;)
    8000081a:	a001                	j	8000081a <panic+0x3a>

000000008000081c <printfinit>:
    ;
}

void
printfinit(void)
{
    8000081c:	1141                	addi	sp,sp,-16
    8000081e:	e406                	sd	ra,8(sp)
    80000820:	e022                	sd	s0,0(sp)
    80000822:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000824:	00007597          	auipc	a1,0x7
    80000828:	80458593          	addi	a1,a1,-2044 # 80007028 <etext+0x28>
    8000082c:	0000f517          	auipc	a0,0xf
    80000830:	1ac50513          	addi	a0,a0,428 # 8000f9d8 <pr>
    80000834:	35c000ef          	jal	80000b90 <initlock>
}
    80000838:	60a2                	ld	ra,8(sp)
    8000083a:	6402                	ld	s0,0(sp)
    8000083c:	0141                	addi	sp,sp,16
    8000083e:	8082                	ret

0000000080000840 <uartinit>:
extern volatile int panicking; // from printf.c
extern volatile int panicked; // from printf.c

void
uartinit(void)
{
    80000840:	1141                	addi	sp,sp,-16
    80000842:	e406                	sd	ra,8(sp)
    80000844:	e022                	sd	s0,0(sp)
    80000846:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000848:	100007b7          	lui	a5,0x10000
    8000084c:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000850:	10000737          	lui	a4,0x10000
    80000854:	f8000693          	li	a3,-128
    80000858:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    8000085c:	468d                	li	a3,3
    8000085e:	10000637          	lui	a2,0x10000
    80000862:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80000866:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    8000086a:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    8000086e:	10000737          	lui	a4,0x10000
    80000872:	461d                	li	a2,7
    80000874:	00c70123          	sb	a2,2(a4) # 10000002 <_entry-0x6ffffffe>

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80000878:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    8000087c:	00006597          	auipc	a1,0x6
    80000880:	7b458593          	addi	a1,a1,1972 # 80007030 <etext+0x30>
    80000884:	0000f517          	auipc	a0,0xf
    80000888:	16c50513          	addi	a0,a0,364 # 8000f9f0 <tx_lock>
    8000088c:	304000ef          	jal	80000b90 <initlock>
}
    80000890:	60a2                	ld	ra,8(sp)
    80000892:	6402                	ld	s0,0(sp)
    80000894:	0141                	addi	sp,sp,16
    80000896:	8082                	ret

0000000080000898 <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    80000898:	715d                	addi	sp,sp,-80
    8000089a:	e486                	sd	ra,72(sp)
    8000089c:	e0a2                	sd	s0,64(sp)
    8000089e:	fc26                	sd	s1,56(sp)
    800008a0:	ec56                	sd	s5,24(sp)
    800008a2:	0880                	addi	s0,sp,80
    800008a4:	8aaa                	mv	s5,a0
    800008a6:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008a8:	0000f517          	auipc	a0,0xf
    800008ac:	14850513          	addi	a0,a0,328 # 8000f9f0 <tx_lock>
    800008b0:	360000ef          	jal	80000c10 <acquire>

  int i = 0;
  while(i < n){ 
    800008b4:	06905063          	blez	s1,80000914 <uartwrite+0x7c>
    800008b8:	f84a                	sd	s2,48(sp)
    800008ba:	f44e                	sd	s3,40(sp)
    800008bc:	f052                	sd	s4,32(sp)
    800008be:	e85a                	sd	s6,16(sp)
    800008c0:	e45e                	sd	s7,8(sp)
    800008c2:	8a56                	mv	s4,s5
    800008c4:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    800008c6:	00007497          	auipc	s1,0x7
    800008ca:	04648493          	addi	s1,s1,70 # 8000790c <tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    800008ce:	0000f997          	auipc	s3,0xf
    800008d2:	12298993          	addi	s3,s3,290 # 8000f9f0 <tx_lock>
    800008d6:	00007917          	auipc	s2,0x7
    800008da:	03290913          	addi	s2,s2,50 # 80007908 <tx_chan>
    }   
      
    WriteReg(THR, buf[i]);
    800008de:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    800008e2:	4b05                	li	s6,1
    800008e4:	a005                	j	80000904 <uartwrite+0x6c>
      sleep(&tx_chan, &tx_lock);
    800008e6:	85ce                	mv	a1,s3
    800008e8:	854a                	mv	a0,s2
    800008ea:	634010ef          	jal	80001f1e <sleep>
    while(tx_busy != 0){
    800008ee:	409c                	lw	a5,0(s1)
    800008f0:	fbfd                	bnez	a5,800008e6 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    800008f2:	000a4783          	lbu	a5,0(s4)
    800008f6:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    800008fa:	0164a023          	sw	s6,0(s1)
  while(i < n){ 
    800008fe:	0a05                	addi	s4,s4,1
    80000900:	015a0563          	beq	s4,s5,8000090a <uartwrite+0x72>
    while(tx_busy != 0){
    80000904:	409c                	lw	a5,0(s1)
    80000906:	f3e5                	bnez	a5,800008e6 <uartwrite+0x4e>
    80000908:	b7ed                	j	800008f2 <uartwrite+0x5a>
    8000090a:	7942                	ld	s2,48(sp)
    8000090c:	79a2                	ld	s3,40(sp)
    8000090e:	7a02                	ld	s4,32(sp)
    80000910:	6b42                	ld	s6,16(sp)
    80000912:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000914:	0000f517          	auipc	a0,0xf
    80000918:	0dc50513          	addi	a0,a0,220 # 8000f9f0 <tx_lock>
    8000091c:	38c000ef          	jal	80000ca8 <release>
}
    80000920:	60a6                	ld	ra,72(sp)
    80000922:	6406                	ld	s0,64(sp)
    80000924:	74e2                	ld	s1,56(sp)
    80000926:	6ae2                	ld	s5,24(sp)
    80000928:	6161                	addi	sp,sp,80
    8000092a:	8082                	ret

000000008000092c <uartputc_sync>:
// interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000092c:	1101                	addi	sp,sp,-32
    8000092e:	ec06                	sd	ra,24(sp)
    80000930:	e822                	sd	s0,16(sp)
    80000932:	e426                	sd	s1,8(sp)
    80000934:	1000                	addi	s0,sp,32
    80000936:	84aa                	mv	s1,a0
  if(panicking == 0)
    80000938:	00007797          	auipc	a5,0x7
    8000093c:	fcc7a783          	lw	a5,-52(a5) # 80007904 <panicking>
    80000940:	cf95                	beqz	a5,8000097c <uartputc_sync+0x50>
    push_off();

  if(panicked){
    80000942:	00007797          	auipc	a5,0x7
    80000946:	fbe7a783          	lw	a5,-66(a5) # 80007900 <panicked>
    8000094a:	ef85                	bnez	a5,80000982 <uartputc_sync+0x56>
    for(;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000094c:	10000737          	lui	a4,0x10000
    80000950:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000952:	00074783          	lbu	a5,0(a4)
    80000956:	0207f793          	andi	a5,a5,32
    8000095a:	dfe5                	beqz	a5,80000952 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000095c:	0ff4f513          	zext.b	a0,s1
    80000960:	100007b7          	lui	a5,0x10000
    80000964:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    80000968:	00007797          	auipc	a5,0x7
    8000096c:	f9c7a783          	lw	a5,-100(a5) # 80007904 <panicking>
    80000970:	cb91                	beqz	a5,80000984 <uartputc_sync+0x58>
    pop_off();
}
    80000972:	60e2                	ld	ra,24(sp)
    80000974:	6442                	ld	s0,16(sp)
    80000976:	64a2                	ld	s1,8(sp)
    80000978:	6105                	addi	sp,sp,32
    8000097a:	8082                	ret
    push_off();
    8000097c:	254000ef          	jal	80000bd0 <push_off>
    80000980:	b7c9                	j	80000942 <uartputc_sync+0x16>
    for(;;)
    80000982:	a001                	j	80000982 <uartputc_sync+0x56>
    pop_off();
    80000984:	2d0000ef          	jal	80000c54 <pop_off>
}
    80000988:	b7ed                	j	80000972 <uartputc_sync+0x46>

000000008000098a <uartgetc>:

// try to read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    8000098a:	1141                	addi	sp,sp,-16
    8000098c:	e422                	sd	s0,8(sp)
    8000098e:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    80000990:	100007b7          	lui	a5,0x10000
    80000994:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    80000996:	0007c783          	lbu	a5,0(a5)
    8000099a:	8b85                	andi	a5,a5,1
    8000099c:	cb81                	beqz	a5,800009ac <uartgetc+0x22>
    // input data is ready.
    return ReadReg(RHR);
    8000099e:	100007b7          	lui	a5,0x10000
    800009a2:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800009a6:	6422                	ld	s0,8(sp)
    800009a8:	0141                	addi	sp,sp,16
    800009aa:	8082                	ret
    return -1;
    800009ac:	557d                	li	a0,-1
    800009ae:	bfe5                	j	800009a6 <uartgetc+0x1c>

00000000800009b0 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009b0:	1101                	addi	sp,sp,-32
    800009b2:	ec06                	sd	ra,24(sp)
    800009b4:	e822                	sd	s0,16(sp)
    800009b6:	e426                	sd	s1,8(sp)
    800009b8:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009ba:	100007b7          	lui	a5,0x10000
    800009be:	0789                	addi	a5,a5,2 # 10000002 <_entry-0x6ffffffe>
    800009c0:	0007c783          	lbu	a5,0(a5)

  acquire(&tx_lock);
    800009c4:	0000f517          	auipc	a0,0xf
    800009c8:	02c50513          	addi	a0,a0,44 # 8000f9f0 <tx_lock>
    800009cc:	244000ef          	jal	80000c10 <acquire>
  if(ReadReg(LSR) & LSR_TX_IDLE){
    800009d0:	100007b7          	lui	a5,0x10000
    800009d4:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    800009d6:	0007c783          	lbu	a5,0(a5)
    800009da:	0207f793          	andi	a5,a5,32
    800009de:	eb89                	bnez	a5,800009f0 <uartintr+0x40>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    800009e0:	0000f517          	auipc	a0,0xf
    800009e4:	01050513          	addi	a0,a0,16 # 8000f9f0 <tx_lock>
    800009e8:	2c0000ef          	jal	80000ca8 <release>

  // read and process incoming characters, if any.
  while(1){
    int c = uartgetc();
    if(c == -1)
    800009ec:	54fd                	li	s1,-1
    800009ee:	a831                	j	80000a0a <uartintr+0x5a>
    tx_busy = 0;
    800009f0:	00007797          	auipc	a5,0x7
    800009f4:	f007ae23          	sw	zero,-228(a5) # 8000790c <tx_busy>
    wakeup(&tx_chan);
    800009f8:	00007517          	auipc	a0,0x7
    800009fc:	f1050513          	addi	a0,a0,-240 # 80007908 <tx_chan>
    80000a00:	56a010ef          	jal	80001f6a <wakeup>
    80000a04:	bff1                	j	800009e0 <uartintr+0x30>
      break;
    consoleintr(c);
    80000a06:	8a5ff0ef          	jal	800002aa <consoleintr>
    int c = uartgetc();
    80000a0a:	f81ff0ef          	jal	8000098a <uartgetc>
    if(c == -1)
    80000a0e:	fe951ce3          	bne	a0,s1,80000a06 <uartintr+0x56>
  }
}
    80000a12:	60e2                	ld	ra,24(sp)
    80000a14:	6442                	ld	s0,16(sp)
    80000a16:	64a2                	ld	s1,8(sp)
    80000a18:	6105                	addi	sp,sp,32
    80000a1a:	8082                	ret

0000000080000a1c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a1c:	1101                	addi	sp,sp,-32
    80000a1e:	ec06                	sd	ra,24(sp)
    80000a20:	e822                	sd	s0,16(sp)
    80000a22:	e426                	sd	s1,8(sp)
    80000a24:	e04a                	sd	s2,0(sp)
    80000a26:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000a28:	03451793          	slli	a5,a0,0x34
    80000a2c:	e7a9                	bnez	a5,80000a76 <kfree+0x5a>
    80000a2e:	84aa                	mv	s1,a0
    80000a30:	00020797          	auipc	a5,0x20
    80000a34:	20878793          	addi	a5,a5,520 # 80020c38 <end>
    80000a38:	02f56f63          	bltu	a0,a5,80000a76 <kfree+0x5a>
    80000a3c:	47c5                	li	a5,17
    80000a3e:	07ee                	slli	a5,a5,0x1b
    80000a40:	02f57b63          	bgeu	a0,a5,80000a76 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a44:	6605                	lui	a2,0x1
    80000a46:	4585                	li	a1,1
    80000a48:	29c000ef          	jal	80000ce4 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a4c:	0000f917          	auipc	s2,0xf
    80000a50:	fbc90913          	addi	s2,s2,-68 # 8000fa08 <kmem>
    80000a54:	854a                	mv	a0,s2
    80000a56:	1ba000ef          	jal	80000c10 <acquire>
  r->next = kmem.freelist;
    80000a5a:	01893783          	ld	a5,24(s2)
    80000a5e:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a60:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a64:	854a                	mv	a0,s2
    80000a66:	242000ef          	jal	80000ca8 <release>
}
    80000a6a:	60e2                	ld	ra,24(sp)
    80000a6c:	6442                	ld	s0,16(sp)
    80000a6e:	64a2                	ld	s1,8(sp)
    80000a70:	6902                	ld	s2,0(sp)
    80000a72:	6105                	addi	sp,sp,32
    80000a74:	8082                	ret
    panic("kfree");
    80000a76:	00006517          	auipc	a0,0x6
    80000a7a:	5c250513          	addi	a0,a0,1474 # 80007038 <etext+0x38>
    80000a7e:	d63ff0ef          	jal	800007e0 <panic>

0000000080000a82 <freerange>:
{
    80000a82:	7179                	addi	sp,sp,-48
    80000a84:	f406                	sd	ra,40(sp)
    80000a86:	f022                	sd	s0,32(sp)
    80000a88:	ec26                	sd	s1,24(sp)
    80000a8a:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000a8c:	6785                	lui	a5,0x1
    80000a8e:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000a92:	00e504b3          	add	s1,a0,a4
    80000a96:	777d                	lui	a4,0xfffff
    80000a98:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a9a:	94be                	add	s1,s1,a5
    80000a9c:	0295e263          	bltu	a1,s1,80000ac0 <freerange+0x3e>
    80000aa0:	e84a                	sd	s2,16(sp)
    80000aa2:	e44e                	sd	s3,8(sp)
    80000aa4:	e052                	sd	s4,0(sp)
    80000aa6:	892e                	mv	s2,a1
    kfree(p);
    80000aa8:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000aaa:	6985                	lui	s3,0x1
    kfree(p);
    80000aac:	01448533          	add	a0,s1,s4
    80000ab0:	f6dff0ef          	jal	80000a1c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ab4:	94ce                	add	s1,s1,s3
    80000ab6:	fe997be3          	bgeu	s2,s1,80000aac <freerange+0x2a>
    80000aba:	6942                	ld	s2,16(sp)
    80000abc:	69a2                	ld	s3,8(sp)
    80000abe:	6a02                	ld	s4,0(sp)
}
    80000ac0:	70a2                	ld	ra,40(sp)
    80000ac2:	7402                	ld	s0,32(sp)
    80000ac4:	64e2                	ld	s1,24(sp)
    80000ac6:	6145                	addi	sp,sp,48
    80000ac8:	8082                	ret

0000000080000aca <kinit>:
{
    80000aca:	1141                	addi	sp,sp,-16
    80000acc:	e406                	sd	ra,8(sp)
    80000ace:	e022                	sd	s0,0(sp)
    80000ad0:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000ad2:	00006597          	auipc	a1,0x6
    80000ad6:	56e58593          	addi	a1,a1,1390 # 80007040 <etext+0x40>
    80000ada:	0000f517          	auipc	a0,0xf
    80000ade:	f2e50513          	addi	a0,a0,-210 # 8000fa08 <kmem>
    80000ae2:	0ae000ef          	jal	80000b90 <initlock>
  freerange(end, (void*)PHYSTOP);
    80000ae6:	45c5                	li	a1,17
    80000ae8:	05ee                	slli	a1,a1,0x1b
    80000aea:	00020517          	auipc	a0,0x20
    80000aee:	14e50513          	addi	a0,a0,334 # 80020c38 <end>
    80000af2:	f91ff0ef          	jal	80000a82 <freerange>
}
    80000af6:	60a2                	ld	ra,8(sp)
    80000af8:	6402                	ld	s0,0(sp)
    80000afa:	0141                	addi	sp,sp,16
    80000afc:	8082                	ret

0000000080000afe <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000afe:	1101                	addi	sp,sp,-32
    80000b00:	ec06                	sd	ra,24(sp)
    80000b02:	e822                	sd	s0,16(sp)
    80000b04:	e426                	sd	s1,8(sp)
    80000b06:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b08:	0000f497          	auipc	s1,0xf
    80000b0c:	f0048493          	addi	s1,s1,-256 # 8000fa08 <kmem>
    80000b10:	8526                	mv	a0,s1
    80000b12:	0fe000ef          	jal	80000c10 <acquire>
  r = kmem.freelist;
    80000b16:	6c84                	ld	s1,24(s1)
  if(r)
    80000b18:	c485                	beqz	s1,80000b40 <kalloc+0x42>
    kmem.freelist = r->next;
    80000b1a:	609c                	ld	a5,0(s1)
    80000b1c:	0000f517          	auipc	a0,0xf
    80000b20:	eec50513          	addi	a0,a0,-276 # 8000fa08 <kmem>
    80000b24:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000b26:	182000ef          	jal	80000ca8 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b2a:	6605                	lui	a2,0x1
    80000b2c:	4595                	li	a1,5
    80000b2e:	8526                	mv	a0,s1
    80000b30:	1b4000ef          	jal	80000ce4 <memset>
  return (void*)r;
}
    80000b34:	8526                	mv	a0,s1
    80000b36:	60e2                	ld	ra,24(sp)
    80000b38:	6442                	ld	s0,16(sp)
    80000b3a:	64a2                	ld	s1,8(sp)
    80000b3c:	6105                	addi	sp,sp,32
    80000b3e:	8082                	ret
  release(&kmem.lock);
    80000b40:	0000f517          	auipc	a0,0xf
    80000b44:	ec850513          	addi	a0,a0,-312 # 8000fa08 <kmem>
    80000b48:	160000ef          	jal	80000ca8 <release>
  if(r)
    80000b4c:	b7e5                	j	80000b34 <kalloc+0x36>

0000000080000b4e <memory_available>:

// Added for project 01
uint64
memory_available(void)
{
    80000b4e:	1101                	addi	sp,sp,-32
    80000b50:	ec06                	sd	ra,24(sp)
    80000b52:	e822                	sd	s0,16(sp)
    80000b54:	e426                	sd	s1,8(sp)
    80000b56:	1000                	addi	s0,sp,32
  struct run *r;
  uint64 count = 0;
  acquire(&kmem.lock);
    80000b58:	0000f497          	auipc	s1,0xf
    80000b5c:	eb048493          	addi	s1,s1,-336 # 8000fa08 <kmem>
    80000b60:	8526                	mv	a0,s1
    80000b62:	0ae000ef          	jal	80000c10 <acquire>
  r = kmem.freelist;
    80000b66:	6c9c                	ld	a5,24(s1)
  while(r){
    80000b68:	c395                	beqz	a5,80000b8c <memory_available+0x3e>
  uint64 count = 0;
    80000b6a:	4481                	li	s1,0
    count++;
    80000b6c:	0485                	addi	s1,s1,1
    r = r->next;
    80000b6e:	639c                	ld	a5,0(a5)
  while(r){
    80000b70:	fff5                	bnez	a5,80000b6c <memory_available+0x1e>
  }
  release(&kmem.lock);
    80000b72:	0000f517          	auipc	a0,0xf
    80000b76:	e9650513          	addi	a0,a0,-362 # 8000fa08 <kmem>
    80000b7a:	12e000ef          	jal	80000ca8 <release>
  return count * PGSIZE;
    80000b7e:	00c49513          	slli	a0,s1,0xc
    80000b82:	60e2                	ld	ra,24(sp)
    80000b84:	6442                	ld	s0,16(sp)
    80000b86:	64a2                	ld	s1,8(sp)
    80000b88:	6105                	addi	sp,sp,32
    80000b8a:	8082                	ret
  uint64 count = 0;
    80000b8c:	4481                	li	s1,0
    80000b8e:	b7d5                	j	80000b72 <memory_available+0x24>

0000000080000b90 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b90:	1141                	addi	sp,sp,-16
    80000b92:	e422                	sd	s0,8(sp)
    80000b94:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b96:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b98:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b9c:	00053823          	sd	zero,16(a0)
}
    80000ba0:	6422                	ld	s0,8(sp)
    80000ba2:	0141                	addi	sp,sp,16
    80000ba4:	8082                	ret

0000000080000ba6 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000ba6:	411c                	lw	a5,0(a0)
    80000ba8:	e399                	bnez	a5,80000bae <holding+0x8>
    80000baa:	4501                	li	a0,0
  return r;
}
    80000bac:	8082                	ret
{
    80000bae:	1101                	addi	sp,sp,-32
    80000bb0:	ec06                	sd	ra,24(sp)
    80000bb2:	e822                	sd	s0,16(sp)
    80000bb4:	e426                	sd	s1,8(sp)
    80000bb6:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000bb8:	6904                	ld	s1,16(a0)
    80000bba:	53b000ef          	jal	800018f4 <mycpu>
    80000bbe:	40a48533          	sub	a0,s1,a0
    80000bc2:	00153513          	seqz	a0,a0
}
    80000bc6:	60e2                	ld	ra,24(sp)
    80000bc8:	6442                	ld	s0,16(sp)
    80000bca:	64a2                	ld	s1,8(sp)
    80000bcc:	6105                	addi	sp,sp,32
    80000bce:	8082                	ret

0000000080000bd0 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000bd0:	1101                	addi	sp,sp,-32
    80000bd2:	ec06                	sd	ra,24(sp)
    80000bd4:	e822                	sd	s0,16(sp)
    80000bd6:	e426                	sd	s1,8(sp)
    80000bd8:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000bda:	100024f3          	csrr	s1,sstatus
    80000bde:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000be2:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000be4:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000be8:	50d000ef          	jal	800018f4 <mycpu>
    80000bec:	5d3c                	lw	a5,120(a0)
    80000bee:	cb99                	beqz	a5,80000c04 <push_off+0x34>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000bf0:	505000ef          	jal	800018f4 <mycpu>
    80000bf4:	5d3c                	lw	a5,120(a0)
    80000bf6:	2785                	addiw	a5,a5,1
    80000bf8:	dd3c                	sw	a5,120(a0)
}
    80000bfa:	60e2                	ld	ra,24(sp)
    80000bfc:	6442                	ld	s0,16(sp)
    80000bfe:	64a2                	ld	s1,8(sp)
    80000c00:	6105                	addi	sp,sp,32
    80000c02:	8082                	ret
    mycpu()->intena = old;
    80000c04:	4f1000ef          	jal	800018f4 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000c08:	8085                	srli	s1,s1,0x1
    80000c0a:	8885                	andi	s1,s1,1
    80000c0c:	dd64                	sw	s1,124(a0)
    80000c0e:	b7cd                	j	80000bf0 <push_off+0x20>

0000000080000c10 <acquire>:
{
    80000c10:	1101                	addi	sp,sp,-32
    80000c12:	ec06                	sd	ra,24(sp)
    80000c14:	e822                	sd	s0,16(sp)
    80000c16:	e426                	sd	s1,8(sp)
    80000c18:	1000                	addi	s0,sp,32
    80000c1a:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c1c:	fb5ff0ef          	jal	80000bd0 <push_off>
  if(holding(lk))
    80000c20:	8526                	mv	a0,s1
    80000c22:	f85ff0ef          	jal	80000ba6 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c26:	4705                	li	a4,1
  if(holding(lk))
    80000c28:	e105                	bnez	a0,80000c48 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c2a:	87ba                	mv	a5,a4
    80000c2c:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c30:	2781                	sext.w	a5,a5
    80000c32:	ffe5                	bnez	a5,80000c2a <acquire+0x1a>
  __sync_synchronize();
    80000c34:	0ff0000f          	fence
  lk->cpu = mycpu();
    80000c38:	4bd000ef          	jal	800018f4 <mycpu>
    80000c3c:	e888                	sd	a0,16(s1)
}
    80000c3e:	60e2                	ld	ra,24(sp)
    80000c40:	6442                	ld	s0,16(sp)
    80000c42:	64a2                	ld	s1,8(sp)
    80000c44:	6105                	addi	sp,sp,32
    80000c46:	8082                	ret
    panic("acquire");
    80000c48:	00006517          	auipc	a0,0x6
    80000c4c:	40050513          	addi	a0,a0,1024 # 80007048 <etext+0x48>
    80000c50:	b91ff0ef          	jal	800007e0 <panic>

0000000080000c54 <pop_off>:

void
pop_off(void)
{
    80000c54:	1141                	addi	sp,sp,-16
    80000c56:	e406                	sd	ra,8(sp)
    80000c58:	e022                	sd	s0,0(sp)
    80000c5a:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c5c:	499000ef          	jal	800018f4 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c60:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c64:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c66:	e78d                	bnez	a5,80000c90 <pop_off+0x3c>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c68:	5d3c                	lw	a5,120(a0)
    80000c6a:	02f05963          	blez	a5,80000c9c <pop_off+0x48>
    panic("pop_off");
  c->noff -= 1;
    80000c6e:	37fd                	addiw	a5,a5,-1
    80000c70:	0007871b          	sext.w	a4,a5
    80000c74:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c76:	eb09                	bnez	a4,80000c88 <pop_off+0x34>
    80000c78:	5d7c                	lw	a5,124(a0)
    80000c7a:	c799                	beqz	a5,80000c88 <pop_off+0x34>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c7c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c80:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c84:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c88:	60a2                	ld	ra,8(sp)
    80000c8a:	6402                	ld	s0,0(sp)
    80000c8c:	0141                	addi	sp,sp,16
    80000c8e:	8082                	ret
    panic("pop_off - interruptible");
    80000c90:	00006517          	auipc	a0,0x6
    80000c94:	3c050513          	addi	a0,a0,960 # 80007050 <etext+0x50>
    80000c98:	b49ff0ef          	jal	800007e0 <panic>
    panic("pop_off");
    80000c9c:	00006517          	auipc	a0,0x6
    80000ca0:	3cc50513          	addi	a0,a0,972 # 80007068 <etext+0x68>
    80000ca4:	b3dff0ef          	jal	800007e0 <panic>

0000000080000ca8 <release>:
{
    80000ca8:	1101                	addi	sp,sp,-32
    80000caa:	ec06                	sd	ra,24(sp)
    80000cac:	e822                	sd	s0,16(sp)
    80000cae:	e426                	sd	s1,8(sp)
    80000cb0:	1000                	addi	s0,sp,32
    80000cb2:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000cb4:	ef3ff0ef          	jal	80000ba6 <holding>
    80000cb8:	c105                	beqz	a0,80000cd8 <release+0x30>
  lk->cpu = 0;
    80000cba:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000cbe:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    80000cc2:	0f50000f          	fence	iorw,ow
    80000cc6:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    80000cca:	f8bff0ef          	jal	80000c54 <pop_off>
}
    80000cce:	60e2                	ld	ra,24(sp)
    80000cd0:	6442                	ld	s0,16(sp)
    80000cd2:	64a2                	ld	s1,8(sp)
    80000cd4:	6105                	addi	sp,sp,32
    80000cd6:	8082                	ret
    panic("release");
    80000cd8:	00006517          	auipc	a0,0x6
    80000cdc:	39850513          	addi	a0,a0,920 # 80007070 <etext+0x70>
    80000ce0:	b01ff0ef          	jal	800007e0 <panic>

0000000080000ce4 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000ce4:	1141                	addi	sp,sp,-16
    80000ce6:	e422                	sd	s0,8(sp)
    80000ce8:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000cea:	ca19                	beqz	a2,80000d00 <memset+0x1c>
    80000cec:	87aa                	mv	a5,a0
    80000cee:	1602                	slli	a2,a2,0x20
    80000cf0:	9201                	srli	a2,a2,0x20
    80000cf2:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000cf6:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000cfa:	0785                	addi	a5,a5,1
    80000cfc:	fee79de3          	bne	a5,a4,80000cf6 <memset+0x12>
  }
  return dst;
}
    80000d00:	6422                	ld	s0,8(sp)
    80000d02:	0141                	addi	sp,sp,16
    80000d04:	8082                	ret

0000000080000d06 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d06:	1141                	addi	sp,sp,-16
    80000d08:	e422                	sd	s0,8(sp)
    80000d0a:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000d0c:	ca05                	beqz	a2,80000d3c <memcmp+0x36>
    80000d0e:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000d12:	1682                	slli	a3,a3,0x20
    80000d14:	9281                	srli	a3,a3,0x20
    80000d16:	0685                	addi	a3,a3,1
    80000d18:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000d1a:	00054783          	lbu	a5,0(a0)
    80000d1e:	0005c703          	lbu	a4,0(a1)
    80000d22:	00e79863          	bne	a5,a4,80000d32 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000d26:	0505                	addi	a0,a0,1
    80000d28:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d2a:	fed518e3          	bne	a0,a3,80000d1a <memcmp+0x14>
  }

  return 0;
    80000d2e:	4501                	li	a0,0
    80000d30:	a019                	j	80000d36 <memcmp+0x30>
      return *s1 - *s2;
    80000d32:	40e7853b          	subw	a0,a5,a4
}
    80000d36:	6422                	ld	s0,8(sp)
    80000d38:	0141                	addi	sp,sp,16
    80000d3a:	8082                	ret
  return 0;
    80000d3c:	4501                	li	a0,0
    80000d3e:	bfe5                	j	80000d36 <memcmp+0x30>

0000000080000d40 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d40:	1141                	addi	sp,sp,-16
    80000d42:	e422                	sd	s0,8(sp)
    80000d44:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d46:	c205                	beqz	a2,80000d66 <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d48:	02a5e263          	bltu	a1,a0,80000d6c <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d4c:	1602                	slli	a2,a2,0x20
    80000d4e:	9201                	srli	a2,a2,0x20
    80000d50:	00c587b3          	add	a5,a1,a2
{
    80000d54:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d56:	0585                	addi	a1,a1,1
    80000d58:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffde3c9>
    80000d5a:	fff5c683          	lbu	a3,-1(a1)
    80000d5e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d62:	feb79ae3          	bne	a5,a1,80000d56 <memmove+0x16>

  return dst;
}
    80000d66:	6422                	ld	s0,8(sp)
    80000d68:	0141                	addi	sp,sp,16
    80000d6a:	8082                	ret
  if(s < d && s + n > d){
    80000d6c:	02061693          	slli	a3,a2,0x20
    80000d70:	9281                	srli	a3,a3,0x20
    80000d72:	00d58733          	add	a4,a1,a3
    80000d76:	fce57be3          	bgeu	a0,a4,80000d4c <memmove+0xc>
    d += n;
    80000d7a:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d7c:	fff6079b          	addiw	a5,a2,-1
    80000d80:	1782                	slli	a5,a5,0x20
    80000d82:	9381                	srli	a5,a5,0x20
    80000d84:	fff7c793          	not	a5,a5
    80000d88:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d8a:	177d                	addi	a4,a4,-1
    80000d8c:	16fd                	addi	a3,a3,-1
    80000d8e:	00074603          	lbu	a2,0(a4)
    80000d92:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000d96:	fef71ae3          	bne	a4,a5,80000d8a <memmove+0x4a>
    80000d9a:	b7f1                	j	80000d66 <memmove+0x26>

0000000080000d9c <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000d9c:	1141                	addi	sp,sp,-16
    80000d9e:	e406                	sd	ra,8(sp)
    80000da0:	e022                	sd	s0,0(sp)
    80000da2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000da4:	f9dff0ef          	jal	80000d40 <memmove>
}
    80000da8:	60a2                	ld	ra,8(sp)
    80000daa:	6402                	ld	s0,0(sp)
    80000dac:	0141                	addi	sp,sp,16
    80000dae:	8082                	ret

0000000080000db0 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000db0:	1141                	addi	sp,sp,-16
    80000db2:	e422                	sd	s0,8(sp)
    80000db4:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000db6:	ce11                	beqz	a2,80000dd2 <strncmp+0x22>
    80000db8:	00054783          	lbu	a5,0(a0)
    80000dbc:	cf89                	beqz	a5,80000dd6 <strncmp+0x26>
    80000dbe:	0005c703          	lbu	a4,0(a1)
    80000dc2:	00f71a63          	bne	a4,a5,80000dd6 <strncmp+0x26>
    n--, p++, q++;
    80000dc6:	367d                	addiw	a2,a2,-1
    80000dc8:	0505                	addi	a0,a0,1
    80000dca:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000dcc:	f675                	bnez	a2,80000db8 <strncmp+0x8>
  if(n == 0)
    return 0;
    80000dce:	4501                	li	a0,0
    80000dd0:	a801                	j	80000de0 <strncmp+0x30>
    80000dd2:	4501                	li	a0,0
    80000dd4:	a031                	j	80000de0 <strncmp+0x30>
  return (uchar)*p - (uchar)*q;
    80000dd6:	00054503          	lbu	a0,0(a0)
    80000dda:	0005c783          	lbu	a5,0(a1)
    80000dde:	9d1d                	subw	a0,a0,a5
}
    80000de0:	6422                	ld	s0,8(sp)
    80000de2:	0141                	addi	sp,sp,16
    80000de4:	8082                	ret

0000000080000de6 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000de6:	1141                	addi	sp,sp,-16
    80000de8:	e422                	sd	s0,8(sp)
    80000dea:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000dec:	87aa                	mv	a5,a0
    80000dee:	86b2                	mv	a3,a2
    80000df0:	367d                	addiw	a2,a2,-1
    80000df2:	02d05563          	blez	a3,80000e1c <strncpy+0x36>
    80000df6:	0785                	addi	a5,a5,1
    80000df8:	0005c703          	lbu	a4,0(a1)
    80000dfc:	fee78fa3          	sb	a4,-1(a5)
    80000e00:	0585                	addi	a1,a1,1
    80000e02:	f775                	bnez	a4,80000dee <strncpy+0x8>
    ;
  while(n-- > 0)
    80000e04:	873e                	mv	a4,a5
    80000e06:	9fb5                	addw	a5,a5,a3
    80000e08:	37fd                	addiw	a5,a5,-1
    80000e0a:	00c05963          	blez	a2,80000e1c <strncpy+0x36>
    *s++ = 0;
    80000e0e:	0705                	addi	a4,a4,1
    80000e10:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000e14:	40e786bb          	subw	a3,a5,a4
    80000e18:	fed04be3          	bgtz	a3,80000e0e <strncpy+0x28>
  return os;
}
    80000e1c:	6422                	ld	s0,8(sp)
    80000e1e:	0141                	addi	sp,sp,16
    80000e20:	8082                	ret

0000000080000e22 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e22:	1141                	addi	sp,sp,-16
    80000e24:	e422                	sd	s0,8(sp)
    80000e26:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e28:	02c05363          	blez	a2,80000e4e <safestrcpy+0x2c>
    80000e2c:	fff6069b          	addiw	a3,a2,-1
    80000e30:	1682                	slli	a3,a3,0x20
    80000e32:	9281                	srli	a3,a3,0x20
    80000e34:	96ae                	add	a3,a3,a1
    80000e36:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e38:	00d58963          	beq	a1,a3,80000e4a <safestrcpy+0x28>
    80000e3c:	0585                	addi	a1,a1,1
    80000e3e:	0785                	addi	a5,a5,1
    80000e40:	fff5c703          	lbu	a4,-1(a1)
    80000e44:	fee78fa3          	sb	a4,-1(a5)
    80000e48:	fb65                	bnez	a4,80000e38 <safestrcpy+0x16>
    ;
  *s = 0;
    80000e4a:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e4e:	6422                	ld	s0,8(sp)
    80000e50:	0141                	addi	sp,sp,16
    80000e52:	8082                	ret

0000000080000e54 <strlen>:

int
strlen(const char *s)
{
    80000e54:	1141                	addi	sp,sp,-16
    80000e56:	e422                	sd	s0,8(sp)
    80000e58:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e5a:	00054783          	lbu	a5,0(a0)
    80000e5e:	cf91                	beqz	a5,80000e7a <strlen+0x26>
    80000e60:	0505                	addi	a0,a0,1
    80000e62:	87aa                	mv	a5,a0
    80000e64:	86be                	mv	a3,a5
    80000e66:	0785                	addi	a5,a5,1
    80000e68:	fff7c703          	lbu	a4,-1(a5)
    80000e6c:	ff65                	bnez	a4,80000e64 <strlen+0x10>
    80000e6e:	40a6853b          	subw	a0,a3,a0
    80000e72:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    80000e74:	6422                	ld	s0,8(sp)
    80000e76:	0141                	addi	sp,sp,16
    80000e78:	8082                	ret
  for(n = 0; s[n]; n++)
    80000e7a:	4501                	li	a0,0
    80000e7c:	bfe5                	j	80000e74 <strlen+0x20>

0000000080000e7e <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e7e:	1141                	addi	sp,sp,-16
    80000e80:	e406                	sd	ra,8(sp)
    80000e82:	e022                	sd	s0,0(sp)
    80000e84:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000e86:	25f000ef          	jal	800018e4 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000e8a:	00007717          	auipc	a4,0x7
    80000e8e:	a8670713          	addi	a4,a4,-1402 # 80007910 <started>
  if(cpuid() == 0){
    80000e92:	c51d                	beqz	a0,80000ec0 <main+0x42>
    while(started == 0)
    80000e94:	431c                	lw	a5,0(a4)
    80000e96:	2781                	sext.w	a5,a5
    80000e98:	dff5                	beqz	a5,80000e94 <main+0x16>
      ;
    __sync_synchronize();
    80000e9a:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    80000e9e:	247000ef          	jal	800018e4 <cpuid>
    80000ea2:	85aa                	mv	a1,a0
    80000ea4:	00006517          	auipc	a0,0x6
    80000ea8:	1f450513          	addi	a0,a0,500 # 80007098 <etext+0x98>
    80000eac:	e4eff0ef          	jal	800004fa <printf>
    kvminithart();    // turn on paging
    80000eb0:	080000ef          	jal	80000f30 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000eb4:	171010ef          	jal	80002824 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000eb8:	1e1040ef          	jal	80005898 <plicinithart>
  }

  scheduler();        
    80000ebc:	6cb000ef          	jal	80001d86 <scheduler>
    consoleinit();
    80000ec0:	d64ff0ef          	jal	80000424 <consoleinit>
    printfinit();
    80000ec4:	959ff0ef          	jal	8000081c <printfinit>
    printf("\n");
    80000ec8:	00006517          	auipc	a0,0x6
    80000ecc:	1b050513          	addi	a0,a0,432 # 80007078 <etext+0x78>
    80000ed0:	e2aff0ef          	jal	800004fa <printf>
    printf("xv6 kernel is booting\n");
    80000ed4:	00006517          	auipc	a0,0x6
    80000ed8:	1ac50513          	addi	a0,a0,428 # 80007080 <etext+0x80>
    80000edc:	e1eff0ef          	jal	800004fa <printf>
    printf("\n");
    80000ee0:	00006517          	auipc	a0,0x6
    80000ee4:	19850513          	addi	a0,a0,408 # 80007078 <etext+0x78>
    80000ee8:	e12ff0ef          	jal	800004fa <printf>
    kinit();         // physical page allocator
    80000eec:	bdfff0ef          	jal	80000aca <kinit>
    kvminit();       // create kernel page table
    80000ef0:	2ca000ef          	jal	800011ba <kvminit>
    kvminithart();   // turn on paging
    80000ef4:	03c000ef          	jal	80000f30 <kvminithart>
    procinit();      // process table
    80000ef8:	137000ef          	jal	8000182e <procinit>
    trapinit();      // trap vectors
    80000efc:	105010ef          	jal	80002800 <trapinit>
    trapinithart();  // install kernel trap vector
    80000f00:	125010ef          	jal	80002824 <trapinithart>
    plicinit();      // set up interrupt controller
    80000f04:	17b040ef          	jal	8000587e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f08:	191040ef          	jal	80005898 <plicinithart>
    binit();         // buffer cache
    80000f0c:	05a020ef          	jal	80002f66 <binit>
    iinit();         // inode table
    80000f10:	5e0020ef          	jal	800034f0 <iinit>
    fileinit();      // file table
    80000f14:	4d2030ef          	jal	800043e6 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f18:	271040ef          	jal	80005988 <virtio_disk_init>
    userinit();      // first user process
    80000f1c:	4bf000ef          	jal	80001bda <userinit>
    __sync_synchronize();
    80000f20:	0ff0000f          	fence
    started = 1;
    80000f24:	4785                	li	a5,1
    80000f26:	00007717          	auipc	a4,0x7
    80000f2a:	9ef72523          	sw	a5,-1558(a4) # 80007910 <started>
    80000f2e:	b779                	j	80000ebc <main+0x3e>

0000000080000f30 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000f30:	1141                	addi	sp,sp,-16
    80000f32:	e422                	sd	s0,8(sp)
    80000f34:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000f36:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f3a:	00007797          	auipc	a5,0x7
    80000f3e:	9de7b783          	ld	a5,-1570(a5) # 80007918 <kernel_pagetable>
    80000f42:	83b1                	srli	a5,a5,0xc
    80000f44:	577d                	li	a4,-1
    80000f46:	177e                	slli	a4,a4,0x3f
    80000f48:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000f4a:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000f4e:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f52:	6422                	ld	s0,8(sp)
    80000f54:	0141                	addi	sp,sp,16
    80000f56:	8082                	ret

0000000080000f58 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f58:	7139                	addi	sp,sp,-64
    80000f5a:	fc06                	sd	ra,56(sp)
    80000f5c:	f822                	sd	s0,48(sp)
    80000f5e:	f426                	sd	s1,40(sp)
    80000f60:	f04a                	sd	s2,32(sp)
    80000f62:	ec4e                	sd	s3,24(sp)
    80000f64:	e852                	sd	s4,16(sp)
    80000f66:	e456                	sd	s5,8(sp)
    80000f68:	e05a                	sd	s6,0(sp)
    80000f6a:	0080                	addi	s0,sp,64
    80000f6c:	84aa                	mv	s1,a0
    80000f6e:	89ae                	mv	s3,a1
    80000f70:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80000f72:	57fd                	li	a5,-1
    80000f74:	83e9                	srli	a5,a5,0x1a
    80000f76:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000f78:	4b31                	li	s6,12
  if(va >= MAXVA)
    80000f7a:	02b7fc63          	bgeu	a5,a1,80000fb2 <walk+0x5a>
    panic("walk");
    80000f7e:	00006517          	auipc	a0,0x6
    80000f82:	13250513          	addi	a0,a0,306 # 800070b0 <etext+0xb0>
    80000f86:	85bff0ef          	jal	800007e0 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000f8a:	060a8263          	beqz	s5,80000fee <walk+0x96>
    80000f8e:	b71ff0ef          	jal	80000afe <kalloc>
    80000f92:	84aa                	mv	s1,a0
    80000f94:	c139                	beqz	a0,80000fda <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000f96:	6605                	lui	a2,0x1
    80000f98:	4581                	li	a1,0
    80000f9a:	d4bff0ef          	jal	80000ce4 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000f9e:	00c4d793          	srli	a5,s1,0xc
    80000fa2:	07aa                	slli	a5,a5,0xa
    80000fa4:	0017e793          	ori	a5,a5,1
    80000fa8:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80000fac:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffde3bf>
    80000fae:	036a0063          	beq	s4,s6,80000fce <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    80000fb2:	0149d933          	srl	s2,s3,s4
    80000fb6:	1ff97913          	andi	s2,s2,511
    80000fba:	090e                	slli	s2,s2,0x3
    80000fbc:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000fbe:	00093483          	ld	s1,0(s2)
    80000fc2:	0014f793          	andi	a5,s1,1
    80000fc6:	d3f1                	beqz	a5,80000f8a <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000fc8:	80a9                	srli	s1,s1,0xa
    80000fca:	04b2                	slli	s1,s1,0xc
    80000fcc:	b7c5                	j	80000fac <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    80000fce:	00c9d513          	srli	a0,s3,0xc
    80000fd2:	1ff57513          	andi	a0,a0,511
    80000fd6:	050e                	slli	a0,a0,0x3
    80000fd8:	9526                	add	a0,a0,s1
}
    80000fda:	70e2                	ld	ra,56(sp)
    80000fdc:	7442                	ld	s0,48(sp)
    80000fde:	74a2                	ld	s1,40(sp)
    80000fe0:	7902                	ld	s2,32(sp)
    80000fe2:	69e2                	ld	s3,24(sp)
    80000fe4:	6a42                	ld	s4,16(sp)
    80000fe6:	6aa2                	ld	s5,8(sp)
    80000fe8:	6b02                	ld	s6,0(sp)
    80000fea:	6121                	addi	sp,sp,64
    80000fec:	8082                	ret
        return 0;
    80000fee:	4501                	li	a0,0
    80000ff0:	b7ed                	j	80000fda <walk+0x82>

0000000080000ff2 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80000ff2:	57fd                	li	a5,-1
    80000ff4:	83e9                	srli	a5,a5,0x1a
    80000ff6:	00b7f463          	bgeu	a5,a1,80000ffe <walkaddr+0xc>
    return 0;
    80000ffa:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000ffc:	8082                	ret
{
    80000ffe:	1141                	addi	sp,sp,-16
    80001000:	e406                	sd	ra,8(sp)
    80001002:	e022                	sd	s0,0(sp)
    80001004:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80001006:	4601                	li	a2,0
    80001008:	f51ff0ef          	jal	80000f58 <walk>
  if(pte == 0)
    8000100c:	c105                	beqz	a0,8000102c <walkaddr+0x3a>
  if((*pte & PTE_V) == 0)
    8000100e:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80001010:	0117f693          	andi	a3,a5,17
    80001014:	4745                	li	a4,17
    return 0;
    80001016:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80001018:	00e68663          	beq	a3,a4,80001024 <walkaddr+0x32>
}
    8000101c:	60a2                	ld	ra,8(sp)
    8000101e:	6402                	ld	s0,0(sp)
    80001020:	0141                	addi	sp,sp,16
    80001022:	8082                	ret
  pa = PTE2PA(*pte);
    80001024:	83a9                	srli	a5,a5,0xa
    80001026:	00c79513          	slli	a0,a5,0xc
  return pa;
    8000102a:	bfcd                	j	8000101c <walkaddr+0x2a>
    return 0;
    8000102c:	4501                	li	a0,0
    8000102e:	b7fd                	j	8000101c <walkaddr+0x2a>

0000000080001030 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001030:	715d                	addi	sp,sp,-80
    80001032:	e486                	sd	ra,72(sp)
    80001034:	e0a2                	sd	s0,64(sp)
    80001036:	fc26                	sd	s1,56(sp)
    80001038:	f84a                	sd	s2,48(sp)
    8000103a:	f44e                	sd	s3,40(sp)
    8000103c:	f052                	sd	s4,32(sp)
    8000103e:	ec56                	sd	s5,24(sp)
    80001040:	e85a                	sd	s6,16(sp)
    80001042:	e45e                	sd	s7,8(sp)
    80001044:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001046:	03459793          	slli	a5,a1,0x34
    8000104a:	e7a9                	bnez	a5,80001094 <mappages+0x64>
    8000104c:	8aaa                	mv	s5,a0
    8000104e:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    80001050:	03461793          	slli	a5,a2,0x34
    80001054:	e7b1                	bnez	a5,800010a0 <mappages+0x70>
    panic("mappages: size not aligned");

  if(size == 0)
    80001056:	ca39                	beqz	a2,800010ac <mappages+0x7c>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80001058:	77fd                	lui	a5,0xfffff
    8000105a:	963e                	add	a2,a2,a5
    8000105c:	00b609b3          	add	s3,a2,a1
  a = va;
    80001060:	892e                	mv	s2,a1
    80001062:	40b68a33          	sub	s4,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    80001066:	6b85                	lui	s7,0x1
    80001068:	014904b3          	add	s1,s2,s4
    if((pte = walk(pagetable, a, 1)) == 0)
    8000106c:	4605                	li	a2,1
    8000106e:	85ca                	mv	a1,s2
    80001070:	8556                	mv	a0,s5
    80001072:	ee7ff0ef          	jal	80000f58 <walk>
    80001076:	c539                	beqz	a0,800010c4 <mappages+0x94>
    if(*pte & PTE_V)
    80001078:	611c                	ld	a5,0(a0)
    8000107a:	8b85                	andi	a5,a5,1
    8000107c:	ef95                	bnez	a5,800010b8 <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    8000107e:	80b1                	srli	s1,s1,0xc
    80001080:	04aa                	slli	s1,s1,0xa
    80001082:	0164e4b3          	or	s1,s1,s6
    80001086:	0014e493          	ori	s1,s1,1
    8000108a:	e104                	sd	s1,0(a0)
    if(a == last)
    8000108c:	05390863          	beq	s2,s3,800010dc <mappages+0xac>
    a += PGSIZE;
    80001090:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    80001092:	bfd9                	j	80001068 <mappages+0x38>
    panic("mappages: va not aligned");
    80001094:	00006517          	auipc	a0,0x6
    80001098:	02450513          	addi	a0,a0,36 # 800070b8 <etext+0xb8>
    8000109c:	f44ff0ef          	jal	800007e0 <panic>
    panic("mappages: size not aligned");
    800010a0:	00006517          	auipc	a0,0x6
    800010a4:	03850513          	addi	a0,a0,56 # 800070d8 <etext+0xd8>
    800010a8:	f38ff0ef          	jal	800007e0 <panic>
    panic("mappages: size");
    800010ac:	00006517          	auipc	a0,0x6
    800010b0:	04c50513          	addi	a0,a0,76 # 800070f8 <etext+0xf8>
    800010b4:	f2cff0ef          	jal	800007e0 <panic>
      panic("mappages: remap");
    800010b8:	00006517          	auipc	a0,0x6
    800010bc:	05050513          	addi	a0,a0,80 # 80007108 <etext+0x108>
    800010c0:	f20ff0ef          	jal	800007e0 <panic>
      return -1;
    800010c4:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800010c6:	60a6                	ld	ra,72(sp)
    800010c8:	6406                	ld	s0,64(sp)
    800010ca:	74e2                	ld	s1,56(sp)
    800010cc:	7942                	ld	s2,48(sp)
    800010ce:	79a2                	ld	s3,40(sp)
    800010d0:	7a02                	ld	s4,32(sp)
    800010d2:	6ae2                	ld	s5,24(sp)
    800010d4:	6b42                	ld	s6,16(sp)
    800010d6:	6ba2                	ld	s7,8(sp)
    800010d8:	6161                	addi	sp,sp,80
    800010da:	8082                	ret
  return 0;
    800010dc:	4501                	li	a0,0
    800010de:	b7e5                	j	800010c6 <mappages+0x96>

00000000800010e0 <kvmmap>:
{
    800010e0:	1141                	addi	sp,sp,-16
    800010e2:	e406                	sd	ra,8(sp)
    800010e4:	e022                	sd	s0,0(sp)
    800010e6:	0800                	addi	s0,sp,16
    800010e8:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    800010ea:	86b2                	mv	a3,a2
    800010ec:	863e                	mv	a2,a5
    800010ee:	f43ff0ef          	jal	80001030 <mappages>
    800010f2:	e509                	bnez	a0,800010fc <kvmmap+0x1c>
}
    800010f4:	60a2                	ld	ra,8(sp)
    800010f6:	6402                	ld	s0,0(sp)
    800010f8:	0141                	addi	sp,sp,16
    800010fa:	8082                	ret
    panic("kvmmap");
    800010fc:	00006517          	auipc	a0,0x6
    80001100:	01c50513          	addi	a0,a0,28 # 80007118 <etext+0x118>
    80001104:	edcff0ef          	jal	800007e0 <panic>

0000000080001108 <kvmmake>:
{
    80001108:	1101                	addi	sp,sp,-32
    8000110a:	ec06                	sd	ra,24(sp)
    8000110c:	e822                	sd	s0,16(sp)
    8000110e:	e426                	sd	s1,8(sp)
    80001110:	e04a                	sd	s2,0(sp)
    80001112:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80001114:	9ebff0ef          	jal	80000afe <kalloc>
    80001118:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    8000111a:	6605                	lui	a2,0x1
    8000111c:	4581                	li	a1,0
    8000111e:	bc7ff0ef          	jal	80000ce4 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001122:	4719                	li	a4,6
    80001124:	6685                	lui	a3,0x1
    80001126:	10000637          	lui	a2,0x10000
    8000112a:	100005b7          	lui	a1,0x10000
    8000112e:	8526                	mv	a0,s1
    80001130:	fb1ff0ef          	jal	800010e0 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001134:	4719                	li	a4,6
    80001136:	6685                	lui	a3,0x1
    80001138:	10001637          	lui	a2,0x10001
    8000113c:	100015b7          	lui	a1,0x10001
    80001140:	8526                	mv	a0,s1
    80001142:	f9fff0ef          	jal	800010e0 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001146:	4719                	li	a4,6
    80001148:	040006b7          	lui	a3,0x4000
    8000114c:	0c000637          	lui	a2,0xc000
    80001150:	0c0005b7          	lui	a1,0xc000
    80001154:	8526                	mv	a0,s1
    80001156:	f8bff0ef          	jal	800010e0 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    8000115a:	00006917          	auipc	s2,0x6
    8000115e:	ea690913          	addi	s2,s2,-346 # 80007000 <etext>
    80001162:	4729                	li	a4,10
    80001164:	80006697          	auipc	a3,0x80006
    80001168:	e9c68693          	addi	a3,a3,-356 # 7000 <_entry-0x7fff9000>
    8000116c:	4605                	li	a2,1
    8000116e:	067e                	slli	a2,a2,0x1f
    80001170:	85b2                	mv	a1,a2
    80001172:	8526                	mv	a0,s1
    80001174:	f6dff0ef          	jal	800010e0 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80001178:	46c5                	li	a3,17
    8000117a:	06ee                	slli	a3,a3,0x1b
    8000117c:	4719                	li	a4,6
    8000117e:	412686b3          	sub	a3,a3,s2
    80001182:	864a                	mv	a2,s2
    80001184:	85ca                	mv	a1,s2
    80001186:	8526                	mv	a0,s1
    80001188:	f59ff0ef          	jal	800010e0 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    8000118c:	4729                	li	a4,10
    8000118e:	6685                	lui	a3,0x1
    80001190:	00005617          	auipc	a2,0x5
    80001194:	e7060613          	addi	a2,a2,-400 # 80006000 <_trampoline>
    80001198:	040005b7          	lui	a1,0x4000
    8000119c:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000119e:	05b2                	slli	a1,a1,0xc
    800011a0:	8526                	mv	a0,s1
    800011a2:	f3fff0ef          	jal	800010e0 <kvmmap>
  proc_mapstacks(kpgtbl);
    800011a6:	8526                	mv	a0,s1
    800011a8:	5ee000ef          	jal	80001796 <proc_mapstacks>
}
    800011ac:	8526                	mv	a0,s1
    800011ae:	60e2                	ld	ra,24(sp)
    800011b0:	6442                	ld	s0,16(sp)
    800011b2:	64a2                	ld	s1,8(sp)
    800011b4:	6902                	ld	s2,0(sp)
    800011b6:	6105                	addi	sp,sp,32
    800011b8:	8082                	ret

00000000800011ba <kvminit>:
{
    800011ba:	1141                	addi	sp,sp,-16
    800011bc:	e406                	sd	ra,8(sp)
    800011be:	e022                	sd	s0,0(sp)
    800011c0:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800011c2:	f47ff0ef          	jal	80001108 <kvmmake>
    800011c6:	00006797          	auipc	a5,0x6
    800011ca:	74a7b923          	sd	a0,1874(a5) # 80007918 <kernel_pagetable>
}
    800011ce:	60a2                	ld	ra,8(sp)
    800011d0:	6402                	ld	s0,0(sp)
    800011d2:	0141                	addi	sp,sp,16
    800011d4:	8082                	ret

00000000800011d6 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800011d6:	1101                	addi	sp,sp,-32
    800011d8:	ec06                	sd	ra,24(sp)
    800011da:	e822                	sd	s0,16(sp)
    800011dc:	e426                	sd	s1,8(sp)
    800011de:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    800011e0:	91fff0ef          	jal	80000afe <kalloc>
    800011e4:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800011e6:	c509                	beqz	a0,800011f0 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800011e8:	6605                	lui	a2,0x1
    800011ea:	4581                	li	a1,0
    800011ec:	af9ff0ef          	jal	80000ce4 <memset>
  return pagetable;
}
    800011f0:	8526                	mv	a0,s1
    800011f2:	60e2                	ld	ra,24(sp)
    800011f4:	6442                	ld	s0,16(sp)
    800011f6:	64a2                	ld	s1,8(sp)
    800011f8:	6105                	addi	sp,sp,32
    800011fa:	8082                	ret

00000000800011fc <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800011fc:	7139                	addi	sp,sp,-64
    800011fe:	fc06                	sd	ra,56(sp)
    80001200:	f822                	sd	s0,48(sp)
    80001202:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001204:	03459793          	slli	a5,a1,0x34
    80001208:	e38d                	bnez	a5,8000122a <uvmunmap+0x2e>
    8000120a:	f04a                	sd	s2,32(sp)
    8000120c:	ec4e                	sd	s3,24(sp)
    8000120e:	e852                	sd	s4,16(sp)
    80001210:	e456                	sd	s5,8(sp)
    80001212:	e05a                	sd	s6,0(sp)
    80001214:	8a2a                	mv	s4,a0
    80001216:	892e                	mv	s2,a1
    80001218:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000121a:	0632                	slli	a2,a2,0xc
    8000121c:	00b609b3          	add	s3,a2,a1
    80001220:	6b05                	lui	s6,0x1
    80001222:	0535f963          	bgeu	a1,s3,80001274 <uvmunmap+0x78>
    80001226:	f426                	sd	s1,40(sp)
    80001228:	a015                	j	8000124c <uvmunmap+0x50>
    8000122a:	f426                	sd	s1,40(sp)
    8000122c:	f04a                	sd	s2,32(sp)
    8000122e:	ec4e                	sd	s3,24(sp)
    80001230:	e852                	sd	s4,16(sp)
    80001232:	e456                	sd	s5,8(sp)
    80001234:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    80001236:	00006517          	auipc	a0,0x6
    8000123a:	eea50513          	addi	a0,a0,-278 # 80007120 <etext+0x120>
    8000123e:	da2ff0ef          	jal	800007e0 <panic>
      continue;
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    80001242:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001246:	995a                	add	s2,s2,s6
    80001248:	03397563          	bgeu	s2,s3,80001272 <uvmunmap+0x76>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    8000124c:	4601                	li	a2,0
    8000124e:	85ca                	mv	a1,s2
    80001250:	8552                	mv	a0,s4
    80001252:	d07ff0ef          	jal	80000f58 <walk>
    80001256:	84aa                	mv	s1,a0
    80001258:	d57d                	beqz	a0,80001246 <uvmunmap+0x4a>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    8000125a:	611c                	ld	a5,0(a0)
    8000125c:	0017f713          	andi	a4,a5,1
    80001260:	d37d                	beqz	a4,80001246 <uvmunmap+0x4a>
    if(do_free){
    80001262:	fe0a80e3          	beqz	s5,80001242 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    80001266:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    80001268:	00c79513          	slli	a0,a5,0xc
    8000126c:	fb0ff0ef          	jal	80000a1c <kfree>
    80001270:	bfc9                	j	80001242 <uvmunmap+0x46>
    80001272:	74a2                	ld	s1,40(sp)
    80001274:	7902                	ld	s2,32(sp)
    80001276:	69e2                	ld	s3,24(sp)
    80001278:	6a42                	ld	s4,16(sp)
    8000127a:	6aa2                	ld	s5,8(sp)
    8000127c:	6b02                	ld	s6,0(sp)
  }
}
    8000127e:	70e2                	ld	ra,56(sp)
    80001280:	7442                	ld	s0,48(sp)
    80001282:	6121                	addi	sp,sp,64
    80001284:	8082                	ret

0000000080001286 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    80001286:	1101                	addi	sp,sp,-32
    80001288:	ec06                	sd	ra,24(sp)
    8000128a:	e822                	sd	s0,16(sp)
    8000128c:	e426                	sd	s1,8(sp)
    8000128e:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    80001290:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    80001292:	00b67d63          	bgeu	a2,a1,800012ac <uvmdealloc+0x26>
    80001296:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80001298:	6785                	lui	a5,0x1
    8000129a:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000129c:	00f60733          	add	a4,a2,a5
    800012a0:	76fd                	lui	a3,0xfffff
    800012a2:	8f75                	and	a4,a4,a3
    800012a4:	97ae                	add	a5,a5,a1
    800012a6:	8ff5                	and	a5,a5,a3
    800012a8:	00f76863          	bltu	a4,a5,800012b8 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800012ac:	8526                	mv	a0,s1
    800012ae:	60e2                	ld	ra,24(sp)
    800012b0:	6442                	ld	s0,16(sp)
    800012b2:	64a2                	ld	s1,8(sp)
    800012b4:	6105                	addi	sp,sp,32
    800012b6:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800012b8:	8f99                	sub	a5,a5,a4
    800012ba:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800012bc:	4685                	li	a3,1
    800012be:	0007861b          	sext.w	a2,a5
    800012c2:	85ba                	mv	a1,a4
    800012c4:	f39ff0ef          	jal	800011fc <uvmunmap>
    800012c8:	b7d5                	j	800012ac <uvmdealloc+0x26>

00000000800012ca <uvmalloc>:
  if(newsz < oldsz)
    800012ca:	08b66f63          	bltu	a2,a1,80001368 <uvmalloc+0x9e>
{
    800012ce:	7139                	addi	sp,sp,-64
    800012d0:	fc06                	sd	ra,56(sp)
    800012d2:	f822                	sd	s0,48(sp)
    800012d4:	ec4e                	sd	s3,24(sp)
    800012d6:	e852                	sd	s4,16(sp)
    800012d8:	e456                	sd	s5,8(sp)
    800012da:	0080                	addi	s0,sp,64
    800012dc:	8aaa                	mv	s5,a0
    800012de:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800012e0:	6785                	lui	a5,0x1
    800012e2:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012e4:	95be                	add	a1,a1,a5
    800012e6:	77fd                	lui	a5,0xfffff
    800012e8:	00f5f9b3          	and	s3,a1,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    800012ec:	08c9f063          	bgeu	s3,a2,8000136c <uvmalloc+0xa2>
    800012f0:	f426                	sd	s1,40(sp)
    800012f2:	f04a                	sd	s2,32(sp)
    800012f4:	e05a                	sd	s6,0(sp)
    800012f6:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800012f8:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800012fc:	803ff0ef          	jal	80000afe <kalloc>
    80001300:	84aa                	mv	s1,a0
    if(mem == 0){
    80001302:	c515                	beqz	a0,8000132e <uvmalloc+0x64>
    memset(mem, 0, PGSIZE);
    80001304:	6605                	lui	a2,0x1
    80001306:	4581                	li	a1,0
    80001308:	9ddff0ef          	jal	80000ce4 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000130c:	875a                	mv	a4,s6
    8000130e:	86a6                	mv	a3,s1
    80001310:	6605                	lui	a2,0x1
    80001312:	85ca                	mv	a1,s2
    80001314:	8556                	mv	a0,s5
    80001316:	d1bff0ef          	jal	80001030 <mappages>
    8000131a:	e915                	bnez	a0,8000134e <uvmalloc+0x84>
  for(a = oldsz; a < newsz; a += PGSIZE){
    8000131c:	6785                	lui	a5,0x1
    8000131e:	993e                	add	s2,s2,a5
    80001320:	fd496ee3          	bltu	s2,s4,800012fc <uvmalloc+0x32>
  return newsz;
    80001324:	8552                	mv	a0,s4
    80001326:	74a2                	ld	s1,40(sp)
    80001328:	7902                	ld	s2,32(sp)
    8000132a:	6b02                	ld	s6,0(sp)
    8000132c:	a811                	j	80001340 <uvmalloc+0x76>
      uvmdealloc(pagetable, a, oldsz);
    8000132e:	864e                	mv	a2,s3
    80001330:	85ca                	mv	a1,s2
    80001332:	8556                	mv	a0,s5
    80001334:	f53ff0ef          	jal	80001286 <uvmdealloc>
      return 0;
    80001338:	4501                	li	a0,0
    8000133a:	74a2                	ld	s1,40(sp)
    8000133c:	7902                	ld	s2,32(sp)
    8000133e:	6b02                	ld	s6,0(sp)
}
    80001340:	70e2                	ld	ra,56(sp)
    80001342:	7442                	ld	s0,48(sp)
    80001344:	69e2                	ld	s3,24(sp)
    80001346:	6a42                	ld	s4,16(sp)
    80001348:	6aa2                	ld	s5,8(sp)
    8000134a:	6121                	addi	sp,sp,64
    8000134c:	8082                	ret
      kfree(mem);
    8000134e:	8526                	mv	a0,s1
    80001350:	eccff0ef          	jal	80000a1c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001354:	864e                	mv	a2,s3
    80001356:	85ca                	mv	a1,s2
    80001358:	8556                	mv	a0,s5
    8000135a:	f2dff0ef          	jal	80001286 <uvmdealloc>
      return 0;
    8000135e:	4501                	li	a0,0
    80001360:	74a2                	ld	s1,40(sp)
    80001362:	7902                	ld	s2,32(sp)
    80001364:	6b02                	ld	s6,0(sp)
    80001366:	bfe9                	j	80001340 <uvmalloc+0x76>
    return oldsz;
    80001368:	852e                	mv	a0,a1
}
    8000136a:	8082                	ret
  return newsz;
    8000136c:	8532                	mv	a0,a2
    8000136e:	bfc9                	j	80001340 <uvmalloc+0x76>

0000000080001370 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    80001370:	7179                	addi	sp,sp,-48
    80001372:	f406                	sd	ra,40(sp)
    80001374:	f022                	sd	s0,32(sp)
    80001376:	ec26                	sd	s1,24(sp)
    80001378:	e84a                	sd	s2,16(sp)
    8000137a:	e44e                	sd	s3,8(sp)
    8000137c:	e052                	sd	s4,0(sp)
    8000137e:	1800                	addi	s0,sp,48
    80001380:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    80001382:	84aa                	mv	s1,a0
    80001384:	6905                	lui	s2,0x1
    80001386:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001388:	4985                	li	s3,1
    8000138a:	a819                	j	800013a0 <freewalk+0x30>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    8000138c:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    8000138e:	00c79513          	slli	a0,a5,0xc
    80001392:	fdfff0ef          	jal	80001370 <freewalk>
      pagetable[i] = 0;
    80001396:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    8000139a:	04a1                	addi	s1,s1,8
    8000139c:	01248f63          	beq	s1,s2,800013ba <freewalk+0x4a>
    pte_t pte = pagetable[i];
    800013a0:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800013a2:	00f7f713          	andi	a4,a5,15
    800013a6:	ff3703e3          	beq	a4,s3,8000138c <freewalk+0x1c>
    } else if(pte & PTE_V){
    800013aa:	8b85                	andi	a5,a5,1
    800013ac:	d7fd                	beqz	a5,8000139a <freewalk+0x2a>
      panic("freewalk: leaf");
    800013ae:	00006517          	auipc	a0,0x6
    800013b2:	d8a50513          	addi	a0,a0,-630 # 80007138 <etext+0x138>
    800013b6:	c2aff0ef          	jal	800007e0 <panic>
    }
  }
  kfree((void*)pagetable);
    800013ba:	8552                	mv	a0,s4
    800013bc:	e60ff0ef          	jal	80000a1c <kfree>
}
    800013c0:	70a2                	ld	ra,40(sp)
    800013c2:	7402                	ld	s0,32(sp)
    800013c4:	64e2                	ld	s1,24(sp)
    800013c6:	6942                	ld	s2,16(sp)
    800013c8:	69a2                	ld	s3,8(sp)
    800013ca:	6a02                	ld	s4,0(sp)
    800013cc:	6145                	addi	sp,sp,48
    800013ce:	8082                	ret

00000000800013d0 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800013d0:	1101                	addi	sp,sp,-32
    800013d2:	ec06                	sd	ra,24(sp)
    800013d4:	e822                	sd	s0,16(sp)
    800013d6:	e426                	sd	s1,8(sp)
    800013d8:	1000                	addi	s0,sp,32
    800013da:	84aa                	mv	s1,a0
  if(sz > 0)
    800013dc:	e989                	bnez	a1,800013ee <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    800013de:	8526                	mv	a0,s1
    800013e0:	f91ff0ef          	jal	80001370 <freewalk>
}
    800013e4:	60e2                	ld	ra,24(sp)
    800013e6:	6442                	ld	s0,16(sp)
    800013e8:	64a2                	ld	s1,8(sp)
    800013ea:	6105                	addi	sp,sp,32
    800013ec:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800013ee:	6785                	lui	a5,0x1
    800013f0:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800013f2:	95be                	add	a1,a1,a5
    800013f4:	4685                	li	a3,1
    800013f6:	00c5d613          	srli	a2,a1,0xc
    800013fa:	4581                	li	a1,0
    800013fc:	e01ff0ef          	jal	800011fc <uvmunmap>
    80001400:	bff9                	j	800013de <uvmfree+0xe>

0000000080001402 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    80001402:	ce49                	beqz	a2,8000149c <uvmcopy+0x9a>
{
    80001404:	715d                	addi	sp,sp,-80
    80001406:	e486                	sd	ra,72(sp)
    80001408:	e0a2                	sd	s0,64(sp)
    8000140a:	fc26                	sd	s1,56(sp)
    8000140c:	f84a                	sd	s2,48(sp)
    8000140e:	f44e                	sd	s3,40(sp)
    80001410:	f052                	sd	s4,32(sp)
    80001412:	ec56                	sd	s5,24(sp)
    80001414:	e85a                	sd	s6,16(sp)
    80001416:	e45e                	sd	s7,8(sp)
    80001418:	0880                	addi	s0,sp,80
    8000141a:	8aaa                	mv	s5,a0
    8000141c:	8b2e                	mv	s6,a1
    8000141e:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    80001420:	4481                	li	s1,0
    80001422:	a029                	j	8000142c <uvmcopy+0x2a>
    80001424:	6785                	lui	a5,0x1
    80001426:	94be                	add	s1,s1,a5
    80001428:	0544fe63          	bgeu	s1,s4,80001484 <uvmcopy+0x82>
    if((pte = walk(old, i, 0)) == 0)
    8000142c:	4601                	li	a2,0
    8000142e:	85a6                	mv	a1,s1
    80001430:	8556                	mv	a0,s5
    80001432:	b27ff0ef          	jal	80000f58 <walk>
    80001436:	d57d                	beqz	a0,80001424 <uvmcopy+0x22>
      continue;   // page table entry hasn't been allocated
    if((*pte & PTE_V) == 0)
    80001438:	6118                	ld	a4,0(a0)
    8000143a:	00177793          	andi	a5,a4,1
    8000143e:	d3fd                	beqz	a5,80001424 <uvmcopy+0x22>
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    80001440:	00a75593          	srli	a1,a4,0xa
    80001444:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    80001448:	3ff77913          	andi	s2,a4,1023
    if((mem = kalloc()) == 0)
    8000144c:	eb2ff0ef          	jal	80000afe <kalloc>
    80001450:	89aa                	mv	s3,a0
    80001452:	c105                	beqz	a0,80001472 <uvmcopy+0x70>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80001454:	6605                	lui	a2,0x1
    80001456:	85de                	mv	a1,s7
    80001458:	8e9ff0ef          	jal	80000d40 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    8000145c:	874a                	mv	a4,s2
    8000145e:	86ce                	mv	a3,s3
    80001460:	6605                	lui	a2,0x1
    80001462:	85a6                	mv	a1,s1
    80001464:	855a                	mv	a0,s6
    80001466:	bcbff0ef          	jal	80001030 <mappages>
    8000146a:	dd4d                	beqz	a0,80001424 <uvmcopy+0x22>
      kfree(mem);
    8000146c:	854e                	mv	a0,s3
    8000146e:	daeff0ef          	jal	80000a1c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80001472:	4685                	li	a3,1
    80001474:	00c4d613          	srli	a2,s1,0xc
    80001478:	4581                	li	a1,0
    8000147a:	855a                	mv	a0,s6
    8000147c:	d81ff0ef          	jal	800011fc <uvmunmap>
  return -1;
    80001480:	557d                	li	a0,-1
    80001482:	a011                	j	80001486 <uvmcopy+0x84>
  return 0;
    80001484:	4501                	li	a0,0
}
    80001486:	60a6                	ld	ra,72(sp)
    80001488:	6406                	ld	s0,64(sp)
    8000148a:	74e2                	ld	s1,56(sp)
    8000148c:	7942                	ld	s2,48(sp)
    8000148e:	79a2                	ld	s3,40(sp)
    80001490:	7a02                	ld	s4,32(sp)
    80001492:	6ae2                	ld	s5,24(sp)
    80001494:	6b42                	ld	s6,16(sp)
    80001496:	6ba2                	ld	s7,8(sp)
    80001498:	6161                	addi	sp,sp,80
    8000149a:	8082                	ret
  return 0;
    8000149c:	4501                	li	a0,0
}
    8000149e:	8082                	ret

00000000800014a0 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800014a0:	1141                	addi	sp,sp,-16
    800014a2:	e406                	sd	ra,8(sp)
    800014a4:	e022                	sd	s0,0(sp)
    800014a6:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800014a8:	4601                	li	a2,0
    800014aa:	aafff0ef          	jal	80000f58 <walk>
  if(pte == 0)
    800014ae:	c901                	beqz	a0,800014be <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800014b0:	611c                	ld	a5,0(a0)
    800014b2:	9bbd                	andi	a5,a5,-17
    800014b4:	e11c                	sd	a5,0(a0)
}
    800014b6:	60a2                	ld	ra,8(sp)
    800014b8:	6402                	ld	s0,0(sp)
    800014ba:	0141                	addi	sp,sp,16
    800014bc:	8082                	ret
    panic("uvmclear");
    800014be:	00006517          	auipc	a0,0x6
    800014c2:	c8a50513          	addi	a0,a0,-886 # 80007148 <etext+0x148>
    800014c6:	b1aff0ef          	jal	800007e0 <panic>

00000000800014ca <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800014ca:	c6dd                	beqz	a3,80001578 <copyinstr+0xae>
{
    800014cc:	715d                	addi	sp,sp,-80
    800014ce:	e486                	sd	ra,72(sp)
    800014d0:	e0a2                	sd	s0,64(sp)
    800014d2:	fc26                	sd	s1,56(sp)
    800014d4:	f84a                	sd	s2,48(sp)
    800014d6:	f44e                	sd	s3,40(sp)
    800014d8:	f052                	sd	s4,32(sp)
    800014da:	ec56                	sd	s5,24(sp)
    800014dc:	e85a                	sd	s6,16(sp)
    800014de:	e45e                	sd	s7,8(sp)
    800014e0:	0880                	addi	s0,sp,80
    800014e2:	8a2a                	mv	s4,a0
    800014e4:	8b2e                	mv	s6,a1
    800014e6:	8bb2                	mv	s7,a2
    800014e8:	8936                	mv	s2,a3
    va0 = PGROUNDDOWN(srcva);
    800014ea:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    800014ec:	6985                	lui	s3,0x1
    800014ee:	a825                	j	80001526 <copyinstr+0x5c>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    800014f0:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    800014f4:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    800014f6:	37fd                	addiw	a5,a5,-1
    800014f8:	0007851b          	sext.w	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    800014fc:	60a6                	ld	ra,72(sp)
    800014fe:	6406                	ld	s0,64(sp)
    80001500:	74e2                	ld	s1,56(sp)
    80001502:	7942                	ld	s2,48(sp)
    80001504:	79a2                	ld	s3,40(sp)
    80001506:	7a02                	ld	s4,32(sp)
    80001508:	6ae2                	ld	s5,24(sp)
    8000150a:	6b42                	ld	s6,16(sp)
    8000150c:	6ba2                	ld	s7,8(sp)
    8000150e:	6161                	addi	sp,sp,80
    80001510:	8082                	ret
    80001512:	fff90713          	addi	a4,s2,-1 # fff <_entry-0x7ffff001>
    80001516:	9742                	add	a4,a4,a6
      --max;
    80001518:	40b70933          	sub	s2,a4,a1
    srcva = va0 + PGSIZE;
    8000151c:	01348bb3          	add	s7,s1,s3
  while(got_null == 0 && max > 0){
    80001520:	04e58463          	beq	a1,a4,80001568 <copyinstr+0x9e>
{
    80001524:	8b3e                	mv	s6,a5
    va0 = PGROUNDDOWN(srcva);
    80001526:	015bf4b3          	and	s1,s7,s5
    pa0 = walkaddr(pagetable, va0);
    8000152a:	85a6                	mv	a1,s1
    8000152c:	8552                	mv	a0,s4
    8000152e:	ac5ff0ef          	jal	80000ff2 <walkaddr>
    if(pa0 == 0)
    80001532:	cd0d                	beqz	a0,8000156c <copyinstr+0xa2>
    n = PGSIZE - (srcva - va0);
    80001534:	417486b3          	sub	a3,s1,s7
    80001538:	96ce                	add	a3,a3,s3
    if(n > max)
    8000153a:	00d97363          	bgeu	s2,a3,80001540 <copyinstr+0x76>
    8000153e:	86ca                	mv	a3,s2
    char *p = (char *) (pa0 + (srcva - va0));
    80001540:	955e                	add	a0,a0,s7
    80001542:	8d05                	sub	a0,a0,s1
    while(n > 0){
    80001544:	c695                	beqz	a3,80001570 <copyinstr+0xa6>
    80001546:	87da                	mv	a5,s6
    80001548:	885a                	mv	a6,s6
      if(*p == '\0'){
    8000154a:	41650633          	sub	a2,a0,s6
    while(n > 0){
    8000154e:	96da                	add	a3,a3,s6
    80001550:	85be                	mv	a1,a5
      if(*p == '\0'){
    80001552:	00f60733          	add	a4,a2,a5
    80001556:	00074703          	lbu	a4,0(a4)
    8000155a:	db59                	beqz	a4,800014f0 <copyinstr+0x26>
        *dst = *p;
    8000155c:	00e78023          	sb	a4,0(a5)
      dst++;
    80001560:	0785                	addi	a5,a5,1
    while(n > 0){
    80001562:	fed797e3          	bne	a5,a3,80001550 <copyinstr+0x86>
    80001566:	b775                	j	80001512 <copyinstr+0x48>
    80001568:	4781                	li	a5,0
    8000156a:	b771                	j	800014f6 <copyinstr+0x2c>
      return -1;
    8000156c:	557d                	li	a0,-1
    8000156e:	b779                	j	800014fc <copyinstr+0x32>
    srcva = va0 + PGSIZE;
    80001570:	6b85                	lui	s7,0x1
    80001572:	9ba6                	add	s7,s7,s1
    80001574:	87da                	mv	a5,s6
    80001576:	b77d                	j	80001524 <copyinstr+0x5a>
  int got_null = 0;
    80001578:	4781                	li	a5,0
  if(got_null){
    8000157a:	37fd                	addiw	a5,a5,-1
    8000157c:	0007851b          	sext.w	a0,a5
}
    80001580:	8082                	ret

0000000080001582 <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    80001582:	1141                	addi	sp,sp,-16
    80001584:	e406                	sd	ra,8(sp)
    80001586:	e022                	sd	s0,0(sp)
    80001588:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    8000158a:	4601                	li	a2,0
    8000158c:	9cdff0ef          	jal	80000f58 <walk>
  if (pte == 0) {
    80001590:	c519                	beqz	a0,8000159e <ismapped+0x1c>
    return 0;
  }
  if (*pte & PTE_V){
    80001592:	6108                	ld	a0,0(a0)
    80001594:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    80001596:	60a2                	ld	ra,8(sp)
    80001598:	6402                	ld	s0,0(sp)
    8000159a:	0141                	addi	sp,sp,16
    8000159c:	8082                	ret
    return 0;
    8000159e:	4501                	li	a0,0
    800015a0:	bfdd                	j	80001596 <ismapped+0x14>

00000000800015a2 <vmfault>:
{
    800015a2:	7179                	addi	sp,sp,-48
    800015a4:	f406                	sd	ra,40(sp)
    800015a6:	f022                	sd	s0,32(sp)
    800015a8:	ec26                	sd	s1,24(sp)
    800015aa:	e44e                	sd	s3,8(sp)
    800015ac:	1800                	addi	s0,sp,48
    800015ae:	89aa                	mv	s3,a0
    800015b0:	84ae                	mv	s1,a1
  struct proc *p = myproc();
    800015b2:	35e000ef          	jal	80001910 <myproc>
  if (va >= p->sz)
    800015b6:	653c                	ld	a5,72(a0)
    800015b8:	00f4ea63          	bltu	s1,a5,800015cc <vmfault+0x2a>
    return 0;
    800015bc:	4981                	li	s3,0
}
    800015be:	854e                	mv	a0,s3
    800015c0:	70a2                	ld	ra,40(sp)
    800015c2:	7402                	ld	s0,32(sp)
    800015c4:	64e2                	ld	s1,24(sp)
    800015c6:	69a2                	ld	s3,8(sp)
    800015c8:	6145                	addi	sp,sp,48
    800015ca:	8082                	ret
    800015cc:	e84a                	sd	s2,16(sp)
    800015ce:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    800015d0:	77fd                	lui	a5,0xfffff
    800015d2:	8cfd                	and	s1,s1,a5
  if(ismapped(pagetable, va)) {
    800015d4:	85a6                	mv	a1,s1
    800015d6:	854e                	mv	a0,s3
    800015d8:	fabff0ef          	jal	80001582 <ismapped>
    return 0;
    800015dc:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    800015de:	c119                	beqz	a0,800015e4 <vmfault+0x42>
    800015e0:	6942                	ld	s2,16(sp)
    800015e2:	bff1                	j	800015be <vmfault+0x1c>
    800015e4:	e052                	sd	s4,0(sp)
  mem = (uint64) kalloc();
    800015e6:	d18ff0ef          	jal	80000afe <kalloc>
    800015ea:	8a2a                	mv	s4,a0
  if(mem == 0)
    800015ec:	c90d                	beqz	a0,8000161e <vmfault+0x7c>
  mem = (uint64) kalloc();
    800015ee:	89aa                	mv	s3,a0
  memset((void *) mem, 0, PGSIZE);
    800015f0:	6605                	lui	a2,0x1
    800015f2:	4581                	li	a1,0
    800015f4:	ef0ff0ef          	jal	80000ce4 <memset>
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    800015f8:	4759                	li	a4,22
    800015fa:	86d2                	mv	a3,s4
    800015fc:	6605                	lui	a2,0x1
    800015fe:	85a6                	mv	a1,s1
    80001600:	05093503          	ld	a0,80(s2)
    80001604:	a2dff0ef          	jal	80001030 <mappages>
    80001608:	e501                	bnez	a0,80001610 <vmfault+0x6e>
    8000160a:	6942                	ld	s2,16(sp)
    8000160c:	6a02                	ld	s4,0(sp)
    8000160e:	bf45                	j	800015be <vmfault+0x1c>
    kfree((void *)mem);
    80001610:	8552                	mv	a0,s4
    80001612:	c0aff0ef          	jal	80000a1c <kfree>
    return 0;
    80001616:	4981                	li	s3,0
    80001618:	6942                	ld	s2,16(sp)
    8000161a:	6a02                	ld	s4,0(sp)
    8000161c:	b74d                	j	800015be <vmfault+0x1c>
    8000161e:	6942                	ld	s2,16(sp)
    80001620:	6a02                	ld	s4,0(sp)
    80001622:	bf71                	j	800015be <vmfault+0x1c>

0000000080001624 <copyout>:
  while(len > 0){
    80001624:	c2cd                	beqz	a3,800016c6 <copyout+0xa2>
{
    80001626:	711d                	addi	sp,sp,-96
    80001628:	ec86                	sd	ra,88(sp)
    8000162a:	e8a2                	sd	s0,80(sp)
    8000162c:	e4a6                	sd	s1,72(sp)
    8000162e:	f852                	sd	s4,48(sp)
    80001630:	f05a                	sd	s6,32(sp)
    80001632:	ec5e                	sd	s7,24(sp)
    80001634:	e862                	sd	s8,16(sp)
    80001636:	1080                	addi	s0,sp,96
    80001638:	8c2a                	mv	s8,a0
    8000163a:	8b2e                	mv	s6,a1
    8000163c:	8bb2                	mv	s7,a2
    8000163e:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    80001640:	74fd                	lui	s1,0xfffff
    80001642:	8ced                	and	s1,s1,a1
    if(va0 >= MAXVA)
    80001644:	57fd                	li	a5,-1
    80001646:	83e9                	srli	a5,a5,0x1a
    80001648:	0897e163          	bltu	a5,s1,800016ca <copyout+0xa6>
    8000164c:	e0ca                	sd	s2,64(sp)
    8000164e:	fc4e                	sd	s3,56(sp)
    80001650:	f456                	sd	s5,40(sp)
    80001652:	e466                	sd	s9,8(sp)
    80001654:	e06a                	sd	s10,0(sp)
    80001656:	6d05                	lui	s10,0x1
    80001658:	8cbe                	mv	s9,a5
    8000165a:	a015                	j	8000167e <copyout+0x5a>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    8000165c:	409b0533          	sub	a0,s6,s1
    80001660:	0009861b          	sext.w	a2,s3
    80001664:	85de                	mv	a1,s7
    80001666:	954a                	add	a0,a0,s2
    80001668:	ed8ff0ef          	jal	80000d40 <memmove>
    len -= n;
    8000166c:	413a0a33          	sub	s4,s4,s3
    src += n;
    80001670:	9bce                	add	s7,s7,s3
  while(len > 0){
    80001672:	040a0363          	beqz	s4,800016b8 <copyout+0x94>
    if(va0 >= MAXVA)
    80001676:	055cec63          	bltu	s9,s5,800016ce <copyout+0xaa>
    8000167a:	84d6                	mv	s1,s5
    8000167c:	8b56                	mv	s6,s5
    pa0 = walkaddr(pagetable, va0);
    8000167e:	85a6                	mv	a1,s1
    80001680:	8562                	mv	a0,s8
    80001682:	971ff0ef          	jal	80000ff2 <walkaddr>
    80001686:	892a                	mv	s2,a0
    if(pa0 == 0) {
    80001688:	e901                	bnez	a0,80001698 <copyout+0x74>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    8000168a:	4601                	li	a2,0
    8000168c:	85a6                	mv	a1,s1
    8000168e:	8562                	mv	a0,s8
    80001690:	f13ff0ef          	jal	800015a2 <vmfault>
    80001694:	892a                	mv	s2,a0
    80001696:	c139                	beqz	a0,800016dc <copyout+0xb8>
    pte = walk(pagetable, va0, 0);
    80001698:	4601                	li	a2,0
    8000169a:	85a6                	mv	a1,s1
    8000169c:	8562                	mv	a0,s8
    8000169e:	8bbff0ef          	jal	80000f58 <walk>
    if((*pte & PTE_W) == 0)
    800016a2:	611c                	ld	a5,0(a0)
    800016a4:	8b91                	andi	a5,a5,4
    800016a6:	c3b1                	beqz	a5,800016ea <copyout+0xc6>
    n = PGSIZE - (dstva - va0);
    800016a8:	01a48ab3          	add	s5,s1,s10
    800016ac:	416a89b3          	sub	s3,s5,s6
    if(n > len)
    800016b0:	fb3a76e3          	bgeu	s4,s3,8000165c <copyout+0x38>
    800016b4:	89d2                	mv	s3,s4
    800016b6:	b75d                	j	8000165c <copyout+0x38>
  return 0;
    800016b8:	4501                	li	a0,0
    800016ba:	6906                	ld	s2,64(sp)
    800016bc:	79e2                	ld	s3,56(sp)
    800016be:	7aa2                	ld	s5,40(sp)
    800016c0:	6ca2                	ld	s9,8(sp)
    800016c2:	6d02                	ld	s10,0(sp)
    800016c4:	a80d                	j	800016f6 <copyout+0xd2>
    800016c6:	4501                	li	a0,0
}
    800016c8:	8082                	ret
      return -1;
    800016ca:	557d                	li	a0,-1
    800016cc:	a02d                	j	800016f6 <copyout+0xd2>
    800016ce:	557d                	li	a0,-1
    800016d0:	6906                	ld	s2,64(sp)
    800016d2:	79e2                	ld	s3,56(sp)
    800016d4:	7aa2                	ld	s5,40(sp)
    800016d6:	6ca2                	ld	s9,8(sp)
    800016d8:	6d02                	ld	s10,0(sp)
    800016da:	a831                	j	800016f6 <copyout+0xd2>
        return -1;
    800016dc:	557d                	li	a0,-1
    800016de:	6906                	ld	s2,64(sp)
    800016e0:	79e2                	ld	s3,56(sp)
    800016e2:	7aa2                	ld	s5,40(sp)
    800016e4:	6ca2                	ld	s9,8(sp)
    800016e6:	6d02                	ld	s10,0(sp)
    800016e8:	a039                	j	800016f6 <copyout+0xd2>
      return -1;
    800016ea:	557d                	li	a0,-1
    800016ec:	6906                	ld	s2,64(sp)
    800016ee:	79e2                	ld	s3,56(sp)
    800016f0:	7aa2                	ld	s5,40(sp)
    800016f2:	6ca2                	ld	s9,8(sp)
    800016f4:	6d02                	ld	s10,0(sp)
}
    800016f6:	60e6                	ld	ra,88(sp)
    800016f8:	6446                	ld	s0,80(sp)
    800016fa:	64a6                	ld	s1,72(sp)
    800016fc:	7a42                	ld	s4,48(sp)
    800016fe:	7b02                	ld	s6,32(sp)
    80001700:	6be2                	ld	s7,24(sp)
    80001702:	6c42                	ld	s8,16(sp)
    80001704:	6125                	addi	sp,sp,96
    80001706:	8082                	ret

0000000080001708 <copyin>:
  while(len > 0){
    80001708:	c6c9                	beqz	a3,80001792 <copyin+0x8a>
{
    8000170a:	715d                	addi	sp,sp,-80
    8000170c:	e486                	sd	ra,72(sp)
    8000170e:	e0a2                	sd	s0,64(sp)
    80001710:	fc26                	sd	s1,56(sp)
    80001712:	f84a                	sd	s2,48(sp)
    80001714:	f44e                	sd	s3,40(sp)
    80001716:	f052                	sd	s4,32(sp)
    80001718:	ec56                	sd	s5,24(sp)
    8000171a:	e85a                	sd	s6,16(sp)
    8000171c:	e45e                	sd	s7,8(sp)
    8000171e:	e062                	sd	s8,0(sp)
    80001720:	0880                	addi	s0,sp,80
    80001722:	8baa                	mv	s7,a0
    80001724:	8aae                	mv	s5,a1
    80001726:	8932                	mv	s2,a2
    80001728:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    8000172a:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    8000172c:	6b05                	lui	s6,0x1
    8000172e:	a035                	j	8000175a <copyin+0x52>
    80001730:	412984b3          	sub	s1,s3,s2
    80001734:	94da                	add	s1,s1,s6
    if(n > len)
    80001736:	009a7363          	bgeu	s4,s1,8000173c <copyin+0x34>
    8000173a:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    8000173c:	413905b3          	sub	a1,s2,s3
    80001740:	0004861b          	sext.w	a2,s1
    80001744:	95aa                	add	a1,a1,a0
    80001746:	8556                	mv	a0,s5
    80001748:	df8ff0ef          	jal	80000d40 <memmove>
    len -= n;
    8000174c:	409a0a33          	sub	s4,s4,s1
    dst += n;
    80001750:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    80001752:	01698933          	add	s2,s3,s6
  while(len > 0){
    80001756:	020a0163          	beqz	s4,80001778 <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    8000175a:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    8000175e:	85ce                	mv	a1,s3
    80001760:	855e                	mv	a0,s7
    80001762:	891ff0ef          	jal	80000ff2 <walkaddr>
    if(pa0 == 0) {
    80001766:	f569                	bnez	a0,80001730 <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001768:	4601                	li	a2,0
    8000176a:	85ce                	mv	a1,s3
    8000176c:	855e                	mv	a0,s7
    8000176e:	e35ff0ef          	jal	800015a2 <vmfault>
    80001772:	fd5d                	bnez	a0,80001730 <copyin+0x28>
        return -1;
    80001774:	557d                	li	a0,-1
    80001776:	a011                	j	8000177a <copyin+0x72>
  return 0;
    80001778:	4501                	li	a0,0
}
    8000177a:	60a6                	ld	ra,72(sp)
    8000177c:	6406                	ld	s0,64(sp)
    8000177e:	74e2                	ld	s1,56(sp)
    80001780:	7942                	ld	s2,48(sp)
    80001782:	79a2                	ld	s3,40(sp)
    80001784:	7a02                	ld	s4,32(sp)
    80001786:	6ae2                	ld	s5,24(sp)
    80001788:	6b42                	ld	s6,16(sp)
    8000178a:	6ba2                	ld	s7,8(sp)
    8000178c:	6c02                	ld	s8,0(sp)
    8000178e:	6161                	addi	sp,sp,80
    80001790:	8082                	ret
  return 0;
    80001792:	4501                	li	a0,0
}
    80001794:	8082                	ret

0000000080001796 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001796:	7139                	addi	sp,sp,-64
    80001798:	fc06                	sd	ra,56(sp)
    8000179a:	f822                	sd	s0,48(sp)
    8000179c:	f426                	sd	s1,40(sp)
    8000179e:	f04a                	sd	s2,32(sp)
    800017a0:	ec4e                	sd	s3,24(sp)
    800017a2:	e852                	sd	s4,16(sp)
    800017a4:	e456                	sd	s5,8(sp)
    800017a6:	e05a                	sd	s6,0(sp)
    800017a8:	0080                	addi	s0,sp,64
    800017aa:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    800017ac:	0000e497          	auipc	s1,0xe
    800017b0:	6ac48493          	addi	s1,s1,1708 # 8000fe58 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    800017b4:	8b26                	mv	s6,s1
    800017b6:	04fa5937          	lui	s2,0x4fa5
    800017ba:	fa590913          	addi	s2,s2,-91 # 4fa4fa5 <_entry-0x7b05b05b>
    800017be:	0932                	slli	s2,s2,0xc
    800017c0:	fa590913          	addi	s2,s2,-91
    800017c4:	0932                	slli	s2,s2,0xc
    800017c6:	fa590913          	addi	s2,s2,-91
    800017ca:	0932                	slli	s2,s2,0xc
    800017cc:	fa590913          	addi	s2,s2,-91
    800017d0:	040009b7          	lui	s3,0x4000
    800017d4:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800017d6:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800017d8:	00014a97          	auipc	s5,0x14
    800017dc:	080a8a93          	addi	s5,s5,128 # 80015858 <tickslock>
    char *pa = kalloc();
    800017e0:	b1eff0ef          	jal	80000afe <kalloc>
    800017e4:	862a                	mv	a2,a0
    if(pa == 0)
    800017e6:	cd15                	beqz	a0,80001822 <proc_mapstacks+0x8c>
    uint64 va = KSTACK((int) (p - proc));
    800017e8:	416485b3          	sub	a1,s1,s6
    800017ec:	858d                	srai	a1,a1,0x3
    800017ee:	032585b3          	mul	a1,a1,s2
    800017f2:	2585                	addiw	a1,a1,1
    800017f4:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017f8:	4719                	li	a4,6
    800017fa:	6685                	lui	a3,0x1
    800017fc:	40b985b3          	sub	a1,s3,a1
    80001800:	8552                	mv	a0,s4
    80001802:	8dfff0ef          	jal	800010e0 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001806:	16848493          	addi	s1,s1,360
    8000180a:	fd549be3          	bne	s1,s5,800017e0 <proc_mapstacks+0x4a>
  }
}
    8000180e:	70e2                	ld	ra,56(sp)
    80001810:	7442                	ld	s0,48(sp)
    80001812:	74a2                	ld	s1,40(sp)
    80001814:	7902                	ld	s2,32(sp)
    80001816:	69e2                	ld	s3,24(sp)
    80001818:	6a42                	ld	s4,16(sp)
    8000181a:	6aa2                	ld	s5,8(sp)
    8000181c:	6b02                	ld	s6,0(sp)
    8000181e:	6121                	addi	sp,sp,64
    80001820:	8082                	ret
      panic("kalloc");
    80001822:	00006517          	auipc	a0,0x6
    80001826:	93650513          	addi	a0,a0,-1738 # 80007158 <etext+0x158>
    8000182a:	fb7fe0ef          	jal	800007e0 <panic>

000000008000182e <procinit>:

// initialize the proc table.
void
procinit(void)
{
    8000182e:	7139                	addi	sp,sp,-64
    80001830:	fc06                	sd	ra,56(sp)
    80001832:	f822                	sd	s0,48(sp)
    80001834:	f426                	sd	s1,40(sp)
    80001836:	f04a                	sd	s2,32(sp)
    80001838:	ec4e                	sd	s3,24(sp)
    8000183a:	e852                	sd	s4,16(sp)
    8000183c:	e456                	sd	s5,8(sp)
    8000183e:	e05a                	sd	s6,0(sp)
    80001840:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001842:	00006597          	auipc	a1,0x6
    80001846:	91e58593          	addi	a1,a1,-1762 # 80007160 <etext+0x160>
    8000184a:	0000e517          	auipc	a0,0xe
    8000184e:	1de50513          	addi	a0,a0,478 # 8000fa28 <pid_lock>
    80001852:	b3eff0ef          	jal	80000b90 <initlock>
  initlock(&wait_lock, "wait_lock");
    80001856:	00006597          	auipc	a1,0x6
    8000185a:	91258593          	addi	a1,a1,-1774 # 80007168 <etext+0x168>
    8000185e:	0000e517          	auipc	a0,0xe
    80001862:	1e250513          	addi	a0,a0,482 # 8000fa40 <wait_lock>
    80001866:	b2aff0ef          	jal	80000b90 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000186a:	0000e497          	auipc	s1,0xe
    8000186e:	5ee48493          	addi	s1,s1,1518 # 8000fe58 <proc>
      initlock(&p->lock, "proc");
    80001872:	00006b17          	auipc	s6,0x6
    80001876:	906b0b13          	addi	s6,s6,-1786 # 80007178 <etext+0x178>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    8000187a:	8aa6                	mv	s5,s1
    8000187c:	04fa5937          	lui	s2,0x4fa5
    80001880:	fa590913          	addi	s2,s2,-91 # 4fa4fa5 <_entry-0x7b05b05b>
    80001884:	0932                	slli	s2,s2,0xc
    80001886:	fa590913          	addi	s2,s2,-91
    8000188a:	0932                	slli	s2,s2,0xc
    8000188c:	fa590913          	addi	s2,s2,-91
    80001890:	0932                	slli	s2,s2,0xc
    80001892:	fa590913          	addi	s2,s2,-91
    80001896:	040009b7          	lui	s3,0x4000
    8000189a:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    8000189c:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    8000189e:	00014a17          	auipc	s4,0x14
    800018a2:	fbaa0a13          	addi	s4,s4,-70 # 80015858 <tickslock>
      initlock(&p->lock, "proc");
    800018a6:	85da                	mv	a1,s6
    800018a8:	8526                	mv	a0,s1
    800018aa:	ae6ff0ef          	jal	80000b90 <initlock>
      p->state = UNUSED;
    800018ae:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    800018b2:	415487b3          	sub	a5,s1,s5
    800018b6:	878d                	srai	a5,a5,0x3
    800018b8:	032787b3          	mul	a5,a5,s2
    800018bc:	2785                	addiw	a5,a5,1 # fffffffffffff001 <end+0xffffffff7ffde3c9>
    800018be:	00d7979b          	slliw	a5,a5,0xd
    800018c2:	40f987b3          	sub	a5,s3,a5
    800018c6:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    800018c8:	16848493          	addi	s1,s1,360
    800018cc:	fd449de3          	bne	s1,s4,800018a6 <procinit+0x78>
  }
}
    800018d0:	70e2                	ld	ra,56(sp)
    800018d2:	7442                	ld	s0,48(sp)
    800018d4:	74a2                	ld	s1,40(sp)
    800018d6:	7902                	ld	s2,32(sp)
    800018d8:	69e2                	ld	s3,24(sp)
    800018da:	6a42                	ld	s4,16(sp)
    800018dc:	6aa2                	ld	s5,8(sp)
    800018de:	6b02                	ld	s6,0(sp)
    800018e0:	6121                	addi	sp,sp,64
    800018e2:	8082                	ret

00000000800018e4 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018e4:	1141                	addi	sp,sp,-16
    800018e6:	e422                	sd	s0,8(sp)
    800018e8:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    800018ea:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800018ec:	2501                	sext.w	a0,a0
    800018ee:	6422                	ld	s0,8(sp)
    800018f0:	0141                	addi	sp,sp,16
    800018f2:	8082                	ret

00000000800018f4 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    800018f4:	1141                	addi	sp,sp,-16
    800018f6:	e422                	sd	s0,8(sp)
    800018f8:	0800                	addi	s0,sp,16
    800018fa:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800018fc:	2781                	sext.w	a5,a5
    800018fe:	079e                	slli	a5,a5,0x7
  return c;
}
    80001900:	0000e517          	auipc	a0,0xe
    80001904:	15850513          	addi	a0,a0,344 # 8000fa58 <cpus>
    80001908:	953e                	add	a0,a0,a5
    8000190a:	6422                	ld	s0,8(sp)
    8000190c:	0141                	addi	sp,sp,16
    8000190e:	8082                	ret

0000000080001910 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001910:	1101                	addi	sp,sp,-32
    80001912:	ec06                	sd	ra,24(sp)
    80001914:	e822                	sd	s0,16(sp)
    80001916:	e426                	sd	s1,8(sp)
    80001918:	1000                	addi	s0,sp,32
  push_off();
    8000191a:	ab6ff0ef          	jal	80000bd0 <push_off>
    8000191e:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001920:	2781                	sext.w	a5,a5
    80001922:	079e                	slli	a5,a5,0x7
    80001924:	0000e717          	auipc	a4,0xe
    80001928:	10470713          	addi	a4,a4,260 # 8000fa28 <pid_lock>
    8000192c:	97ba                	add	a5,a5,a4
    8000192e:	7b84                	ld	s1,48(a5)
  pop_off();
    80001930:	b24ff0ef          	jal	80000c54 <pop_off>
  return p;
}
    80001934:	8526                	mv	a0,s1
    80001936:	60e2                	ld	ra,24(sp)
    80001938:	6442                	ld	s0,16(sp)
    8000193a:	64a2                	ld	s1,8(sp)
    8000193c:	6105                	addi	sp,sp,32
    8000193e:	8082                	ret

0000000080001940 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001940:	7179                	addi	sp,sp,-48
    80001942:	f406                	sd	ra,40(sp)
    80001944:	f022                	sd	s0,32(sp)
    80001946:	ec26                	sd	s1,24(sp)
    80001948:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    8000194a:	fc7ff0ef          	jal	80001910 <myproc>
    8000194e:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001950:	b58ff0ef          	jal	80000ca8 <release>

  if (first) {
    80001954:	00006797          	auipc	a5,0x6
    80001958:	f9c7a783          	lw	a5,-100(a5) # 800078f0 <first.2>
    8000195c:	cf8d                	beqz	a5,80001996 <forkret+0x56>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    8000195e:	4505                	li	a0,1
    80001960:	04c020ef          	jal	800039ac <fsinit>

    first = 0;
    80001964:	00006797          	auipc	a5,0x6
    80001968:	f807a623          	sw	zero,-116(a5) # 800078f0 <first.2>
    // ensure other cores see first=0.
    __sync_synchronize();
    8000196c:	0ff0000f          	fence

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    80001970:	00006517          	auipc	a0,0x6
    80001974:	81050513          	addi	a0,a0,-2032 # 80007180 <etext+0x180>
    80001978:	fca43823          	sd	a0,-48(s0)
    8000197c:	fc043c23          	sd	zero,-40(s0)
    80001980:	fd040593          	addi	a1,s0,-48
    80001984:	132030ef          	jal	80004ab6 <kexec>
    80001988:	6cbc                	ld	a5,88(s1)
    8000198a:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    8000198c:	6cbc                	ld	a5,88(s1)
    8000198e:	7bb8                	ld	a4,112(a5)
    80001990:	57fd                	li	a5,-1
    80001992:	02f70d63          	beq	a4,a5,800019cc <forkret+0x8c>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    80001996:	6a7000ef          	jal	8000283c <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    8000199a:	68a8                	ld	a0,80(s1)
    8000199c:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    8000199e:	04000737          	lui	a4,0x4000
    800019a2:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800019a4:	0732                	slli	a4,a4,0xc
    800019a6:	00004797          	auipc	a5,0x4
    800019aa:	6f678793          	addi	a5,a5,1782 # 8000609c <userret>
    800019ae:	00004697          	auipc	a3,0x4
    800019b2:	65268693          	addi	a3,a3,1618 # 80006000 <_trampoline>
    800019b6:	8f95                	sub	a5,a5,a3
    800019b8:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800019ba:	577d                	li	a4,-1
    800019bc:	177e                	slli	a4,a4,0x3f
    800019be:	8d59                	or	a0,a0,a4
    800019c0:	9782                	jalr	a5
}
    800019c2:	70a2                	ld	ra,40(sp)
    800019c4:	7402                	ld	s0,32(sp)
    800019c6:	64e2                	ld	s1,24(sp)
    800019c8:	6145                	addi	sp,sp,48
    800019ca:	8082                	ret
      panic("exec");
    800019cc:	00005517          	auipc	a0,0x5
    800019d0:	7bc50513          	addi	a0,a0,1980 # 80007188 <etext+0x188>
    800019d4:	e0dfe0ef          	jal	800007e0 <panic>

00000000800019d8 <allocpid>:
{
    800019d8:	1101                	addi	sp,sp,-32
    800019da:	ec06                	sd	ra,24(sp)
    800019dc:	e822                	sd	s0,16(sp)
    800019de:	e426                	sd	s1,8(sp)
    800019e0:	e04a                	sd	s2,0(sp)
    800019e2:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    800019e4:	0000e917          	auipc	s2,0xe
    800019e8:	04490913          	addi	s2,s2,68 # 8000fa28 <pid_lock>
    800019ec:	854a                	mv	a0,s2
    800019ee:	a22ff0ef          	jal	80000c10 <acquire>
  pid = nextpid;
    800019f2:	00006797          	auipc	a5,0x6
    800019f6:	f0278793          	addi	a5,a5,-254 # 800078f4 <nextpid>
    800019fa:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    800019fc:	0014871b          	addiw	a4,s1,1
    80001a00:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001a02:	854a                	mv	a0,s2
    80001a04:	aa4ff0ef          	jal	80000ca8 <release>
}
    80001a08:	8526                	mv	a0,s1
    80001a0a:	60e2                	ld	ra,24(sp)
    80001a0c:	6442                	ld	s0,16(sp)
    80001a0e:	64a2                	ld	s1,8(sp)
    80001a10:	6902                	ld	s2,0(sp)
    80001a12:	6105                	addi	sp,sp,32
    80001a14:	8082                	ret

0000000080001a16 <proc_pagetable>:
{
    80001a16:	1101                	addi	sp,sp,-32
    80001a18:	ec06                	sd	ra,24(sp)
    80001a1a:	e822                	sd	s0,16(sp)
    80001a1c:	e426                	sd	s1,8(sp)
    80001a1e:	e04a                	sd	s2,0(sp)
    80001a20:	1000                	addi	s0,sp,32
    80001a22:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001a24:	fb2ff0ef          	jal	800011d6 <uvmcreate>
    80001a28:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001a2a:	cd05                	beqz	a0,80001a62 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001a2c:	4729                	li	a4,10
    80001a2e:	00004697          	auipc	a3,0x4
    80001a32:	5d268693          	addi	a3,a3,1490 # 80006000 <_trampoline>
    80001a36:	6605                	lui	a2,0x1
    80001a38:	040005b7          	lui	a1,0x4000
    80001a3c:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a3e:	05b2                	slli	a1,a1,0xc
    80001a40:	df0ff0ef          	jal	80001030 <mappages>
    80001a44:	02054663          	bltz	a0,80001a70 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001a48:	4719                	li	a4,6
    80001a4a:	05893683          	ld	a3,88(s2)
    80001a4e:	6605                	lui	a2,0x1
    80001a50:	020005b7          	lui	a1,0x2000
    80001a54:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a56:	05b6                	slli	a1,a1,0xd
    80001a58:	8526                	mv	a0,s1
    80001a5a:	dd6ff0ef          	jal	80001030 <mappages>
    80001a5e:	00054f63          	bltz	a0,80001a7c <proc_pagetable+0x66>
}
    80001a62:	8526                	mv	a0,s1
    80001a64:	60e2                	ld	ra,24(sp)
    80001a66:	6442                	ld	s0,16(sp)
    80001a68:	64a2                	ld	s1,8(sp)
    80001a6a:	6902                	ld	s2,0(sp)
    80001a6c:	6105                	addi	sp,sp,32
    80001a6e:	8082                	ret
    uvmfree(pagetable, 0);
    80001a70:	4581                	li	a1,0
    80001a72:	8526                	mv	a0,s1
    80001a74:	95dff0ef          	jal	800013d0 <uvmfree>
    return 0;
    80001a78:	4481                	li	s1,0
    80001a7a:	b7e5                	j	80001a62 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a7c:	4681                	li	a3,0
    80001a7e:	4605                	li	a2,1
    80001a80:	040005b7          	lui	a1,0x4000
    80001a84:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a86:	05b2                	slli	a1,a1,0xc
    80001a88:	8526                	mv	a0,s1
    80001a8a:	f72ff0ef          	jal	800011fc <uvmunmap>
    uvmfree(pagetable, 0);
    80001a8e:	4581                	li	a1,0
    80001a90:	8526                	mv	a0,s1
    80001a92:	93fff0ef          	jal	800013d0 <uvmfree>
    return 0;
    80001a96:	4481                	li	s1,0
    80001a98:	b7e9                	j	80001a62 <proc_pagetable+0x4c>

0000000080001a9a <proc_freepagetable>:
{
    80001a9a:	1101                	addi	sp,sp,-32
    80001a9c:	ec06                	sd	ra,24(sp)
    80001a9e:	e822                	sd	s0,16(sp)
    80001aa0:	e426                	sd	s1,8(sp)
    80001aa2:	e04a                	sd	s2,0(sp)
    80001aa4:	1000                	addi	s0,sp,32
    80001aa6:	84aa                	mv	s1,a0
    80001aa8:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001aaa:	4681                	li	a3,0
    80001aac:	4605                	li	a2,1
    80001aae:	040005b7          	lui	a1,0x4000
    80001ab2:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001ab4:	05b2                	slli	a1,a1,0xc
    80001ab6:	f46ff0ef          	jal	800011fc <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001aba:	4681                	li	a3,0
    80001abc:	4605                	li	a2,1
    80001abe:	020005b7          	lui	a1,0x2000
    80001ac2:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001ac4:	05b6                	slli	a1,a1,0xd
    80001ac6:	8526                	mv	a0,s1
    80001ac8:	f34ff0ef          	jal	800011fc <uvmunmap>
  uvmfree(pagetable, sz);
    80001acc:	85ca                	mv	a1,s2
    80001ace:	8526                	mv	a0,s1
    80001ad0:	901ff0ef          	jal	800013d0 <uvmfree>
}
    80001ad4:	60e2                	ld	ra,24(sp)
    80001ad6:	6442                	ld	s0,16(sp)
    80001ad8:	64a2                	ld	s1,8(sp)
    80001ada:	6902                	ld	s2,0(sp)
    80001adc:	6105                	addi	sp,sp,32
    80001ade:	8082                	ret

0000000080001ae0 <freeproc>:
{
    80001ae0:	1101                	addi	sp,sp,-32
    80001ae2:	ec06                	sd	ra,24(sp)
    80001ae4:	e822                	sd	s0,16(sp)
    80001ae6:	e426                	sd	s1,8(sp)
    80001ae8:	1000                	addi	s0,sp,32
    80001aea:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001aec:	6d28                	ld	a0,88(a0)
    80001aee:	c119                	beqz	a0,80001af4 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001af0:	f2dfe0ef          	jal	80000a1c <kfree>
  p->trapframe = 0;
    80001af4:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001af8:	68a8                	ld	a0,80(s1)
    80001afa:	c501                	beqz	a0,80001b02 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001afc:	64ac                	ld	a1,72(s1)
    80001afe:	f9dff0ef          	jal	80001a9a <proc_freepagetable>
  p->pagetable = 0;
    80001b02:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001b06:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001b0a:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001b0e:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001b12:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001b16:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001b1a:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001b1e:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001b22:	0004ac23          	sw	zero,24(s1)
}
    80001b26:	60e2                	ld	ra,24(sp)
    80001b28:	6442                	ld	s0,16(sp)
    80001b2a:	64a2                	ld	s1,8(sp)
    80001b2c:	6105                	addi	sp,sp,32
    80001b2e:	8082                	ret

0000000080001b30 <allocproc>:
{
    80001b30:	1101                	addi	sp,sp,-32
    80001b32:	ec06                	sd	ra,24(sp)
    80001b34:	e822                	sd	s0,16(sp)
    80001b36:	e426                	sd	s1,8(sp)
    80001b38:	e04a                	sd	s2,0(sp)
    80001b3a:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b3c:	0000e497          	auipc	s1,0xe
    80001b40:	31c48493          	addi	s1,s1,796 # 8000fe58 <proc>
    80001b44:	00014917          	auipc	s2,0x14
    80001b48:	d1490913          	addi	s2,s2,-748 # 80015858 <tickslock>
    acquire(&p->lock);
    80001b4c:	8526                	mv	a0,s1
    80001b4e:	8c2ff0ef          	jal	80000c10 <acquire>
    if(p->state == UNUSED) {
    80001b52:	4c9c                	lw	a5,24(s1)
    80001b54:	cb91                	beqz	a5,80001b68 <allocproc+0x38>
      release(&p->lock);
    80001b56:	8526                	mv	a0,s1
    80001b58:	950ff0ef          	jal	80000ca8 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b5c:	16848493          	addi	s1,s1,360
    80001b60:	ff2496e3          	bne	s1,s2,80001b4c <allocproc+0x1c>
  return 0;
    80001b64:	4481                	li	s1,0
    80001b66:	a099                	j	80001bac <allocproc+0x7c>
  p->pid = allocpid();
    80001b68:	e71ff0ef          	jal	800019d8 <allocpid>
    80001b6c:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b6e:	4785                	li	a5,1
    80001b70:	cc9c                	sw	a5,24(s1)
  p->nice = 20; //Added for project 01
    80001b72:	47d1                	li	a5,20
    80001b74:	d8dc                	sw	a5,52(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001b76:	f89fe0ef          	jal	80000afe <kalloc>
    80001b7a:	892a                	mv	s2,a0
    80001b7c:	eca8                	sd	a0,88(s1)
    80001b7e:	cd15                	beqz	a0,80001bba <allocproc+0x8a>
  p->pagetable = proc_pagetable(p);
    80001b80:	8526                	mv	a0,s1
    80001b82:	e95ff0ef          	jal	80001a16 <proc_pagetable>
    80001b86:	892a                	mv	s2,a0
    80001b88:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001b8a:	c121                	beqz	a0,80001bca <allocproc+0x9a>
  memset(&p->context, 0, sizeof(p->context));
    80001b8c:	07000613          	li	a2,112
    80001b90:	4581                	li	a1,0
    80001b92:	06048513          	addi	a0,s1,96
    80001b96:	94eff0ef          	jal	80000ce4 <memset>
  p->context.ra = (uint64)forkret;
    80001b9a:	00000797          	auipc	a5,0x0
    80001b9e:	da678793          	addi	a5,a5,-602 # 80001940 <forkret>
    80001ba2:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001ba4:	60bc                	ld	a5,64(s1)
    80001ba6:	6705                	lui	a4,0x1
    80001ba8:	97ba                	add	a5,a5,a4
    80001baa:	f4bc                	sd	a5,104(s1)
}
    80001bac:	8526                	mv	a0,s1
    80001bae:	60e2                	ld	ra,24(sp)
    80001bb0:	6442                	ld	s0,16(sp)
    80001bb2:	64a2                	ld	s1,8(sp)
    80001bb4:	6902                	ld	s2,0(sp)
    80001bb6:	6105                	addi	sp,sp,32
    80001bb8:	8082                	ret
    freeproc(p);
    80001bba:	8526                	mv	a0,s1
    80001bbc:	f25ff0ef          	jal	80001ae0 <freeproc>
    release(&p->lock);
    80001bc0:	8526                	mv	a0,s1
    80001bc2:	8e6ff0ef          	jal	80000ca8 <release>
    return 0;
    80001bc6:	84ca                	mv	s1,s2
    80001bc8:	b7d5                	j	80001bac <allocproc+0x7c>
    freeproc(p);
    80001bca:	8526                	mv	a0,s1
    80001bcc:	f15ff0ef          	jal	80001ae0 <freeproc>
    release(&p->lock);
    80001bd0:	8526                	mv	a0,s1
    80001bd2:	8d6ff0ef          	jal	80000ca8 <release>
    return 0;
    80001bd6:	84ca                	mv	s1,s2
    80001bd8:	bfd1                	j	80001bac <allocproc+0x7c>

0000000080001bda <userinit>:
{
    80001bda:	1101                	addi	sp,sp,-32
    80001bdc:	ec06                	sd	ra,24(sp)
    80001bde:	e822                	sd	s0,16(sp)
    80001be0:	e426                	sd	s1,8(sp)
    80001be2:	1000                	addi	s0,sp,32
  p = allocproc();
    80001be4:	f4dff0ef          	jal	80001b30 <allocproc>
    80001be8:	84aa                	mv	s1,a0
  initproc = p;
    80001bea:	00006797          	auipc	a5,0x6
    80001bee:	d2a7bb23          	sd	a0,-714(a5) # 80007920 <initproc>
  p->cwd = namei("/");
    80001bf2:	00005517          	auipc	a0,0x5
    80001bf6:	59e50513          	addi	a0,a0,1438 # 80007190 <etext+0x190>
    80001bfa:	2d4020ef          	jal	80003ece <namei>
    80001bfe:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001c02:	478d                	li	a5,3
    80001c04:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001c06:	8526                	mv	a0,s1
    80001c08:	8a0ff0ef          	jal	80000ca8 <release>
}
    80001c0c:	60e2                	ld	ra,24(sp)
    80001c0e:	6442                	ld	s0,16(sp)
    80001c10:	64a2                	ld	s1,8(sp)
    80001c12:	6105                	addi	sp,sp,32
    80001c14:	8082                	ret

0000000080001c16 <growproc>:
{
    80001c16:	1101                	addi	sp,sp,-32
    80001c18:	ec06                	sd	ra,24(sp)
    80001c1a:	e822                	sd	s0,16(sp)
    80001c1c:	e426                	sd	s1,8(sp)
    80001c1e:	e04a                	sd	s2,0(sp)
    80001c20:	1000                	addi	s0,sp,32
    80001c22:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001c24:	cedff0ef          	jal	80001910 <myproc>
    80001c28:	892a                	mv	s2,a0
  sz = p->sz;
    80001c2a:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001c2c:	02905963          	blez	s1,80001c5e <growproc+0x48>
    if(sz + n > TRAPFRAME) {
    80001c30:	00b48633          	add	a2,s1,a1
    80001c34:	020007b7          	lui	a5,0x2000
    80001c38:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001c3a:	07b6                	slli	a5,a5,0xd
    80001c3c:	02c7ea63          	bltu	a5,a2,80001c70 <growproc+0x5a>
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c40:	4691                	li	a3,4
    80001c42:	6928                	ld	a0,80(a0)
    80001c44:	e86ff0ef          	jal	800012ca <uvmalloc>
    80001c48:	85aa                	mv	a1,a0
    80001c4a:	c50d                	beqz	a0,80001c74 <growproc+0x5e>
  p->sz = sz;
    80001c4c:	04b93423          	sd	a1,72(s2)
  return 0;
    80001c50:	4501                	li	a0,0
}
    80001c52:	60e2                	ld	ra,24(sp)
    80001c54:	6442                	ld	s0,16(sp)
    80001c56:	64a2                	ld	s1,8(sp)
    80001c58:	6902                	ld	s2,0(sp)
    80001c5a:	6105                	addi	sp,sp,32
    80001c5c:	8082                	ret
  } else if(n < 0){
    80001c5e:	fe04d7e3          	bgez	s1,80001c4c <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c62:	00b48633          	add	a2,s1,a1
    80001c66:	6928                	ld	a0,80(a0)
    80001c68:	e1eff0ef          	jal	80001286 <uvmdealloc>
    80001c6c:	85aa                	mv	a1,a0
    80001c6e:	bff9                	j	80001c4c <growproc+0x36>
      return -1;
    80001c70:	557d                	li	a0,-1
    80001c72:	b7c5                	j	80001c52 <growproc+0x3c>
      return -1;
    80001c74:	557d                	li	a0,-1
    80001c76:	bff1                	j	80001c52 <growproc+0x3c>

0000000080001c78 <kfork>:
{
    80001c78:	7139                	addi	sp,sp,-64
    80001c7a:	fc06                	sd	ra,56(sp)
    80001c7c:	f822                	sd	s0,48(sp)
    80001c7e:	f04a                	sd	s2,32(sp)
    80001c80:	e456                	sd	s5,8(sp)
    80001c82:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c84:	c8dff0ef          	jal	80001910 <myproc>
    80001c88:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001c8a:	ea7ff0ef          	jal	80001b30 <allocproc>
    80001c8e:	0e050a63          	beqz	a0,80001d82 <kfork+0x10a>
    80001c92:	e852                	sd	s4,16(sp)
    80001c94:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001c96:	048ab603          	ld	a2,72(s5)
    80001c9a:	692c                	ld	a1,80(a0)
    80001c9c:	050ab503          	ld	a0,80(s5)
    80001ca0:	f62ff0ef          	jal	80001402 <uvmcopy>
    80001ca4:	04054a63          	bltz	a0,80001cf8 <kfork+0x80>
    80001ca8:	f426                	sd	s1,40(sp)
    80001caa:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001cac:	048ab783          	ld	a5,72(s5)
    80001cb0:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001cb4:	058ab683          	ld	a3,88(s5)
    80001cb8:	87b6                	mv	a5,a3
    80001cba:	058a3703          	ld	a4,88(s4)
    80001cbe:	12068693          	addi	a3,a3,288
    80001cc2:	0007b803          	ld	a6,0(a5)
    80001cc6:	6788                	ld	a0,8(a5)
    80001cc8:	6b8c                	ld	a1,16(a5)
    80001cca:	6f90                	ld	a2,24(a5)
    80001ccc:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001cd0:	e708                	sd	a0,8(a4)
    80001cd2:	eb0c                	sd	a1,16(a4)
    80001cd4:	ef10                	sd	a2,24(a4)
    80001cd6:	02078793          	addi	a5,a5,32
    80001cda:	02070713          	addi	a4,a4,32
    80001cde:	fed792e3          	bne	a5,a3,80001cc2 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001ce2:	058a3783          	ld	a5,88(s4)
    80001ce6:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001cea:	0d0a8493          	addi	s1,s5,208
    80001cee:	0d0a0913          	addi	s2,s4,208
    80001cf2:	150a8993          	addi	s3,s5,336
    80001cf6:	a831                	j	80001d12 <kfork+0x9a>
    freeproc(np);
    80001cf8:	8552                	mv	a0,s4
    80001cfa:	de7ff0ef          	jal	80001ae0 <freeproc>
    release(&np->lock);
    80001cfe:	8552                	mv	a0,s4
    80001d00:	fa9fe0ef          	jal	80000ca8 <release>
    return -1;
    80001d04:	597d                	li	s2,-1
    80001d06:	6a42                	ld	s4,16(sp)
    80001d08:	a0b5                	j	80001d74 <kfork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001d0a:	04a1                	addi	s1,s1,8
    80001d0c:	0921                	addi	s2,s2,8
    80001d0e:	01348963          	beq	s1,s3,80001d20 <kfork+0xa8>
    if(p->ofile[i])
    80001d12:	6088                	ld	a0,0(s1)
    80001d14:	d97d                	beqz	a0,80001d0a <kfork+0x92>
      np->ofile[i] = filedup(p->ofile[i]);
    80001d16:	752020ef          	jal	80004468 <filedup>
    80001d1a:	00a93023          	sd	a0,0(s2)
    80001d1e:	b7f5                	j	80001d0a <kfork+0x92>
  np->cwd = idup(p->cwd);
    80001d20:	150ab503          	ld	a0,336(s5)
    80001d24:	15f010ef          	jal	80003682 <idup>
    80001d28:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001d2c:	4641                	li	a2,16
    80001d2e:	158a8593          	addi	a1,s5,344
    80001d32:	158a0513          	addi	a0,s4,344
    80001d36:	8ecff0ef          	jal	80000e22 <safestrcpy>
  pid = np->pid;
    80001d3a:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001d3e:	8552                	mv	a0,s4
    80001d40:	f69fe0ef          	jal	80000ca8 <release>
  acquire(&wait_lock);
    80001d44:	0000e497          	auipc	s1,0xe
    80001d48:	cfc48493          	addi	s1,s1,-772 # 8000fa40 <wait_lock>
    80001d4c:	8526                	mv	a0,s1
    80001d4e:	ec3fe0ef          	jal	80000c10 <acquire>
  np->parent = p;
    80001d52:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d56:	8526                	mv	a0,s1
    80001d58:	f51fe0ef          	jal	80000ca8 <release>
  acquire(&np->lock);
    80001d5c:	8552                	mv	a0,s4
    80001d5e:	eb3fe0ef          	jal	80000c10 <acquire>
  np->state = RUNNABLE;
    80001d62:	478d                	li	a5,3
    80001d64:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d68:	8552                	mv	a0,s4
    80001d6a:	f3ffe0ef          	jal	80000ca8 <release>
  return pid;
    80001d6e:	74a2                	ld	s1,40(sp)
    80001d70:	69e2                	ld	s3,24(sp)
    80001d72:	6a42                	ld	s4,16(sp)
}
    80001d74:	854a                	mv	a0,s2
    80001d76:	70e2                	ld	ra,56(sp)
    80001d78:	7442                	ld	s0,48(sp)
    80001d7a:	7902                	ld	s2,32(sp)
    80001d7c:	6aa2                	ld	s5,8(sp)
    80001d7e:	6121                	addi	sp,sp,64
    80001d80:	8082                	ret
    return -1;
    80001d82:	597d                	li	s2,-1
    80001d84:	bfc5                	j	80001d74 <kfork+0xfc>

0000000080001d86 <scheduler>:
{
    80001d86:	715d                	addi	sp,sp,-80
    80001d88:	e486                	sd	ra,72(sp)
    80001d8a:	e0a2                	sd	s0,64(sp)
    80001d8c:	fc26                	sd	s1,56(sp)
    80001d8e:	f84a                	sd	s2,48(sp)
    80001d90:	f44e                	sd	s3,40(sp)
    80001d92:	f052                	sd	s4,32(sp)
    80001d94:	ec56                	sd	s5,24(sp)
    80001d96:	e85a                	sd	s6,16(sp)
    80001d98:	e45e                	sd	s7,8(sp)
    80001d9a:	e062                	sd	s8,0(sp)
    80001d9c:	0880                	addi	s0,sp,80
    80001d9e:	8792                	mv	a5,tp
  int id = r_tp();
    80001da0:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001da2:	00779b13          	slli	s6,a5,0x7
    80001da6:	0000e717          	auipc	a4,0xe
    80001daa:	c8270713          	addi	a4,a4,-894 # 8000fa28 <pid_lock>
    80001dae:	975a                	add	a4,a4,s6
    80001db0:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001db4:	0000e717          	auipc	a4,0xe
    80001db8:	cac70713          	addi	a4,a4,-852 # 8000fa60 <cpus+0x8>
    80001dbc:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80001dbe:	4c11                	li	s8,4
        c->proc = p;
    80001dc0:	079e                	slli	a5,a5,0x7
    80001dc2:	0000ea17          	auipc	s4,0xe
    80001dc6:	c66a0a13          	addi	s4,s4,-922 # 8000fa28 <pid_lock>
    80001dca:	9a3e                	add	s4,s4,a5
        found = 1;
    80001dcc:	4b85                	li	s7,1
    for(p = proc; p < &proc[NPROC]; p++) {
    80001dce:	00014997          	auipc	s3,0x14
    80001dd2:	a8a98993          	addi	s3,s3,-1398 # 80015858 <tickslock>
    80001dd6:	a83d                	j	80001e14 <scheduler+0x8e>
      release(&p->lock);
    80001dd8:	8526                	mv	a0,s1
    80001dda:	ecffe0ef          	jal	80000ca8 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001dde:	16848493          	addi	s1,s1,360
    80001de2:	03348563          	beq	s1,s3,80001e0c <scheduler+0x86>
      acquire(&p->lock);
    80001de6:	8526                	mv	a0,s1
    80001de8:	e29fe0ef          	jal	80000c10 <acquire>
      if(p->state == RUNNABLE) {
    80001dec:	4c9c                	lw	a5,24(s1)
    80001dee:	ff2795e3          	bne	a5,s2,80001dd8 <scheduler+0x52>
        p->state = RUNNING;
    80001df2:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001df6:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001dfa:	06048593          	addi	a1,s1,96
    80001dfe:	855a                	mv	a0,s6
    80001e00:	197000ef          	jal	80002796 <swtch>
        c->proc = 0;
    80001e04:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001e08:	8ade                	mv	s5,s7
    80001e0a:	b7f9                	j	80001dd8 <scheduler+0x52>
    if(found == 0) {
    80001e0c:	000a9463          	bnez	s5,80001e14 <scheduler+0x8e>
      asm volatile("wfi");
    80001e10:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e14:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001e18:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001e1c:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e20:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001e24:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001e26:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001e2a:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001e2c:	0000e497          	auipc	s1,0xe
    80001e30:	02c48493          	addi	s1,s1,44 # 8000fe58 <proc>
      if(p->state == RUNNABLE) {
    80001e34:	490d                	li	s2,3
    80001e36:	bf45                	j	80001de6 <scheduler+0x60>

0000000080001e38 <sched>:
{
    80001e38:	7179                	addi	sp,sp,-48
    80001e3a:	f406                	sd	ra,40(sp)
    80001e3c:	f022                	sd	s0,32(sp)
    80001e3e:	ec26                	sd	s1,24(sp)
    80001e40:	e84a                	sd	s2,16(sp)
    80001e42:	e44e                	sd	s3,8(sp)
    80001e44:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e46:	acbff0ef          	jal	80001910 <myproc>
    80001e4a:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001e4c:	d5bfe0ef          	jal	80000ba6 <holding>
    80001e50:	c92d                	beqz	a0,80001ec2 <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e52:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001e54:	2781                	sext.w	a5,a5
    80001e56:	079e                	slli	a5,a5,0x7
    80001e58:	0000e717          	auipc	a4,0xe
    80001e5c:	bd070713          	addi	a4,a4,-1072 # 8000fa28 <pid_lock>
    80001e60:	97ba                	add	a5,a5,a4
    80001e62:	0a87a703          	lw	a4,168(a5)
    80001e66:	4785                	li	a5,1
    80001e68:	06f71363          	bne	a4,a5,80001ece <sched+0x96>
  if(p->state == RUNNING)
    80001e6c:	4c98                	lw	a4,24(s1)
    80001e6e:	4791                	li	a5,4
    80001e70:	06f70563          	beq	a4,a5,80001eda <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e74:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e78:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001e7a:	e7b5                	bnez	a5,80001ee6 <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e7c:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e7e:	0000e917          	auipc	s2,0xe
    80001e82:	baa90913          	addi	s2,s2,-1110 # 8000fa28 <pid_lock>
    80001e86:	2781                	sext.w	a5,a5
    80001e88:	079e                	slli	a5,a5,0x7
    80001e8a:	97ca                	add	a5,a5,s2
    80001e8c:	0ac7a983          	lw	s3,172(a5)
    80001e90:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e92:	2781                	sext.w	a5,a5
    80001e94:	079e                	slli	a5,a5,0x7
    80001e96:	0000e597          	auipc	a1,0xe
    80001e9a:	bca58593          	addi	a1,a1,-1078 # 8000fa60 <cpus+0x8>
    80001e9e:	95be                	add	a1,a1,a5
    80001ea0:	06048513          	addi	a0,s1,96
    80001ea4:	0f3000ef          	jal	80002796 <swtch>
    80001ea8:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001eaa:	2781                	sext.w	a5,a5
    80001eac:	079e                	slli	a5,a5,0x7
    80001eae:	993e                	add	s2,s2,a5
    80001eb0:	0b392623          	sw	s3,172(s2)
}
    80001eb4:	70a2                	ld	ra,40(sp)
    80001eb6:	7402                	ld	s0,32(sp)
    80001eb8:	64e2                	ld	s1,24(sp)
    80001eba:	6942                	ld	s2,16(sp)
    80001ebc:	69a2                	ld	s3,8(sp)
    80001ebe:	6145                	addi	sp,sp,48
    80001ec0:	8082                	ret
    panic("sched p->lock");
    80001ec2:	00005517          	auipc	a0,0x5
    80001ec6:	2d650513          	addi	a0,a0,726 # 80007198 <etext+0x198>
    80001eca:	917fe0ef          	jal	800007e0 <panic>
    panic("sched locks");
    80001ece:	00005517          	auipc	a0,0x5
    80001ed2:	2da50513          	addi	a0,a0,730 # 800071a8 <etext+0x1a8>
    80001ed6:	90bfe0ef          	jal	800007e0 <panic>
    panic("sched RUNNING");
    80001eda:	00005517          	auipc	a0,0x5
    80001ede:	2de50513          	addi	a0,a0,734 # 800071b8 <etext+0x1b8>
    80001ee2:	8fffe0ef          	jal	800007e0 <panic>
    panic("sched interruptible");
    80001ee6:	00005517          	auipc	a0,0x5
    80001eea:	2e250513          	addi	a0,a0,738 # 800071c8 <etext+0x1c8>
    80001eee:	8f3fe0ef          	jal	800007e0 <panic>

0000000080001ef2 <yield>:
{
    80001ef2:	1101                	addi	sp,sp,-32
    80001ef4:	ec06                	sd	ra,24(sp)
    80001ef6:	e822                	sd	s0,16(sp)
    80001ef8:	e426                	sd	s1,8(sp)
    80001efa:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001efc:	a15ff0ef          	jal	80001910 <myproc>
    80001f00:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001f02:	d0ffe0ef          	jal	80000c10 <acquire>
  p->state = RUNNABLE;
    80001f06:	478d                	li	a5,3
    80001f08:	cc9c                	sw	a5,24(s1)
  sched();
    80001f0a:	f2fff0ef          	jal	80001e38 <sched>
  release(&p->lock);
    80001f0e:	8526                	mv	a0,s1
    80001f10:	d99fe0ef          	jal	80000ca8 <release>
}
    80001f14:	60e2                	ld	ra,24(sp)
    80001f16:	6442                	ld	s0,16(sp)
    80001f18:	64a2                	ld	s1,8(sp)
    80001f1a:	6105                	addi	sp,sp,32
    80001f1c:	8082                	ret

0000000080001f1e <sleep>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001f1e:	7179                	addi	sp,sp,-48
    80001f20:	f406                	sd	ra,40(sp)
    80001f22:	f022                	sd	s0,32(sp)
    80001f24:	ec26                	sd	s1,24(sp)
    80001f26:	e84a                	sd	s2,16(sp)
    80001f28:	e44e                	sd	s3,8(sp)
    80001f2a:	1800                	addi	s0,sp,48
    80001f2c:	89aa                	mv	s3,a0
    80001f2e:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001f30:	9e1ff0ef          	jal	80001910 <myproc>
    80001f34:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001f36:	cdbfe0ef          	jal	80000c10 <acquire>
  release(lk);
    80001f3a:	854a                	mv	a0,s2
    80001f3c:	d6dfe0ef          	jal	80000ca8 <release>

  // Go to sleep.
  p->chan = chan;
    80001f40:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001f44:	4789                	li	a5,2
    80001f46:	cc9c                	sw	a5,24(s1)

  sched();
    80001f48:	ef1ff0ef          	jal	80001e38 <sched>

  // Tidy up.
  p->chan = 0;
    80001f4c:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001f50:	8526                	mv	a0,s1
    80001f52:	d57fe0ef          	jal	80000ca8 <release>
  acquire(lk);
    80001f56:	854a                	mv	a0,s2
    80001f58:	cb9fe0ef          	jal	80000c10 <acquire>
}
    80001f5c:	70a2                	ld	ra,40(sp)
    80001f5e:	7402                	ld	s0,32(sp)
    80001f60:	64e2                	ld	s1,24(sp)
    80001f62:	6942                	ld	s2,16(sp)
    80001f64:	69a2                	ld	s3,8(sp)
    80001f66:	6145                	addi	sp,sp,48
    80001f68:	8082                	ret

0000000080001f6a <wakeup>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80001f6a:	7139                	addi	sp,sp,-64
    80001f6c:	fc06                	sd	ra,56(sp)
    80001f6e:	f822                	sd	s0,48(sp)
    80001f70:	f426                	sd	s1,40(sp)
    80001f72:	f04a                	sd	s2,32(sp)
    80001f74:	ec4e                	sd	s3,24(sp)
    80001f76:	e852                	sd	s4,16(sp)
    80001f78:	e456                	sd	s5,8(sp)
    80001f7a:	0080                	addi	s0,sp,64
    80001f7c:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001f7e:	0000e497          	auipc	s1,0xe
    80001f82:	eda48493          	addi	s1,s1,-294 # 8000fe58 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001f86:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001f88:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f8a:	00014917          	auipc	s2,0x14
    80001f8e:	8ce90913          	addi	s2,s2,-1842 # 80015858 <tickslock>
    80001f92:	a801                	j	80001fa2 <wakeup+0x38>
      }
      release(&p->lock);
    80001f94:	8526                	mv	a0,s1
    80001f96:	d13fe0ef          	jal	80000ca8 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f9a:	16848493          	addi	s1,s1,360
    80001f9e:	03248263          	beq	s1,s2,80001fc2 <wakeup+0x58>
    if(p != myproc()){
    80001fa2:	96fff0ef          	jal	80001910 <myproc>
    80001fa6:	fea48ae3          	beq	s1,a0,80001f9a <wakeup+0x30>
      acquire(&p->lock);
    80001faa:	8526                	mv	a0,s1
    80001fac:	c65fe0ef          	jal	80000c10 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001fb0:	4c9c                	lw	a5,24(s1)
    80001fb2:	ff3791e3          	bne	a5,s3,80001f94 <wakeup+0x2a>
    80001fb6:	709c                	ld	a5,32(s1)
    80001fb8:	fd479ee3          	bne	a5,s4,80001f94 <wakeup+0x2a>
        p->state = RUNNABLE;
    80001fbc:	0154ac23          	sw	s5,24(s1)
    80001fc0:	bfd1                	j	80001f94 <wakeup+0x2a>
    }
  }
}
    80001fc2:	70e2                	ld	ra,56(sp)
    80001fc4:	7442                	ld	s0,48(sp)
    80001fc6:	74a2                	ld	s1,40(sp)
    80001fc8:	7902                	ld	s2,32(sp)
    80001fca:	69e2                	ld	s3,24(sp)
    80001fcc:	6a42                	ld	s4,16(sp)
    80001fce:	6aa2                	ld	s5,8(sp)
    80001fd0:	6121                	addi	sp,sp,64
    80001fd2:	8082                	ret

0000000080001fd4 <reparent>:
{
    80001fd4:	7179                	addi	sp,sp,-48
    80001fd6:	f406                	sd	ra,40(sp)
    80001fd8:	f022                	sd	s0,32(sp)
    80001fda:	ec26                	sd	s1,24(sp)
    80001fdc:	e84a                	sd	s2,16(sp)
    80001fde:	e44e                	sd	s3,8(sp)
    80001fe0:	e052                	sd	s4,0(sp)
    80001fe2:	1800                	addi	s0,sp,48
    80001fe4:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001fe6:	0000e497          	auipc	s1,0xe
    80001fea:	e7248493          	addi	s1,s1,-398 # 8000fe58 <proc>
      pp->parent = initproc;
    80001fee:	00006a17          	auipc	s4,0x6
    80001ff2:	932a0a13          	addi	s4,s4,-1742 # 80007920 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001ff6:	00014997          	auipc	s3,0x14
    80001ffa:	86298993          	addi	s3,s3,-1950 # 80015858 <tickslock>
    80001ffe:	a029                	j	80002008 <reparent+0x34>
    80002000:	16848493          	addi	s1,s1,360
    80002004:	01348b63          	beq	s1,s3,8000201a <reparent+0x46>
    if(pp->parent == p){
    80002008:	7c9c                	ld	a5,56(s1)
    8000200a:	ff279be3          	bne	a5,s2,80002000 <reparent+0x2c>
      pp->parent = initproc;
    8000200e:	000a3503          	ld	a0,0(s4)
    80002012:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80002014:	f57ff0ef          	jal	80001f6a <wakeup>
    80002018:	b7e5                	j	80002000 <reparent+0x2c>
}
    8000201a:	70a2                	ld	ra,40(sp)
    8000201c:	7402                	ld	s0,32(sp)
    8000201e:	64e2                	ld	s1,24(sp)
    80002020:	6942                	ld	s2,16(sp)
    80002022:	69a2                	ld	s3,8(sp)
    80002024:	6a02                	ld	s4,0(sp)
    80002026:	6145                	addi	sp,sp,48
    80002028:	8082                	ret

000000008000202a <kexit>:
{
    8000202a:	7179                	addi	sp,sp,-48
    8000202c:	f406                	sd	ra,40(sp)
    8000202e:	f022                	sd	s0,32(sp)
    80002030:	ec26                	sd	s1,24(sp)
    80002032:	e84a                	sd	s2,16(sp)
    80002034:	e44e                	sd	s3,8(sp)
    80002036:	e052                	sd	s4,0(sp)
    80002038:	1800                	addi	s0,sp,48
    8000203a:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000203c:	8d5ff0ef          	jal	80001910 <myproc>
    80002040:	89aa                	mv	s3,a0
  if(p == initproc)
    80002042:	00006797          	auipc	a5,0x6
    80002046:	8de7b783          	ld	a5,-1826(a5) # 80007920 <initproc>
    8000204a:	0d050493          	addi	s1,a0,208
    8000204e:	15050913          	addi	s2,a0,336
    80002052:	00a79f63          	bne	a5,a0,80002070 <kexit+0x46>
    panic("init exiting");
    80002056:	00005517          	auipc	a0,0x5
    8000205a:	18a50513          	addi	a0,a0,394 # 800071e0 <etext+0x1e0>
    8000205e:	f82fe0ef          	jal	800007e0 <panic>
      fileclose(f);
    80002062:	44c020ef          	jal	800044ae <fileclose>
      p->ofile[fd] = 0;
    80002066:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    8000206a:	04a1                	addi	s1,s1,8
    8000206c:	01248563          	beq	s1,s2,80002076 <kexit+0x4c>
    if(p->ofile[fd]){
    80002070:	6088                	ld	a0,0(s1)
    80002072:	f965                	bnez	a0,80002062 <kexit+0x38>
    80002074:	bfdd                	j	8000206a <kexit+0x40>
  begin_op();
    80002076:	02c020ef          	jal	800040a2 <begin_op>
  iput(p->cwd);
    8000207a:	1509b503          	ld	a0,336(s3)
    8000207e:	7bc010ef          	jal	8000383a <iput>
  end_op();
    80002082:	08a020ef          	jal	8000410c <end_op>
  p->cwd = 0;
    80002086:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000208a:	0000e497          	auipc	s1,0xe
    8000208e:	9b648493          	addi	s1,s1,-1610 # 8000fa40 <wait_lock>
    80002092:	8526                	mv	a0,s1
    80002094:	b7dfe0ef          	jal	80000c10 <acquire>
  reparent(p);
    80002098:	854e                	mv	a0,s3
    8000209a:	f3bff0ef          	jal	80001fd4 <reparent>
  wakeup(p->parent);
    8000209e:	0389b503          	ld	a0,56(s3)
    800020a2:	ec9ff0ef          	jal	80001f6a <wakeup>
  acquire(&p->lock);
    800020a6:	854e                	mv	a0,s3
    800020a8:	b69fe0ef          	jal	80000c10 <acquire>
  p->xstate = status;
    800020ac:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800020b0:	4795                	li	a5,5
    800020b2:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800020b6:	8526                	mv	a0,s1
    800020b8:	bf1fe0ef          	jal	80000ca8 <release>
  sched();
    800020bc:	d7dff0ef          	jal	80001e38 <sched>
  panic("zombie exit");
    800020c0:	00005517          	auipc	a0,0x5
    800020c4:	13050513          	addi	a0,a0,304 # 800071f0 <etext+0x1f0>
    800020c8:	f18fe0ef          	jal	800007e0 <panic>

00000000800020cc <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    800020cc:	7179                	addi	sp,sp,-48
    800020ce:	f406                	sd	ra,40(sp)
    800020d0:	f022                	sd	s0,32(sp)
    800020d2:	ec26                	sd	s1,24(sp)
    800020d4:	e84a                	sd	s2,16(sp)
    800020d6:	e44e                	sd	s3,8(sp)
    800020d8:	1800                	addi	s0,sp,48
    800020da:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    800020dc:	0000e497          	auipc	s1,0xe
    800020e0:	d7c48493          	addi	s1,s1,-644 # 8000fe58 <proc>
    800020e4:	00013997          	auipc	s3,0x13
    800020e8:	77498993          	addi	s3,s3,1908 # 80015858 <tickslock>
    acquire(&p->lock);
    800020ec:	8526                	mv	a0,s1
    800020ee:	b23fe0ef          	jal	80000c10 <acquire>
    if(p->pid == pid){
    800020f2:	589c                	lw	a5,48(s1)
    800020f4:	01278b63          	beq	a5,s2,8000210a <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800020f8:	8526                	mv	a0,s1
    800020fa:	baffe0ef          	jal	80000ca8 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800020fe:	16848493          	addi	s1,s1,360
    80002102:	ff3495e3          	bne	s1,s3,800020ec <kkill+0x20>
  }
  return -1;
    80002106:	557d                	li	a0,-1
    80002108:	a819                	j	8000211e <kkill+0x52>
      p->killed = 1;
    8000210a:	4785                	li	a5,1
    8000210c:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    8000210e:	4c98                	lw	a4,24(s1)
    80002110:	4789                	li	a5,2
    80002112:	00f70d63          	beq	a4,a5,8000212c <kkill+0x60>
      release(&p->lock);
    80002116:	8526                	mv	a0,s1
    80002118:	b91fe0ef          	jal	80000ca8 <release>
      return 0;
    8000211c:	4501                	li	a0,0
}
    8000211e:	70a2                	ld	ra,40(sp)
    80002120:	7402                	ld	s0,32(sp)
    80002122:	64e2                	ld	s1,24(sp)
    80002124:	6942                	ld	s2,16(sp)
    80002126:	69a2                	ld	s3,8(sp)
    80002128:	6145                	addi	sp,sp,48
    8000212a:	8082                	ret
        p->state = RUNNABLE;
    8000212c:	478d                	li	a5,3
    8000212e:	cc9c                	sw	a5,24(s1)
    80002130:	b7dd                	j	80002116 <kkill+0x4a>

0000000080002132 <setkilled>:

void
setkilled(struct proc *p)
{
    80002132:	1101                	addi	sp,sp,-32
    80002134:	ec06                	sd	ra,24(sp)
    80002136:	e822                	sd	s0,16(sp)
    80002138:	e426                	sd	s1,8(sp)
    8000213a:	1000                	addi	s0,sp,32
    8000213c:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000213e:	ad3fe0ef          	jal	80000c10 <acquire>
  p->killed = 1;
    80002142:	4785                	li	a5,1
    80002144:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80002146:	8526                	mv	a0,s1
    80002148:	b61fe0ef          	jal	80000ca8 <release>
}
    8000214c:	60e2                	ld	ra,24(sp)
    8000214e:	6442                	ld	s0,16(sp)
    80002150:	64a2                	ld	s1,8(sp)
    80002152:	6105                	addi	sp,sp,32
    80002154:	8082                	ret

0000000080002156 <killed>:

int
killed(struct proc *p)
{
    80002156:	1101                	addi	sp,sp,-32
    80002158:	ec06                	sd	ra,24(sp)
    8000215a:	e822                	sd	s0,16(sp)
    8000215c:	e426                	sd	s1,8(sp)
    8000215e:	e04a                	sd	s2,0(sp)
    80002160:	1000                	addi	s0,sp,32
    80002162:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80002164:	aadfe0ef          	jal	80000c10 <acquire>
  k = p->killed;
    80002168:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    8000216c:	8526                	mv	a0,s1
    8000216e:	b3bfe0ef          	jal	80000ca8 <release>
  return k;
}
    80002172:	854a                	mv	a0,s2
    80002174:	60e2                	ld	ra,24(sp)
    80002176:	6442                	ld	s0,16(sp)
    80002178:	64a2                	ld	s1,8(sp)
    8000217a:	6902                	ld	s2,0(sp)
    8000217c:	6105                	addi	sp,sp,32
    8000217e:	8082                	ret

0000000080002180 <kwait>:
{
    80002180:	715d                	addi	sp,sp,-80
    80002182:	e486                	sd	ra,72(sp)
    80002184:	e0a2                	sd	s0,64(sp)
    80002186:	fc26                	sd	s1,56(sp)
    80002188:	f84a                	sd	s2,48(sp)
    8000218a:	f44e                	sd	s3,40(sp)
    8000218c:	f052                	sd	s4,32(sp)
    8000218e:	ec56                	sd	s5,24(sp)
    80002190:	e85a                	sd	s6,16(sp)
    80002192:	e45e                	sd	s7,8(sp)
    80002194:	e062                	sd	s8,0(sp)
    80002196:	0880                	addi	s0,sp,80
    80002198:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    8000219a:	f76ff0ef          	jal	80001910 <myproc>
    8000219e:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800021a0:	0000e517          	auipc	a0,0xe
    800021a4:	8a050513          	addi	a0,a0,-1888 # 8000fa40 <wait_lock>
    800021a8:	a69fe0ef          	jal	80000c10 <acquire>
    havekids = 0;
    800021ac:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    800021ae:	4a15                	li	s4,5
        havekids = 1;
    800021b0:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800021b2:	00013997          	auipc	s3,0x13
    800021b6:	6a698993          	addi	s3,s3,1702 # 80015858 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800021ba:	0000ec17          	auipc	s8,0xe
    800021be:	886c0c13          	addi	s8,s8,-1914 # 8000fa40 <wait_lock>
    800021c2:	a871                	j	8000225e <kwait+0xde>
          pid = pp->pid;
    800021c4:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    800021c8:	000b0c63          	beqz	s6,800021e0 <kwait+0x60>
    800021cc:	4691                	li	a3,4
    800021ce:	02c48613          	addi	a2,s1,44
    800021d2:	85da                	mv	a1,s6
    800021d4:	05093503          	ld	a0,80(s2)
    800021d8:	c4cff0ef          	jal	80001624 <copyout>
    800021dc:	02054b63          	bltz	a0,80002212 <kwait+0x92>
          freeproc(pp);
    800021e0:	8526                	mv	a0,s1
    800021e2:	8ffff0ef          	jal	80001ae0 <freeproc>
          release(&pp->lock);
    800021e6:	8526                	mv	a0,s1
    800021e8:	ac1fe0ef          	jal	80000ca8 <release>
          release(&wait_lock);
    800021ec:	0000e517          	auipc	a0,0xe
    800021f0:	85450513          	addi	a0,a0,-1964 # 8000fa40 <wait_lock>
    800021f4:	ab5fe0ef          	jal	80000ca8 <release>
}
    800021f8:	854e                	mv	a0,s3
    800021fa:	60a6                	ld	ra,72(sp)
    800021fc:	6406                	ld	s0,64(sp)
    800021fe:	74e2                	ld	s1,56(sp)
    80002200:	7942                	ld	s2,48(sp)
    80002202:	79a2                	ld	s3,40(sp)
    80002204:	7a02                	ld	s4,32(sp)
    80002206:	6ae2                	ld	s5,24(sp)
    80002208:	6b42                	ld	s6,16(sp)
    8000220a:	6ba2                	ld	s7,8(sp)
    8000220c:	6c02                	ld	s8,0(sp)
    8000220e:	6161                	addi	sp,sp,80
    80002210:	8082                	ret
            release(&pp->lock);
    80002212:	8526                	mv	a0,s1
    80002214:	a95fe0ef          	jal	80000ca8 <release>
            release(&wait_lock);
    80002218:	0000e517          	auipc	a0,0xe
    8000221c:	82850513          	addi	a0,a0,-2008 # 8000fa40 <wait_lock>
    80002220:	a89fe0ef          	jal	80000ca8 <release>
            return -1;
    80002224:	59fd                	li	s3,-1
    80002226:	bfc9                	j	800021f8 <kwait+0x78>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002228:	16848493          	addi	s1,s1,360
    8000222c:	03348063          	beq	s1,s3,8000224c <kwait+0xcc>
      if(pp->parent == p){
    80002230:	7c9c                	ld	a5,56(s1)
    80002232:	ff279be3          	bne	a5,s2,80002228 <kwait+0xa8>
        acquire(&pp->lock);
    80002236:	8526                	mv	a0,s1
    80002238:	9d9fe0ef          	jal	80000c10 <acquire>
        if(pp->state == ZOMBIE){
    8000223c:	4c9c                	lw	a5,24(s1)
    8000223e:	f94783e3          	beq	a5,s4,800021c4 <kwait+0x44>
        release(&pp->lock);
    80002242:	8526                	mv	a0,s1
    80002244:	a65fe0ef          	jal	80000ca8 <release>
        havekids = 1;
    80002248:	8756                	mv	a4,s5
    8000224a:	bff9                	j	80002228 <kwait+0xa8>
    if(!havekids || killed(p)){
    8000224c:	cf19                	beqz	a4,8000226a <kwait+0xea>
    8000224e:	854a                	mv	a0,s2
    80002250:	f07ff0ef          	jal	80002156 <killed>
    80002254:	e919                	bnez	a0,8000226a <kwait+0xea>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002256:	85e2                	mv	a1,s8
    80002258:	854a                	mv	a0,s2
    8000225a:	cc5ff0ef          	jal	80001f1e <sleep>
    havekids = 0;
    8000225e:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002260:	0000e497          	auipc	s1,0xe
    80002264:	bf848493          	addi	s1,s1,-1032 # 8000fe58 <proc>
    80002268:	b7e1                	j	80002230 <kwait+0xb0>
      release(&wait_lock);
    8000226a:	0000d517          	auipc	a0,0xd
    8000226e:	7d650513          	addi	a0,a0,2006 # 8000fa40 <wait_lock>
    80002272:	a37fe0ef          	jal	80000ca8 <release>
      return -1;
    80002276:	59fd                	li	s3,-1
    80002278:	b741                	j	800021f8 <kwait+0x78>

000000008000227a <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    8000227a:	7179                	addi	sp,sp,-48
    8000227c:	f406                	sd	ra,40(sp)
    8000227e:	f022                	sd	s0,32(sp)
    80002280:	ec26                	sd	s1,24(sp)
    80002282:	e84a                	sd	s2,16(sp)
    80002284:	e44e                	sd	s3,8(sp)
    80002286:	e052                	sd	s4,0(sp)
    80002288:	1800                	addi	s0,sp,48
    8000228a:	84aa                	mv	s1,a0
    8000228c:	892e                	mv	s2,a1
    8000228e:	89b2                	mv	s3,a2
    80002290:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002292:	e7eff0ef          	jal	80001910 <myproc>
  if(user_dst){
    80002296:	cc99                	beqz	s1,800022b4 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    80002298:	86d2                	mv	a3,s4
    8000229a:	864e                	mv	a2,s3
    8000229c:	85ca                	mv	a1,s2
    8000229e:	6928                	ld	a0,80(a0)
    800022a0:	b84ff0ef          	jal	80001624 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800022a4:	70a2                	ld	ra,40(sp)
    800022a6:	7402                	ld	s0,32(sp)
    800022a8:	64e2                	ld	s1,24(sp)
    800022aa:	6942                	ld	s2,16(sp)
    800022ac:	69a2                	ld	s3,8(sp)
    800022ae:	6a02                	ld	s4,0(sp)
    800022b0:	6145                	addi	sp,sp,48
    800022b2:	8082                	ret
    memmove((char *)dst, src, len);
    800022b4:	000a061b          	sext.w	a2,s4
    800022b8:	85ce                	mv	a1,s3
    800022ba:	854a                	mv	a0,s2
    800022bc:	a85fe0ef          	jal	80000d40 <memmove>
    return 0;
    800022c0:	8526                	mv	a0,s1
    800022c2:	b7cd                	j	800022a4 <either_copyout+0x2a>

00000000800022c4 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800022c4:	7179                	addi	sp,sp,-48
    800022c6:	f406                	sd	ra,40(sp)
    800022c8:	f022                	sd	s0,32(sp)
    800022ca:	ec26                	sd	s1,24(sp)
    800022cc:	e84a                	sd	s2,16(sp)
    800022ce:	e44e                	sd	s3,8(sp)
    800022d0:	e052                	sd	s4,0(sp)
    800022d2:	1800                	addi	s0,sp,48
    800022d4:	892a                	mv	s2,a0
    800022d6:	84ae                	mv	s1,a1
    800022d8:	89b2                	mv	s3,a2
    800022da:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800022dc:	e34ff0ef          	jal	80001910 <myproc>
  if(user_src){
    800022e0:	cc99                	beqz	s1,800022fe <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    800022e2:	86d2                	mv	a3,s4
    800022e4:	864e                	mv	a2,s3
    800022e6:	85ca                	mv	a1,s2
    800022e8:	6928                	ld	a0,80(a0)
    800022ea:	c1eff0ef          	jal	80001708 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800022ee:	70a2                	ld	ra,40(sp)
    800022f0:	7402                	ld	s0,32(sp)
    800022f2:	64e2                	ld	s1,24(sp)
    800022f4:	6942                	ld	s2,16(sp)
    800022f6:	69a2                	ld	s3,8(sp)
    800022f8:	6a02                	ld	s4,0(sp)
    800022fa:	6145                	addi	sp,sp,48
    800022fc:	8082                	ret
    memmove(dst, (char*)src, len);
    800022fe:	000a061b          	sext.w	a2,s4
    80002302:	85ce                	mv	a1,s3
    80002304:	854a                	mv	a0,s2
    80002306:	a3bfe0ef          	jal	80000d40 <memmove>
    return 0;
    8000230a:	8526                	mv	a0,s1
    8000230c:	b7cd                	j	800022ee <either_copyin+0x2a>

000000008000230e <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    8000230e:	715d                	addi	sp,sp,-80
    80002310:	e486                	sd	ra,72(sp)
    80002312:	e0a2                	sd	s0,64(sp)
    80002314:	fc26                	sd	s1,56(sp)
    80002316:	f84a                	sd	s2,48(sp)
    80002318:	f44e                	sd	s3,40(sp)
    8000231a:	f052                	sd	s4,32(sp)
    8000231c:	ec56                	sd	s5,24(sp)
    8000231e:	e85a                	sd	s6,16(sp)
    80002320:	e45e                	sd	s7,8(sp)
    80002322:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80002324:	00005517          	auipc	a0,0x5
    80002328:	d5450513          	addi	a0,a0,-684 # 80007078 <etext+0x78>
    8000232c:	9cefe0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002330:	0000e497          	auipc	s1,0xe
    80002334:	c8048493          	addi	s1,s1,-896 # 8000ffb0 <proc+0x158>
    80002338:	00013917          	auipc	s2,0x13
    8000233c:	67890913          	addi	s2,s2,1656 # 800159b0 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002340:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002342:	00005997          	auipc	s3,0x5
    80002346:	ebe98993          	addi	s3,s3,-322 # 80007200 <etext+0x200>
    printf("%d %s %s", p->pid, state, p->name);
    8000234a:	00005a97          	auipc	s5,0x5
    8000234e:	ebea8a93          	addi	s5,s5,-322 # 80007208 <etext+0x208>
    printf("\n");
    80002352:	00005a17          	auipc	s4,0x5
    80002356:	d26a0a13          	addi	s4,s4,-730 # 80007078 <etext+0x78>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000235a:	00005b97          	auipc	s7,0x5
    8000235e:	43eb8b93          	addi	s7,s7,1086 # 80007798 <states.1>
    80002362:	a829                	j	8000237c <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80002364:	ed86a583          	lw	a1,-296(a3)
    80002368:	8556                	mv	a0,s5
    8000236a:	990fe0ef          	jal	800004fa <printf>
    printf("\n");
    8000236e:	8552                	mv	a0,s4
    80002370:	98afe0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002374:	16848493          	addi	s1,s1,360
    80002378:	03248263          	beq	s1,s2,8000239c <procdump+0x8e>
    if(p->state == UNUSED)
    8000237c:	86a6                	mv	a3,s1
    8000237e:	ec04a783          	lw	a5,-320(s1)
    80002382:	dbed                	beqz	a5,80002374 <procdump+0x66>
      state = "???";
    80002384:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002386:	fcfb6fe3          	bltu	s6,a5,80002364 <procdump+0x56>
    8000238a:	02079713          	slli	a4,a5,0x20
    8000238e:	01d75793          	srli	a5,a4,0x1d
    80002392:	97de                	add	a5,a5,s7
    80002394:	6390                	ld	a2,0(a5)
    80002396:	f679                	bnez	a2,80002364 <procdump+0x56>
      state = "???";
    80002398:	864e                	mv	a2,s3
    8000239a:	b7e9                	j	80002364 <procdump+0x56>
  }
}
    8000239c:	60a6                	ld	ra,72(sp)
    8000239e:	6406                	ld	s0,64(sp)
    800023a0:	74e2                	ld	s1,56(sp)
    800023a2:	7942                	ld	s2,48(sp)
    800023a4:	79a2                	ld	s3,40(sp)
    800023a6:	7a02                	ld	s4,32(sp)
    800023a8:	6ae2                	ld	s5,24(sp)
    800023aa:	6b42                	ld	s6,16(sp)
    800023ac:	6ba2                	ld	s7,8(sp)
    800023ae:	6161                	addi	sp,sp,80
    800023b0:	8082                	ret

00000000800023b2 <getnice>:


int
getnice(int pid)
{
    800023b2:	7179                	addi	sp,sp,-48
    800023b4:	f406                	sd	ra,40(sp)
    800023b6:	f022                	sd	s0,32(sp)
    800023b8:	ec26                	sd	s1,24(sp)
    800023ba:	e84a                	sd	s2,16(sp)
    800023bc:	e44e                	sd	s3,8(sp)
    800023be:	e052                	sd	s4,0(sp)
    800023c0:	1800                	addi	s0,sp,48
    800023c2:	89aa                	mv	s3,a0
    int i = 0;
    while (i < NPROC) {
    800023c4:	0000e497          	auipc	s1,0xe
    800023c8:	a9448493          	addi	s1,s1,-1388 # 8000fe58 <proc>
    int i = 0;
    800023cc:	4901                	li	s2,0
    while (i < NPROC) {
    800023ce:	04000a13          	li	s4,64
        struct proc *p = &proc[i];
        acquire(&p->lock);
    800023d2:	8526                	mv	a0,s1
    800023d4:	83dfe0ef          	jal	80000c10 <acquire>
        if (p->pid == pid) {
    800023d8:	589c                	lw	a5,48(s1)
    800023da:	01378c63          	beq	a5,s3,800023f2 <getnice+0x40>
            int niceValue = p->nice;
            release(&p->lock);
            return niceValue;
        }
        release(&p->lock);
    800023de:	8526                	mv	a0,s1
    800023e0:	8c9fe0ef          	jal	80000ca8 <release>
        i = i + 1;
    800023e4:	2905                	addiw	s2,s2,1
    while (i < NPROC) {
    800023e6:	16848493          	addi	s1,s1,360
    800023ea:	ff4914e3          	bne	s2,s4,800023d2 <getnice+0x20>
    }
    return -1;
    800023ee:	597d                	li	s2,-1
    800023f0:	a839                	j	8000240e <getnice+0x5c>
            int niceValue = p->nice;
    800023f2:	16800793          	li	a5,360
    800023f6:	02f90933          	mul	s2,s2,a5
    800023fa:	0000e797          	auipc	a5,0xe
    800023fe:	a5e78793          	addi	a5,a5,-1442 # 8000fe58 <proc>
    80002402:	97ca                	add	a5,a5,s2
    80002404:	0347a903          	lw	s2,52(a5)
            release(&p->lock);
    80002408:	8526                	mv	a0,s1
    8000240a:	89ffe0ef          	jal	80000ca8 <release>
}
    8000240e:	854a                	mv	a0,s2
    80002410:	70a2                	ld	ra,40(sp)
    80002412:	7402                	ld	s0,32(sp)
    80002414:	64e2                	ld	s1,24(sp)
    80002416:	6942                	ld	s2,16(sp)
    80002418:	69a2                	ld	s3,8(sp)
    8000241a:	6a02                	ld	s4,0(sp)
    8000241c:	6145                	addi	sp,sp,48
    8000241e:	8082                	ret

0000000080002420 <setnice>:

int
setnice(int pid, int value)
{
    if (value < 0 || value > 39) {
    80002420:	02700793          	li	a5,39
    80002424:	06b7ec63          	bltu	a5,a1,8000249c <setnice+0x7c>
{
    80002428:	7139                	addi	sp,sp,-64
    8000242a:	fc06                	sd	ra,56(sp)
    8000242c:	f822                	sd	s0,48(sp)
    8000242e:	f426                	sd	s1,40(sp)
    80002430:	f04a                	sd	s2,32(sp)
    80002432:	ec4e                	sd	s3,24(sp)
    80002434:	e852                	sd	s4,16(sp)
    80002436:	e456                	sd	s5,8(sp)
    80002438:	0080                	addi	s0,sp,64
    8000243a:	89aa                	mv	s3,a0
    8000243c:	8aae                	mv	s5,a1
    8000243e:	0000e497          	auipc	s1,0xe
    80002442:	a1a48493          	addi	s1,s1,-1510 # 8000fe58 <proc>
        return -1;  
    }
    int i = 0;
    80002446:	4901                	li	s2,0
    while (i < NPROC) {
    80002448:	04000a13          	li	s4,64
        struct proc *p = &proc[i];
        acquire(&p->lock);
    8000244c:	8526                	mv	a0,s1
    8000244e:	fc2fe0ef          	jal	80000c10 <acquire>
        if (p->pid == pid) {
    80002452:	589c                	lw	a5,48(s1)
    80002454:	01378c63          	beq	a5,s3,8000246c <setnice+0x4c>
            p->nice = value;
            release(&p->lock);
            return 0;
        }
        release(&p->lock);
    80002458:	8526                	mv	a0,s1
    8000245a:	84ffe0ef          	jal	80000ca8 <release>
        i = i + 1;
    8000245e:	2905                	addiw	s2,s2,1
    while (i < NPROC) {
    80002460:	16848493          	addi	s1,s1,360
    80002464:	ff4914e3          	bne	s2,s4,8000244c <setnice+0x2c>
    }
    return -1;
    80002468:	557d                	li	a0,-1
    8000246a:	a005                	j	8000248a <setnice+0x6a>
            p->nice = value;
    8000246c:	16800793          	li	a5,360
    80002470:	02f90933          	mul	s2,s2,a5
    80002474:	0000e797          	auipc	a5,0xe
    80002478:	9e478793          	addi	a5,a5,-1564 # 8000fe58 <proc>
    8000247c:	97ca                	add	a5,a5,s2
    8000247e:	0357aa23          	sw	s5,52(a5)
            release(&p->lock);
    80002482:	8526                	mv	a0,s1
    80002484:	825fe0ef          	jal	80000ca8 <release>
            return 0;
    80002488:	4501                	li	a0,0
}
    8000248a:	70e2                	ld	ra,56(sp)
    8000248c:	7442                	ld	s0,48(sp)
    8000248e:	74a2                	ld	s1,40(sp)
    80002490:	7902                	ld	s2,32(sp)
    80002492:	69e2                	ld	s3,24(sp)
    80002494:	6a42                	ld	s4,16(sp)
    80002496:	6aa2                	ld	s5,8(sp)
    80002498:	6121                	addi	sp,sp,64
    8000249a:	8082                	ret
        return -1;  
    8000249c:	557d                	li	a0,-1
}
    8000249e:	8082                	ret

00000000800024a0 <ps>:

void
ps(int pid)
{
    800024a0:	715d                	addi	sp,sp,-80
    800024a2:	e486                	sd	ra,72(sp)
    800024a4:	e0a2                	sd	s0,64(sp)
    800024a6:	fc26                	sd	s1,56(sp)
    800024a8:	f84a                	sd	s2,48(sp)
    800024aa:	f44e                	sd	s3,40(sp)
    800024ac:	f052                	sd	s4,32(sp)
    800024ae:	ec56                	sd	s5,24(sp)
    800024b0:	e85a                	sd	s6,16(sp)
    800024b2:	e45e                	sd	s7,8(sp)
    800024b4:	e062                	sd	s8,0(sp)
    800024b6:	0880                	addi	s0,sp,80
    800024b8:	8a2a                	mv	s4,a0
    [ZOMBIE]    "ZOMBIE"
  };

  int printed = 0;
  int i = 0;
  while (i < NPROC){
    800024ba:	0000e497          	auipc	s1,0xe
    800024be:	99e48493          	addi	s1,s1,-1634 # 8000fe58 <proc>
    800024c2:	0000e917          	auipc	s2,0xe
    800024c6:	aee90913          	addi	s2,s2,-1298 # 8000ffb0 <proc+0x158>
{
    800024ca:	4985                	li	s3,1
  int printed = 0;
    800024cc:	4c01                	li	s8,0
  while (i < NPROC){
    800024ce:	04100b93          	li	s7,65
    800024d2:	a841                	j	80002562 <ps+0xc2>
    struct proc *p = &proc[i];

    if(p == myproc()){  // 자기 자신은 락 없이 처리
      if(pid == 0 || p->pid == pid){
    800024d4:	120a0763          	beqz	s4,80002602 <ps+0x162>
    800024d8:	ed892783          	lw	a5,-296(s2)
    800024dc:	07479c63          	bne	a5,s4,80002554 <ps+0xb4>
        if(printed == 0){ printf("name\t\tpid\tstate\t\tpriority\n"); printed = 1; }
    800024e0:	180c0463          	beqz	s8,80002668 <ps+0x1c8>
        printf("%s\t\t%d\t%s\t\t%d\n", p->name, p->pid, states[p->state], p->nice);
    800024e4:	0000e597          	auipc	a1,0xe
    800024e8:	97458593          	addi	a1,a1,-1676 # 8000fe58 <proc>
    800024ec:	16800793          	li	a5,360
    800024f0:	02fb07b3          	mul	a5,s6,a5
    800024f4:	00f58633          	add	a2,a1,a5
    800024f8:	01866703          	lwu	a4,24(a2) # 1018 <_entry-0x7fffefe8>
    800024fc:	070e                	slli	a4,a4,0x3
    800024fe:	00005697          	auipc	a3,0x5
    80002502:	29a68693          	addi	a3,a3,666 # 80007798 <states.1>
    80002506:	96ba                	add	a3,a3,a4
    80002508:	15878793          	addi	a5,a5,344
    8000250c:	5a58                	lw	a4,52(a2)
    8000250e:	7a94                	ld	a3,48(a3)
    80002510:	5a10                	lw	a2,48(a2)
    80002512:	95be                	add	a1,a1,a5
    80002514:	00005517          	auipc	a0,0x5
    80002518:	d2450513          	addi	a0,a0,-732 # 80007238 <etext+0x238>
    8000251c:	fdffd0ef          	jal	800004fa <printf>
      }
    }
    release(&p->lock);
    i++;
  }
}
    80002520:	60a6                	ld	ra,72(sp)
    80002522:	6406                	ld	s0,64(sp)
    80002524:	74e2                	ld	s1,56(sp)
    80002526:	7942                	ld	s2,48(sp)
    80002528:	79a2                	ld	s3,40(sp)
    8000252a:	7a02                	ld	s4,32(sp)
    8000252c:	6ae2                	ld	s5,24(sp)
    8000252e:	6b42                	ld	s6,16(sp)
    80002530:	6ba2                	ld	s7,8(sp)
    80002532:	6c02                	ld	s8,0(sp)
    80002534:	6161                	addi	sp,sp,80
    80002536:	8082                	ret
        if(printed == 0){ printf("name\t\tpid\tstate\t\tpriority\n"); printed = 1; }
    80002538:	00005517          	auipc	a0,0x5
    8000253c:	ce050513          	addi	a0,a0,-800 # 80007218 <etext+0x218>
    80002540:	fbbfd0ef          	jal	800004fa <printf>
    80002544:	a089                	j	80002586 <ps+0xe6>
      if(p->pid == pid){
    80002546:	ed892783          	lw	a5,-296(s2)
    8000254a:	07478463          	beq	a5,s4,800025b2 <ps+0x112>
    release(&p->lock);
    8000254e:	8556                	mv	a0,s5
    80002550:	f58fe0ef          	jal	80000ca8 <release>
  while (i < NPROC){
    80002554:	16848493          	addi	s1,s1,360
    80002558:	2985                	addiw	s3,s3,1
    8000255a:	16890913          	addi	s2,s2,360
    8000255e:	fd7981e3          	beq	s3,s7,80002520 <ps+0x80>
    80002562:	fff98b1b          	addiw	s6,s3,-1
    struct proc *p = &proc[i];
    80002566:	8aa6                	mv	s5,s1
    if(p == myproc()){  // 자기 자신은 락 없이 처리
    80002568:	ba8ff0ef          	jal	80001910 <myproc>
    8000256c:	f69504e3          	beq	a0,s1,800024d4 <ps+0x34>
    acquire(&p->lock);
    80002570:	8526                	mv	a0,s1
    80002572:	e9efe0ef          	jal	80000c10 <acquire>
    if(pid == 0){
    80002576:	fc0a18e3          	bnez	s4,80002546 <ps+0xa6>
      if(p->state != UNUSED){
    8000257a:	8b4a                	mv	s6,s2
    8000257c:	ec092783          	lw	a5,-320(s2)
    80002580:	d7f9                	beqz	a5,8000254e <ps+0xae>
        if(printed == 0){ printf("name\t\tpid\tstate\t\tpriority\n"); printed = 1; }
    80002582:	fa0c0be3          	beqz	s8,80002538 <ps+0x98>
        printf("%s\t\t%d\t%s\t\t%d\n", p->name, p->pid, states[p->state], p->nice);
    80002586:	ec0b6703          	lwu	a4,-320(s6)
    8000258a:	070e                	slli	a4,a4,0x3
    8000258c:	00005797          	auipc	a5,0x5
    80002590:	20c78793          	addi	a5,a5,524 # 80007798 <states.1>
    80002594:	97ba                	add	a5,a5,a4
    80002596:	edcb2703          	lw	a4,-292(s6)
    8000259a:	7b94                	ld	a3,48(a5)
    8000259c:	ed8b2603          	lw	a2,-296(s6)
    800025a0:	85da                	mv	a1,s6
    800025a2:	00005517          	auipc	a0,0x5
    800025a6:	c9650513          	addi	a0,a0,-874 # 80007238 <etext+0x238>
    800025aa:	f51fd0ef          	jal	800004fa <printf>
    800025ae:	4c05                	li	s8,1
    800025b0:	bf79                	j	8000254e <ps+0xae>
        printf("name\t\tpid\tstate\t\tpriority\n");
    800025b2:	00005517          	auipc	a0,0x5
    800025b6:	c6650513          	addi	a0,a0,-922 # 80007218 <etext+0x218>
    800025ba:	f41fd0ef          	jal	800004fa <printf>
        printf("%s\t\t%d\t%s\t\t%d\n", p->name, p->pid, states[p->state], p->nice);
    800025be:	0000e597          	auipc	a1,0xe
    800025c2:	89a58593          	addi	a1,a1,-1894 # 8000fe58 <proc>
    800025c6:	16800793          	li	a5,360
    800025ca:	02fb07b3          	mul	a5,s6,a5
    800025ce:	00f58633          	add	a2,a1,a5
    800025d2:	01866703          	lwu	a4,24(a2)
    800025d6:	070e                	slli	a4,a4,0x3
    800025d8:	00005697          	auipc	a3,0x5
    800025dc:	1c068693          	addi	a3,a3,448 # 80007798 <states.1>
    800025e0:	96ba                	add	a3,a3,a4
    800025e2:	15878793          	addi	a5,a5,344
    800025e6:	5a58                	lw	a4,52(a2)
    800025e8:	7a94                	ld	a3,48(a3)
    800025ea:	5a10                	lw	a2,48(a2)
    800025ec:	95be                	add	a1,a1,a5
    800025ee:	00005517          	auipc	a0,0x5
    800025f2:	c4a50513          	addi	a0,a0,-950 # 80007238 <etext+0x238>
    800025f6:	f05fd0ef          	jal	800004fa <printf>
        release(&p->lock);
    800025fa:	8526                	mv	a0,s1
    800025fc:	eacfe0ef          	jal	80000ca8 <release>
        return;
    80002600:	b705                	j	80002520 <ps+0x80>
        if(printed == 0){ printf("name\t\tpid\tstate\t\tpriority\n"); printed = 1; }
    80002602:	020c0763          	beqz	s8,80002630 <ps+0x190>
        printf("%s\t\t%d\t%s\t\t%d\n", p->name, p->pid, states[p->state], p->nice);
    80002606:	ec096703          	lwu	a4,-320(s2)
    8000260a:	070e                	slli	a4,a4,0x3
    8000260c:	00005797          	auipc	a5,0x5
    80002610:	18c78793          	addi	a5,a5,396 # 80007798 <states.1>
    80002614:	97ba                	add	a5,a5,a4
    80002616:	edc92703          	lw	a4,-292(s2)
    8000261a:	7b94                	ld	a3,48(a5)
    8000261c:	ed892603          	lw	a2,-296(s2)
    80002620:	85ca                	mv	a1,s2
    80002622:	00005517          	auipc	a0,0x5
    80002626:	c1650513          	addi	a0,a0,-1002 # 80007238 <etext+0x238>
    8000262a:	ed1fd0ef          	jal	800004fa <printf>
        if(pid != 0) return;
    8000262e:	b71d                	j	80002554 <ps+0xb4>
        if(printed == 0){ printf("name\t\tpid\tstate\t\tpriority\n"); printed = 1; }
    80002630:	00005517          	auipc	a0,0x5
    80002634:	be850513          	addi	a0,a0,-1048 # 80007218 <etext+0x218>
    80002638:	ec3fd0ef          	jal	800004fa <printf>
        printf("%s\t\t%d\t%s\t\t%d\n", p->name, p->pid, states[p->state], p->nice);
    8000263c:	ec096703          	lwu	a4,-320(s2)
    80002640:	070e                	slli	a4,a4,0x3
    80002642:	00005797          	auipc	a5,0x5
    80002646:	15678793          	addi	a5,a5,342 # 80007798 <states.1>
    8000264a:	97ba                	add	a5,a5,a4
    8000264c:	edc92703          	lw	a4,-292(s2)
    80002650:	7b94                	ld	a3,48(a5)
    80002652:	ed892603          	lw	a2,-296(s2)
    80002656:	85ca                	mv	a1,s2
    80002658:	00005517          	auipc	a0,0x5
    8000265c:	be050513          	addi	a0,a0,-1056 # 80007238 <etext+0x238>
    80002660:	e9bfd0ef          	jal	800004fa <printf>
    80002664:	4c05                	li	s8,1
    80002666:	b5fd                	j	80002554 <ps+0xb4>
        if(printed == 0){ printf("name\t\tpid\tstate\t\tpriority\n"); printed = 1; }
    80002668:	00005517          	auipc	a0,0x5
    8000266c:	bb050513          	addi	a0,a0,-1104 # 80007218 <etext+0x218>
    80002670:	e8bfd0ef          	jal	800004fa <printf>
        printf("%s\t\t%d\t%s\t\t%d\n", p->name, p->pid, states[p->state], p->nice);
    80002674:	ec096703          	lwu	a4,-320(s2)
    80002678:	070e                	slli	a4,a4,0x3
    8000267a:	00005797          	auipc	a5,0x5
    8000267e:	11e78793          	addi	a5,a5,286 # 80007798 <states.1>
    80002682:	97ba                	add	a5,a5,a4
    80002684:	edc92703          	lw	a4,-292(s2)
    80002688:	7b94                	ld	a3,48(a5)
    8000268a:	ed892603          	lw	a2,-296(s2)
    8000268e:	85ca                	mv	a1,s2
    80002690:	00005517          	auipc	a0,0x5
    80002694:	ba850513          	addi	a0,a0,-1112 # 80007238 <etext+0x238>
    80002698:	e63fd0ef          	jal	800004fa <printf>
        if(pid != 0) return;
    8000269c:	b551                	j	80002520 <ps+0x80>

000000008000269e <meminfo>:

uint64
meminfo(void)
{
    8000269e:	1141                	addi	sp,sp,-16
    800026a0:	e406                	sd	ra,8(sp)
    800026a2:	e022                	sd	s0,0(sp)
    800026a4:	0800                	addi	s0,sp,16
  return memory_available();
    800026a6:	ca8fe0ef          	jal	80000b4e <memory_available>
}
    800026aa:	60a2                	ld	ra,8(sp)
    800026ac:	6402                	ld	s0,0(sp)
    800026ae:	0141                	addi	sp,sp,16
    800026b0:	8082                	ret

00000000800026b2 <waitpid>:

int
waitpid(int pid)
{
    800026b2:	7159                	addi	sp,sp,-112
    800026b4:	f486                	sd	ra,104(sp)
    800026b6:	f0a2                	sd	s0,96(sp)
    800026b8:	eca6                	sd	s1,88(sp)
    800026ba:	e8ca                	sd	s2,80(sp)
    800026bc:	e4ce                	sd	s3,72(sp)
    800026be:	e0d2                	sd	s4,64(sp)
    800026c0:	fc56                	sd	s5,56(sp)
    800026c2:	f85a                	sd	s6,48(sp)
    800026c4:	f45e                	sd	s7,40(sp)
    800026c6:	f062                	sd	s8,32(sp)
    800026c8:	ec66                	sd	s9,24(sp)
    800026ca:	e86a                	sd	s10,16(sp)
    800026cc:	e46e                	sd	s11,8(sp)
    800026ce:	1880                	addi	s0,sp,112
    800026d0:	8a2a                	mv	s4,a0
  struct proc *myp = myproc();
    800026d2:	a3eff0ef          	jal	80001910 <myproc>
    800026d6:	8b2a                	mv	s6,a0

  acquire(&wait_lock);
    800026d8:	0000d517          	auipc	a0,0xd
    800026dc:	36850513          	addi	a0,a0,872 # 8000fa40 <wait_lock>
    800026e0:	d30fe0ef          	jal	80000c10 <acquire>

  while (1){
    int found = 0;
    int i = 0;
    800026e4:	4b81                	li	s7,0
    while (i < NPROC){
    800026e6:	04000a93          	li	s5,64
      struct proc *p = &proc[i];
      acquire(&p->lock);
      if(p->pid == pid && p->parent == myp){
        found = 1;
        if(p->state == ZOMBIE){
    800026ea:	0000dd17          	auipc	s10,0xd
    800026ee:	76ed0d13          	addi	s10,s10,1902 # 8000fe58 <proc>
    800026f2:	16800c93          	li	s9,360
    800026f6:	4c15                	li	s8,5
      release(&wait_lock);
      return -1;
    }

    // 자식이 종료될 때까지 sleep (kexit에서 wakeup(p->parent) 호출함)
    sleep(myp, &wait_lock);
    800026f8:	0000dd97          	auipc	s11,0xd
    800026fc:	348d8d93          	addi	s11,s11,840 # 8000fa40 <wait_lock>
    80002700:	a8b9                	j	8000275e <waitpid+0xac>
          freeproc(p);
    80002702:	8526                	mv	a0,s1
    80002704:	bdcff0ef          	jal	80001ae0 <freeproc>
          release(&p->lock);
    80002708:	8526                	mv	a0,s1
    8000270a:	d9efe0ef          	jal	80000ca8 <release>
          release(&wait_lock);
    8000270e:	0000d517          	auipc	a0,0xd
    80002712:	33250513          	addi	a0,a0,818 # 8000fa40 <wait_lock>
    80002716:	d92fe0ef          	jal	80000ca8 <release>
          return 0;
    8000271a:	4501                	li	a0,0
    8000271c:	a8b1                	j	80002778 <waitpid+0xc6>
      release(&p->lock);
    8000271e:	854e                	mv	a0,s3
    80002720:	d88fe0ef          	jal	80000ca8 <release>
      i++;
    80002724:	2905                	addiw	s2,s2,1
    while (i < NPROC){
    80002726:	16848493          	addi	s1,s1,360
    8000272a:	05590063          	beq	s2,s5,8000276a <waitpid+0xb8>
      struct proc *p = &proc[i];
    8000272e:	89a6                	mv	s3,s1
      acquire(&p->lock);
    80002730:	8526                	mv	a0,s1
    80002732:	cdefe0ef          	jal	80000c10 <acquire>
      if(p->pid == pid && p->parent == myp){
    80002736:	589c                	lw	a5,48(s1)
    80002738:	ff4793e3          	bne	a5,s4,8000271e <waitpid+0x6c>
    8000273c:	7c9c                	ld	a5,56(s1)
    8000273e:	ff6790e3          	bne	a5,s6,8000271e <waitpid+0x6c>
        if(p->state == ZOMBIE){
    80002742:	03990933          	mul	s2,s2,s9
    80002746:	996a                	add	s2,s2,s10
    80002748:	01892783          	lw	a5,24(s2)
    8000274c:	fb878be3          	beq	a5,s8,80002702 <waitpid+0x50>
        release(&p->lock);
    80002750:	8526                	mv	a0,s1
    80002752:	d56fe0ef          	jal	80000ca8 <release>
    sleep(myp, &wait_lock);
    80002756:	85ee                	mv	a1,s11
    80002758:	855a                	mv	a0,s6
    8000275a:	fc4ff0ef          	jal	80001f1e <sleep>
    while (i < NPROC){
    8000275e:	0000d497          	auipc	s1,0xd
    80002762:	6fa48493          	addi	s1,s1,1786 # 8000fe58 <proc>
    int i = 0;
    80002766:	895e                	mv	s2,s7
    80002768:	b7d9                	j	8000272e <waitpid+0x7c>
      release(&wait_lock);
    8000276a:	0000d517          	auipc	a0,0xd
    8000276e:	2d650513          	addi	a0,a0,726 # 8000fa40 <wait_lock>
    80002772:	d36fe0ef          	jal	80000ca8 <release>
      return -1;
    80002776:	557d                	li	a0,-1
  }
    80002778:	70a6                	ld	ra,104(sp)
    8000277a:	7406                	ld	s0,96(sp)
    8000277c:	64e6                	ld	s1,88(sp)
    8000277e:	6946                	ld	s2,80(sp)
    80002780:	69a6                	ld	s3,72(sp)
    80002782:	6a06                	ld	s4,64(sp)
    80002784:	7ae2                	ld	s5,56(sp)
    80002786:	7b42                	ld	s6,48(sp)
    80002788:	7ba2                	ld	s7,40(sp)
    8000278a:	7c02                	ld	s8,32(sp)
    8000278c:	6ce2                	ld	s9,24(sp)
    8000278e:	6d42                	ld	s10,16(sp)
    80002790:	6da2                	ld	s11,8(sp)
    80002792:	6165                	addi	sp,sp,112
    80002794:	8082                	ret

0000000080002796 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    80002796:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    8000279a:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    8000279e:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    800027a0:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    800027a2:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    800027a6:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    800027aa:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    800027ae:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    800027b2:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    800027b6:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    800027ba:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    800027be:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    800027c2:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    800027c6:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    800027ca:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    800027ce:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    800027d2:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    800027d4:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    800027d6:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    800027da:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    800027de:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    800027e2:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    800027e6:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    800027ea:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    800027ee:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    800027f2:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    800027f6:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    800027fa:	0685bd83          	ld	s11,104(a1)
        
        ret
    800027fe:	8082                	ret

0000000080002800 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80002800:	1141                	addi	sp,sp,-16
    80002802:	e406                	sd	ra,8(sp)
    80002804:	e022                	sd	s0,0(sp)
    80002806:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002808:	00005597          	auipc	a1,0x5
    8000280c:	ab058593          	addi	a1,a1,-1360 # 800072b8 <etext+0x2b8>
    80002810:	00013517          	auipc	a0,0x13
    80002814:	04850513          	addi	a0,a0,72 # 80015858 <tickslock>
    80002818:	b78fe0ef          	jal	80000b90 <initlock>
}
    8000281c:	60a2                	ld	ra,8(sp)
    8000281e:	6402                	ld	s0,0(sp)
    80002820:	0141                	addi	sp,sp,16
    80002822:	8082                	ret

0000000080002824 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002824:	1141                	addi	sp,sp,-16
    80002826:	e422                	sd	s0,8(sp)
    80002828:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000282a:	00003797          	auipc	a5,0x3
    8000282e:	ff678793          	addi	a5,a5,-10 # 80005820 <kernelvec>
    80002832:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002836:	6422                	ld	s0,8(sp)
    80002838:	0141                	addi	sp,sp,16
    8000283a:	8082                	ret

000000008000283c <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    8000283c:	1141                	addi	sp,sp,-16
    8000283e:	e406                	sd	ra,8(sp)
    80002840:	e022                	sd	s0,0(sp)
    80002842:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002844:	8ccff0ef          	jal	80001910 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002848:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000284c:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000284e:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002852:	04000737          	lui	a4,0x4000
    80002856:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80002858:	0732                	slli	a4,a4,0xc
    8000285a:	00003797          	auipc	a5,0x3
    8000285e:	7a678793          	addi	a5,a5,1958 # 80006000 <_trampoline>
    80002862:	00003697          	auipc	a3,0x3
    80002866:	79e68693          	addi	a3,a3,1950 # 80006000 <_trampoline>
    8000286a:	8f95                	sub	a5,a5,a3
    8000286c:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000286e:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002872:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80002874:	18002773          	csrr	a4,satp
    80002878:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000287a:	6d38                	ld	a4,88(a0)
    8000287c:	613c                	ld	a5,64(a0)
    8000287e:	6685                	lui	a3,0x1
    80002880:	97b6                	add	a5,a5,a3
    80002882:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002884:	6d3c                	ld	a5,88(a0)
    80002886:	00000717          	auipc	a4,0x0
    8000288a:	0f870713          	addi	a4,a4,248 # 8000297e <usertrap>
    8000288e:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80002890:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80002892:	8712                	mv	a4,tp
    80002894:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002896:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000289a:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    8000289e:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800028a2:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800028a6:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    800028a8:	6f9c                	ld	a5,24(a5)
    800028aa:	14179073          	csrw	sepc,a5
}
    800028ae:	60a2                	ld	ra,8(sp)
    800028b0:	6402                	ld	s0,0(sp)
    800028b2:	0141                	addi	sp,sp,16
    800028b4:	8082                	ret

00000000800028b6 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800028b6:	1101                	addi	sp,sp,-32
    800028b8:	ec06                	sd	ra,24(sp)
    800028ba:	e822                	sd	s0,16(sp)
    800028bc:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    800028be:	826ff0ef          	jal	800018e4 <cpuid>
    800028c2:	cd11                	beqz	a0,800028de <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    800028c4:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800028c8:	000f4737          	lui	a4,0xf4
    800028cc:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800028d0:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    800028d2:	14d79073          	csrw	stimecmp,a5
}
    800028d6:	60e2                	ld	ra,24(sp)
    800028d8:	6442                	ld	s0,16(sp)
    800028da:	6105                	addi	sp,sp,32
    800028dc:	8082                	ret
    800028de:	e426                	sd	s1,8(sp)
    acquire(&tickslock);
    800028e0:	00013497          	auipc	s1,0x13
    800028e4:	f7848493          	addi	s1,s1,-136 # 80015858 <tickslock>
    800028e8:	8526                	mv	a0,s1
    800028ea:	b26fe0ef          	jal	80000c10 <acquire>
    ticks++;
    800028ee:	00005517          	auipc	a0,0x5
    800028f2:	03a50513          	addi	a0,a0,58 # 80007928 <ticks>
    800028f6:	411c                	lw	a5,0(a0)
    800028f8:	2785                	addiw	a5,a5,1
    800028fa:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    800028fc:	e6eff0ef          	jal	80001f6a <wakeup>
    release(&tickslock);
    80002900:	8526                	mv	a0,s1
    80002902:	ba6fe0ef          	jal	80000ca8 <release>
    80002906:	64a2                	ld	s1,8(sp)
    80002908:	bf75                	j	800028c4 <clockintr+0xe>

000000008000290a <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    8000290a:	1101                	addi	sp,sp,-32
    8000290c:	ec06                	sd	ra,24(sp)
    8000290e:	e822                	sd	s0,16(sp)
    80002910:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002912:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80002916:	57fd                	li	a5,-1
    80002918:	17fe                	slli	a5,a5,0x3f
    8000291a:	07a5                	addi	a5,a5,9
    8000291c:	00f70c63          	beq	a4,a5,80002934 <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80002920:	57fd                	li	a5,-1
    80002922:	17fe                	slli	a5,a5,0x3f
    80002924:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002926:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80002928:	04f70763          	beq	a4,a5,80002976 <devintr+0x6c>
  }
}
    8000292c:	60e2                	ld	ra,24(sp)
    8000292e:	6442                	ld	s0,16(sp)
    80002930:	6105                	addi	sp,sp,32
    80002932:	8082                	ret
    80002934:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80002936:	797020ef          	jal	800058cc <plic_claim>
    8000293a:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    8000293c:	47a9                	li	a5,10
    8000293e:	00f50963          	beq	a0,a5,80002950 <devintr+0x46>
    } else if(irq == VIRTIO0_IRQ){
    80002942:	4785                	li	a5,1
    80002944:	00f50963          	beq	a0,a5,80002956 <devintr+0x4c>
    return 1;
    80002948:	4505                	li	a0,1
    } else if(irq){
    8000294a:	e889                	bnez	s1,8000295c <devintr+0x52>
    8000294c:	64a2                	ld	s1,8(sp)
    8000294e:	bff9                	j	8000292c <devintr+0x22>
      uartintr();
    80002950:	860fe0ef          	jal	800009b0 <uartintr>
    if(irq)
    80002954:	a819                	j	8000296a <devintr+0x60>
      virtio_disk_intr();
    80002956:	43c030ef          	jal	80005d92 <virtio_disk_intr>
    if(irq)
    8000295a:	a801                	j	8000296a <devintr+0x60>
      printf("unexpected interrupt irq=%d\n", irq);
    8000295c:	85a6                	mv	a1,s1
    8000295e:	00005517          	auipc	a0,0x5
    80002962:	96250513          	addi	a0,a0,-1694 # 800072c0 <etext+0x2c0>
    80002966:	b95fd0ef          	jal	800004fa <printf>
      plic_complete(irq);
    8000296a:	8526                	mv	a0,s1
    8000296c:	781020ef          	jal	800058ec <plic_complete>
    return 1;
    80002970:	4505                	li	a0,1
    80002972:	64a2                	ld	s1,8(sp)
    80002974:	bf65                	j	8000292c <devintr+0x22>
    clockintr();
    80002976:	f41ff0ef          	jal	800028b6 <clockintr>
    return 2;
    8000297a:	4509                	li	a0,2
    8000297c:	bf45                	j	8000292c <devintr+0x22>

000000008000297e <usertrap>:
{
    8000297e:	1101                	addi	sp,sp,-32
    80002980:	ec06                	sd	ra,24(sp)
    80002982:	e822                	sd	s0,16(sp)
    80002984:	e426                	sd	s1,8(sp)
    80002986:	e04a                	sd	s2,0(sp)
    80002988:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000298a:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    8000298e:	1007f793          	andi	a5,a5,256
    80002992:	eba5                	bnez	a5,80002a02 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002994:	00003797          	auipc	a5,0x3
    80002998:	e8c78793          	addi	a5,a5,-372 # 80005820 <kernelvec>
    8000299c:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800029a0:	f71fe0ef          	jal	80001910 <myproc>
    800029a4:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800029a6:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800029a8:	14102773          	csrr	a4,sepc
    800029ac:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    800029ae:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800029b2:	47a1                	li	a5,8
    800029b4:	04f70d63          	beq	a4,a5,80002a0e <usertrap+0x90>
  } else if((which_dev = devintr()) != 0){
    800029b8:	f53ff0ef          	jal	8000290a <devintr>
    800029bc:	892a                	mv	s2,a0
    800029be:	e945                	bnez	a0,80002a6e <usertrap+0xf0>
    800029c0:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    800029c4:	47bd                	li	a5,15
    800029c6:	08f70863          	beq	a4,a5,80002a56 <usertrap+0xd8>
    800029ca:	14202773          	csrr	a4,scause
    800029ce:	47b5                	li	a5,13
    800029d0:	08f70363          	beq	a4,a5,80002a56 <usertrap+0xd8>
    800029d4:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    800029d8:	5890                	lw	a2,48(s1)
    800029da:	00005517          	auipc	a0,0x5
    800029de:	92650513          	addi	a0,a0,-1754 # 80007300 <etext+0x300>
    800029e2:	b19fd0ef          	jal	800004fa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800029e6:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800029ea:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    800029ee:	00005517          	auipc	a0,0x5
    800029f2:	94250513          	addi	a0,a0,-1726 # 80007330 <etext+0x330>
    800029f6:	b05fd0ef          	jal	800004fa <printf>
    setkilled(p);
    800029fa:	8526                	mv	a0,s1
    800029fc:	f36ff0ef          	jal	80002132 <setkilled>
    80002a00:	a035                	j	80002a2c <usertrap+0xae>
    panic("usertrap: not from user mode");
    80002a02:	00005517          	auipc	a0,0x5
    80002a06:	8de50513          	addi	a0,a0,-1826 # 800072e0 <etext+0x2e0>
    80002a0a:	dd7fd0ef          	jal	800007e0 <panic>
    if(killed(p))
    80002a0e:	f48ff0ef          	jal	80002156 <killed>
    80002a12:	ed15                	bnez	a0,80002a4e <usertrap+0xd0>
    p->trapframe->epc += 4;
    80002a14:	6cb8                	ld	a4,88(s1)
    80002a16:	6f1c                	ld	a5,24(a4)
    80002a18:	0791                	addi	a5,a5,4
    80002a1a:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002a1c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80002a20:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002a24:	10079073          	csrw	sstatus,a5
    syscall();
    80002a28:	246000ef          	jal	80002c6e <syscall>
  if(killed(p))
    80002a2c:	8526                	mv	a0,s1
    80002a2e:	f28ff0ef          	jal	80002156 <killed>
    80002a32:	e139                	bnez	a0,80002a78 <usertrap+0xfa>
  prepare_return();
    80002a34:	e09ff0ef          	jal	8000283c <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80002a38:	68a8                	ld	a0,80(s1)
    80002a3a:	8131                	srli	a0,a0,0xc
    80002a3c:	57fd                	li	a5,-1
    80002a3e:	17fe                	slli	a5,a5,0x3f
    80002a40:	8d5d                	or	a0,a0,a5
}
    80002a42:	60e2                	ld	ra,24(sp)
    80002a44:	6442                	ld	s0,16(sp)
    80002a46:	64a2                	ld	s1,8(sp)
    80002a48:	6902                	ld	s2,0(sp)
    80002a4a:	6105                	addi	sp,sp,32
    80002a4c:	8082                	ret
      kexit(-1);
    80002a4e:	557d                	li	a0,-1
    80002a50:	ddaff0ef          	jal	8000202a <kexit>
    80002a54:	b7c1                	j	80002a14 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002a56:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002a5a:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    80002a5e:	164d                	addi	a2,a2,-13
    80002a60:	00163613          	seqz	a2,a2
    80002a64:	68a8                	ld	a0,80(s1)
    80002a66:	b3dfe0ef          	jal	800015a2 <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    80002a6a:	f169                	bnez	a0,80002a2c <usertrap+0xae>
    80002a6c:	b7a5                	j	800029d4 <usertrap+0x56>
  if(killed(p))
    80002a6e:	8526                	mv	a0,s1
    80002a70:	ee6ff0ef          	jal	80002156 <killed>
    80002a74:	c511                	beqz	a0,80002a80 <usertrap+0x102>
    80002a76:	a011                	j	80002a7a <usertrap+0xfc>
    80002a78:	4901                	li	s2,0
    kexit(-1);
    80002a7a:	557d                	li	a0,-1
    80002a7c:	daeff0ef          	jal	8000202a <kexit>
  if(which_dev == 2)
    80002a80:	4789                	li	a5,2
    80002a82:	faf919e3          	bne	s2,a5,80002a34 <usertrap+0xb6>
    yield();
    80002a86:	c6cff0ef          	jal	80001ef2 <yield>
    80002a8a:	b76d                	j	80002a34 <usertrap+0xb6>

0000000080002a8c <kerneltrap>:
{
    80002a8c:	7179                	addi	sp,sp,-48
    80002a8e:	f406                	sd	ra,40(sp)
    80002a90:	f022                	sd	s0,32(sp)
    80002a92:	ec26                	sd	s1,24(sp)
    80002a94:	e84a                	sd	s2,16(sp)
    80002a96:	e44e                	sd	s3,8(sp)
    80002a98:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002a9a:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002a9e:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002aa2:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    80002aa6:	1004f793          	andi	a5,s1,256
    80002aaa:	c795                	beqz	a5,80002ad6 <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002aac:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002ab0:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80002ab2:	eb85                	bnez	a5,80002ae2 <kerneltrap+0x56>
  if((which_dev = devintr()) == 0){
    80002ab4:	e57ff0ef          	jal	8000290a <devintr>
    80002ab8:	c91d                	beqz	a0,80002aee <kerneltrap+0x62>
  if(which_dev == 2 && myproc() != 0)
    80002aba:	4789                	li	a5,2
    80002abc:	04f50a63          	beq	a0,a5,80002b10 <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002ac0:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002ac4:	10049073          	csrw	sstatus,s1
}
    80002ac8:	70a2                	ld	ra,40(sp)
    80002aca:	7402                	ld	s0,32(sp)
    80002acc:	64e2                	ld	s1,24(sp)
    80002ace:	6942                	ld	s2,16(sp)
    80002ad0:	69a2                	ld	s3,8(sp)
    80002ad2:	6145                	addi	sp,sp,48
    80002ad4:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002ad6:	00005517          	auipc	a0,0x5
    80002ada:	88250513          	addi	a0,a0,-1918 # 80007358 <etext+0x358>
    80002ade:	d03fd0ef          	jal	800007e0 <panic>
    panic("kerneltrap: interrupts enabled");
    80002ae2:	00005517          	auipc	a0,0x5
    80002ae6:	89e50513          	addi	a0,a0,-1890 # 80007380 <etext+0x380>
    80002aea:	cf7fd0ef          	jal	800007e0 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002aee:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002af2:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80002af6:	85ce                	mv	a1,s3
    80002af8:	00005517          	auipc	a0,0x5
    80002afc:	8a850513          	addi	a0,a0,-1880 # 800073a0 <etext+0x3a0>
    80002b00:	9fbfd0ef          	jal	800004fa <printf>
    panic("kerneltrap");
    80002b04:	00005517          	auipc	a0,0x5
    80002b08:	8c450513          	addi	a0,a0,-1852 # 800073c8 <etext+0x3c8>
    80002b0c:	cd5fd0ef          	jal	800007e0 <panic>
  if(which_dev == 2 && myproc() != 0)
    80002b10:	e01fe0ef          	jal	80001910 <myproc>
    80002b14:	d555                	beqz	a0,80002ac0 <kerneltrap+0x34>
    yield();
    80002b16:	bdcff0ef          	jal	80001ef2 <yield>
    80002b1a:	b75d                	j	80002ac0 <kerneltrap+0x34>

0000000080002b1c <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002b1c:	1101                	addi	sp,sp,-32
    80002b1e:	ec06                	sd	ra,24(sp)
    80002b20:	e822                	sd	s0,16(sp)
    80002b22:	e426                	sd	s1,8(sp)
    80002b24:	1000                	addi	s0,sp,32
    80002b26:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002b28:	de9fe0ef          	jal	80001910 <myproc>
  switch (n) {
    80002b2c:	4795                	li	a5,5
    80002b2e:	0497e163          	bltu	a5,s1,80002b70 <argraw+0x54>
    80002b32:	048a                	slli	s1,s1,0x2
    80002b34:	00005717          	auipc	a4,0x5
    80002b38:	cc470713          	addi	a4,a4,-828 # 800077f8 <states.0+0x30>
    80002b3c:	94ba                	add	s1,s1,a4
    80002b3e:	409c                	lw	a5,0(s1)
    80002b40:	97ba                	add	a5,a5,a4
    80002b42:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002b44:	6d3c                	ld	a5,88(a0)
    80002b46:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002b48:	60e2                	ld	ra,24(sp)
    80002b4a:	6442                	ld	s0,16(sp)
    80002b4c:	64a2                	ld	s1,8(sp)
    80002b4e:	6105                	addi	sp,sp,32
    80002b50:	8082                	ret
    return p->trapframe->a1;
    80002b52:	6d3c                	ld	a5,88(a0)
    80002b54:	7fa8                	ld	a0,120(a5)
    80002b56:	bfcd                	j	80002b48 <argraw+0x2c>
    return p->trapframe->a2;
    80002b58:	6d3c                	ld	a5,88(a0)
    80002b5a:	63c8                	ld	a0,128(a5)
    80002b5c:	b7f5                	j	80002b48 <argraw+0x2c>
    return p->trapframe->a3;
    80002b5e:	6d3c                	ld	a5,88(a0)
    80002b60:	67c8                	ld	a0,136(a5)
    80002b62:	b7dd                	j	80002b48 <argraw+0x2c>
    return p->trapframe->a4;
    80002b64:	6d3c                	ld	a5,88(a0)
    80002b66:	6bc8                	ld	a0,144(a5)
    80002b68:	b7c5                	j	80002b48 <argraw+0x2c>
    return p->trapframe->a5;
    80002b6a:	6d3c                	ld	a5,88(a0)
    80002b6c:	6fc8                	ld	a0,152(a5)
    80002b6e:	bfe9                	j	80002b48 <argraw+0x2c>
  panic("argraw");
    80002b70:	00005517          	auipc	a0,0x5
    80002b74:	86850513          	addi	a0,a0,-1944 # 800073d8 <etext+0x3d8>
    80002b78:	c69fd0ef          	jal	800007e0 <panic>

0000000080002b7c <fetchaddr>:
{
    80002b7c:	1101                	addi	sp,sp,-32
    80002b7e:	ec06                	sd	ra,24(sp)
    80002b80:	e822                	sd	s0,16(sp)
    80002b82:	e426                	sd	s1,8(sp)
    80002b84:	e04a                	sd	s2,0(sp)
    80002b86:	1000                	addi	s0,sp,32
    80002b88:	84aa                	mv	s1,a0
    80002b8a:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002b8c:	d85fe0ef          	jal	80001910 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002b90:	653c                	ld	a5,72(a0)
    80002b92:	02f4f663          	bgeu	s1,a5,80002bbe <fetchaddr+0x42>
    80002b96:	00848713          	addi	a4,s1,8
    80002b9a:	02e7e463          	bltu	a5,a4,80002bc2 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002b9e:	46a1                	li	a3,8
    80002ba0:	8626                	mv	a2,s1
    80002ba2:	85ca                	mv	a1,s2
    80002ba4:	6928                	ld	a0,80(a0)
    80002ba6:	b63fe0ef          	jal	80001708 <copyin>
    80002baa:	00a03533          	snez	a0,a0
    80002bae:	40a00533          	neg	a0,a0
}
    80002bb2:	60e2                	ld	ra,24(sp)
    80002bb4:	6442                	ld	s0,16(sp)
    80002bb6:	64a2                	ld	s1,8(sp)
    80002bb8:	6902                	ld	s2,0(sp)
    80002bba:	6105                	addi	sp,sp,32
    80002bbc:	8082                	ret
    return -1;
    80002bbe:	557d                	li	a0,-1
    80002bc0:	bfcd                	j	80002bb2 <fetchaddr+0x36>
    80002bc2:	557d                	li	a0,-1
    80002bc4:	b7fd                	j	80002bb2 <fetchaddr+0x36>

0000000080002bc6 <fetchstr>:
{
    80002bc6:	7179                	addi	sp,sp,-48
    80002bc8:	f406                	sd	ra,40(sp)
    80002bca:	f022                	sd	s0,32(sp)
    80002bcc:	ec26                	sd	s1,24(sp)
    80002bce:	e84a                	sd	s2,16(sp)
    80002bd0:	e44e                	sd	s3,8(sp)
    80002bd2:	1800                	addi	s0,sp,48
    80002bd4:	892a                	mv	s2,a0
    80002bd6:	84ae                	mv	s1,a1
    80002bd8:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80002bda:	d37fe0ef          	jal	80001910 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002bde:	86ce                	mv	a3,s3
    80002be0:	864a                	mv	a2,s2
    80002be2:	85a6                	mv	a1,s1
    80002be4:	6928                	ld	a0,80(a0)
    80002be6:	8e5fe0ef          	jal	800014ca <copyinstr>
    80002bea:	00054c63          	bltz	a0,80002c02 <fetchstr+0x3c>
  return strlen(buf);
    80002bee:	8526                	mv	a0,s1
    80002bf0:	a64fe0ef          	jal	80000e54 <strlen>
}
    80002bf4:	70a2                	ld	ra,40(sp)
    80002bf6:	7402                	ld	s0,32(sp)
    80002bf8:	64e2                	ld	s1,24(sp)
    80002bfa:	6942                	ld	s2,16(sp)
    80002bfc:	69a2                	ld	s3,8(sp)
    80002bfe:	6145                	addi	sp,sp,48
    80002c00:	8082                	ret
    return -1;
    80002c02:	557d                	li	a0,-1
    80002c04:	bfc5                	j	80002bf4 <fetchstr+0x2e>

0000000080002c06 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002c06:	1101                	addi	sp,sp,-32
    80002c08:	ec06                	sd	ra,24(sp)
    80002c0a:	e822                	sd	s0,16(sp)
    80002c0c:	e426                	sd	s1,8(sp)
    80002c0e:	1000                	addi	s0,sp,32
    80002c10:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002c12:	f0bff0ef          	jal	80002b1c <argraw>
    80002c16:	c088                	sw	a0,0(s1)
}
    80002c18:	60e2                	ld	ra,24(sp)
    80002c1a:	6442                	ld	s0,16(sp)
    80002c1c:	64a2                	ld	s1,8(sp)
    80002c1e:	6105                	addi	sp,sp,32
    80002c20:	8082                	ret

0000000080002c22 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002c22:	1101                	addi	sp,sp,-32
    80002c24:	ec06                	sd	ra,24(sp)
    80002c26:	e822                	sd	s0,16(sp)
    80002c28:	e426                	sd	s1,8(sp)
    80002c2a:	1000                	addi	s0,sp,32
    80002c2c:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002c2e:	eefff0ef          	jal	80002b1c <argraw>
    80002c32:	e088                	sd	a0,0(s1)
}
    80002c34:	60e2                	ld	ra,24(sp)
    80002c36:	6442                	ld	s0,16(sp)
    80002c38:	64a2                	ld	s1,8(sp)
    80002c3a:	6105                	addi	sp,sp,32
    80002c3c:	8082                	ret

0000000080002c3e <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002c3e:	7179                	addi	sp,sp,-48
    80002c40:	f406                	sd	ra,40(sp)
    80002c42:	f022                	sd	s0,32(sp)
    80002c44:	ec26                	sd	s1,24(sp)
    80002c46:	e84a                	sd	s2,16(sp)
    80002c48:	1800                	addi	s0,sp,48
    80002c4a:	84ae                	mv	s1,a1
    80002c4c:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002c4e:	fd840593          	addi	a1,s0,-40
    80002c52:	fd1ff0ef          	jal	80002c22 <argaddr>
  return fetchstr(addr, buf, max);
    80002c56:	864a                	mv	a2,s2
    80002c58:	85a6                	mv	a1,s1
    80002c5a:	fd843503          	ld	a0,-40(s0)
    80002c5e:	f69ff0ef          	jal	80002bc6 <fetchstr>
}
    80002c62:	70a2                	ld	ra,40(sp)
    80002c64:	7402                	ld	s0,32(sp)
    80002c66:	64e2                	ld	s1,24(sp)
    80002c68:	6942                	ld	s2,16(sp)
    80002c6a:	6145                	addi	sp,sp,48
    80002c6c:	8082                	ret

0000000080002c6e <syscall>:
[SYS_waitpid] sys_waitpid,
};

void
syscall(void)
{
    80002c6e:	1101                	addi	sp,sp,-32
    80002c70:	ec06                	sd	ra,24(sp)
    80002c72:	e822                	sd	s0,16(sp)
    80002c74:	e426                	sd	s1,8(sp)
    80002c76:	e04a                	sd	s2,0(sp)
    80002c78:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002c7a:	c97fe0ef          	jal	80001910 <myproc>
    80002c7e:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002c80:	05853903          	ld	s2,88(a0)
    80002c84:	0a893783          	ld	a5,168(s2)
    80002c88:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002c8c:	37fd                	addiw	a5,a5,-1
    80002c8e:	4765                	li	a4,25
    80002c90:	00f76f63          	bltu	a4,a5,80002cae <syscall+0x40>
    80002c94:	00369713          	slli	a4,a3,0x3
    80002c98:	00005797          	auipc	a5,0x5
    80002c9c:	b7878793          	addi	a5,a5,-1160 # 80007810 <syscalls>
    80002ca0:	97ba                	add	a5,a5,a4
    80002ca2:	639c                	ld	a5,0(a5)
    80002ca4:	c789                	beqz	a5,80002cae <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002ca6:	9782                	jalr	a5
    80002ca8:	06a93823          	sd	a0,112(s2)
    80002cac:	a829                	j	80002cc6 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002cae:	15848613          	addi	a2,s1,344
    80002cb2:	588c                	lw	a1,48(s1)
    80002cb4:	00004517          	auipc	a0,0x4
    80002cb8:	72c50513          	addi	a0,a0,1836 # 800073e0 <etext+0x3e0>
    80002cbc:	83ffd0ef          	jal	800004fa <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002cc0:	6cbc                	ld	a5,88(s1)
    80002cc2:	577d                	li	a4,-1
    80002cc4:	fbb8                	sd	a4,112(a5)
  }
}
    80002cc6:	60e2                	ld	ra,24(sp)
    80002cc8:	6442                	ld	s0,16(sp)
    80002cca:	64a2                	ld	s1,8(sp)
    80002ccc:	6902                	ld	s2,0(sp)
    80002cce:	6105                	addi	sp,sp,32
    80002cd0:	8082                	ret

0000000080002cd2 <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    80002cd2:	1101                	addi	sp,sp,-32
    80002cd4:	ec06                	sd	ra,24(sp)
    80002cd6:	e822                	sd	s0,16(sp)
    80002cd8:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002cda:	fec40593          	addi	a1,s0,-20
    80002cde:	4501                	li	a0,0
    80002ce0:	f27ff0ef          	jal	80002c06 <argint>
  kexit(n);
    80002ce4:	fec42503          	lw	a0,-20(s0)
    80002ce8:	b42ff0ef          	jal	8000202a <kexit>
  return 0;  // not reached
}
    80002cec:	4501                	li	a0,0
    80002cee:	60e2                	ld	ra,24(sp)
    80002cf0:	6442                	ld	s0,16(sp)
    80002cf2:	6105                	addi	sp,sp,32
    80002cf4:	8082                	ret

0000000080002cf6 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002cf6:	1141                	addi	sp,sp,-16
    80002cf8:	e406                	sd	ra,8(sp)
    80002cfa:	e022                	sd	s0,0(sp)
    80002cfc:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002cfe:	c13fe0ef          	jal	80001910 <myproc>
}
    80002d02:	5908                	lw	a0,48(a0)
    80002d04:	60a2                	ld	ra,8(sp)
    80002d06:	6402                	ld	s0,0(sp)
    80002d08:	0141                	addi	sp,sp,16
    80002d0a:	8082                	ret

0000000080002d0c <sys_fork>:

uint64
sys_fork(void)
{
    80002d0c:	1141                	addi	sp,sp,-16
    80002d0e:	e406                	sd	ra,8(sp)
    80002d10:	e022                	sd	s0,0(sp)
    80002d12:	0800                	addi	s0,sp,16
  return kfork();
    80002d14:	f65fe0ef          	jal	80001c78 <kfork>
}
    80002d18:	60a2                	ld	ra,8(sp)
    80002d1a:	6402                	ld	s0,0(sp)
    80002d1c:	0141                	addi	sp,sp,16
    80002d1e:	8082                	ret

0000000080002d20 <sys_wait>:

uint64
sys_wait(void)
{
    80002d20:	1101                	addi	sp,sp,-32
    80002d22:	ec06                	sd	ra,24(sp)
    80002d24:	e822                	sd	s0,16(sp)
    80002d26:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002d28:	fe840593          	addi	a1,s0,-24
    80002d2c:	4501                	li	a0,0
    80002d2e:	ef5ff0ef          	jal	80002c22 <argaddr>
  return kwait(p);
    80002d32:	fe843503          	ld	a0,-24(s0)
    80002d36:	c4aff0ef          	jal	80002180 <kwait>
}
    80002d3a:	60e2                	ld	ra,24(sp)
    80002d3c:	6442                	ld	s0,16(sp)
    80002d3e:	6105                	addi	sp,sp,32
    80002d40:	8082                	ret

0000000080002d42 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002d42:	7179                	addi	sp,sp,-48
    80002d44:	f406                	sd	ra,40(sp)
    80002d46:	f022                	sd	s0,32(sp)
    80002d48:	ec26                	sd	s1,24(sp)
    80002d4a:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002d4c:	fd840593          	addi	a1,s0,-40
    80002d50:	4501                	li	a0,0
    80002d52:	eb5ff0ef          	jal	80002c06 <argint>
  argint(1, &t);
    80002d56:	fdc40593          	addi	a1,s0,-36
    80002d5a:	4505                	li	a0,1
    80002d5c:	eabff0ef          	jal	80002c06 <argint>
  addr = myproc()->sz;
    80002d60:	bb1fe0ef          	jal	80001910 <myproc>
    80002d64:	6524                	ld	s1,72(a0)

  if(t == SBRK_EAGER || n < 0) {
    80002d66:	fdc42703          	lw	a4,-36(s0)
    80002d6a:	4785                	li	a5,1
    80002d6c:	02f70763          	beq	a4,a5,80002d9a <sys_sbrk+0x58>
    80002d70:	fd842783          	lw	a5,-40(s0)
    80002d74:	0207c363          	bltz	a5,80002d9a <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
    80002d78:	97a6                	add	a5,a5,s1
    80002d7a:	0297ee63          	bltu	a5,s1,80002db6 <sys_sbrk+0x74>
      return -1;
    if(addr + n > TRAPFRAME)
    80002d7e:	02000737          	lui	a4,0x2000
    80002d82:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    80002d84:	0736                	slli	a4,a4,0xd
    80002d86:	02f76a63          	bltu	a4,a5,80002dba <sys_sbrk+0x78>
      return -1;
    myproc()->sz += n;
    80002d8a:	b87fe0ef          	jal	80001910 <myproc>
    80002d8e:	fd842703          	lw	a4,-40(s0)
    80002d92:	653c                	ld	a5,72(a0)
    80002d94:	97ba                	add	a5,a5,a4
    80002d96:	e53c                	sd	a5,72(a0)
    80002d98:	a039                	j	80002da6 <sys_sbrk+0x64>
    if(growproc(n) < 0) {
    80002d9a:	fd842503          	lw	a0,-40(s0)
    80002d9e:	e79fe0ef          	jal	80001c16 <growproc>
    80002da2:	00054863          	bltz	a0,80002db2 <sys_sbrk+0x70>
  }
  return addr;
}
    80002da6:	8526                	mv	a0,s1
    80002da8:	70a2                	ld	ra,40(sp)
    80002daa:	7402                	ld	s0,32(sp)
    80002dac:	64e2                	ld	s1,24(sp)
    80002dae:	6145                	addi	sp,sp,48
    80002db0:	8082                	ret
      return -1;
    80002db2:	54fd                	li	s1,-1
    80002db4:	bfcd                	j	80002da6 <sys_sbrk+0x64>
      return -1;
    80002db6:	54fd                	li	s1,-1
    80002db8:	b7fd                	j	80002da6 <sys_sbrk+0x64>
      return -1;
    80002dba:	54fd                	li	s1,-1
    80002dbc:	b7ed                	j	80002da6 <sys_sbrk+0x64>

0000000080002dbe <sys_pause>:

uint64
sys_pause(void)
{
    80002dbe:	7139                	addi	sp,sp,-64
    80002dc0:	fc06                	sd	ra,56(sp)
    80002dc2:	f822                	sd	s0,48(sp)
    80002dc4:	f04a                	sd	s2,32(sp)
    80002dc6:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002dc8:	fcc40593          	addi	a1,s0,-52
    80002dcc:	4501                	li	a0,0
    80002dce:	e39ff0ef          	jal	80002c06 <argint>
  if(n < 0)
    80002dd2:	fcc42783          	lw	a5,-52(s0)
    80002dd6:	0607c763          	bltz	a5,80002e44 <sys_pause+0x86>
    n = 0;
  acquire(&tickslock);
    80002dda:	00013517          	auipc	a0,0x13
    80002dde:	a7e50513          	addi	a0,a0,-1410 # 80015858 <tickslock>
    80002de2:	e2ffd0ef          	jal	80000c10 <acquire>
  ticks0 = ticks;
    80002de6:	00005917          	auipc	s2,0x5
    80002dea:	b4292903          	lw	s2,-1214(s2) # 80007928 <ticks>
  while(ticks - ticks0 < n){
    80002dee:	fcc42783          	lw	a5,-52(s0)
    80002df2:	cf8d                	beqz	a5,80002e2c <sys_pause+0x6e>
    80002df4:	f426                	sd	s1,40(sp)
    80002df6:	ec4e                	sd	s3,24(sp)
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002df8:	00013997          	auipc	s3,0x13
    80002dfc:	a6098993          	addi	s3,s3,-1440 # 80015858 <tickslock>
    80002e00:	00005497          	auipc	s1,0x5
    80002e04:	b2848493          	addi	s1,s1,-1240 # 80007928 <ticks>
    if(killed(myproc())){
    80002e08:	b09fe0ef          	jal	80001910 <myproc>
    80002e0c:	b4aff0ef          	jal	80002156 <killed>
    80002e10:	ed0d                	bnez	a0,80002e4a <sys_pause+0x8c>
    sleep(&ticks, &tickslock);
    80002e12:	85ce                	mv	a1,s3
    80002e14:	8526                	mv	a0,s1
    80002e16:	908ff0ef          	jal	80001f1e <sleep>
  while(ticks - ticks0 < n){
    80002e1a:	409c                	lw	a5,0(s1)
    80002e1c:	412787bb          	subw	a5,a5,s2
    80002e20:	fcc42703          	lw	a4,-52(s0)
    80002e24:	fee7e2e3          	bltu	a5,a4,80002e08 <sys_pause+0x4a>
    80002e28:	74a2                	ld	s1,40(sp)
    80002e2a:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002e2c:	00013517          	auipc	a0,0x13
    80002e30:	a2c50513          	addi	a0,a0,-1492 # 80015858 <tickslock>
    80002e34:	e75fd0ef          	jal	80000ca8 <release>
  return 0;
    80002e38:	4501                	li	a0,0
}
    80002e3a:	70e2                	ld	ra,56(sp)
    80002e3c:	7442                	ld	s0,48(sp)
    80002e3e:	7902                	ld	s2,32(sp)
    80002e40:	6121                	addi	sp,sp,64
    80002e42:	8082                	ret
    n = 0;
    80002e44:	fc042623          	sw	zero,-52(s0)
    80002e48:	bf49                	j	80002dda <sys_pause+0x1c>
      release(&tickslock);
    80002e4a:	00013517          	auipc	a0,0x13
    80002e4e:	a0e50513          	addi	a0,a0,-1522 # 80015858 <tickslock>
    80002e52:	e57fd0ef          	jal	80000ca8 <release>
      return -1;
    80002e56:	557d                	li	a0,-1
    80002e58:	74a2                	ld	s1,40(sp)
    80002e5a:	69e2                	ld	s3,24(sp)
    80002e5c:	bff9                	j	80002e3a <sys_pause+0x7c>

0000000080002e5e <sys_kill>:

uint64
sys_kill(void)
{
    80002e5e:	1101                	addi	sp,sp,-32
    80002e60:	ec06                	sd	ra,24(sp)
    80002e62:	e822                	sd	s0,16(sp)
    80002e64:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002e66:	fec40593          	addi	a1,s0,-20
    80002e6a:	4501                	li	a0,0
    80002e6c:	d9bff0ef          	jal	80002c06 <argint>
  return kkill(pid);
    80002e70:	fec42503          	lw	a0,-20(s0)
    80002e74:	a58ff0ef          	jal	800020cc <kkill>
}
    80002e78:	60e2                	ld	ra,24(sp)
    80002e7a:	6442                	ld	s0,16(sp)
    80002e7c:	6105                	addi	sp,sp,32
    80002e7e:	8082                	ret

0000000080002e80 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002e80:	1101                	addi	sp,sp,-32
    80002e82:	ec06                	sd	ra,24(sp)
    80002e84:	e822                	sd	s0,16(sp)
    80002e86:	e426                	sd	s1,8(sp)
    80002e88:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002e8a:	00013517          	auipc	a0,0x13
    80002e8e:	9ce50513          	addi	a0,a0,-1586 # 80015858 <tickslock>
    80002e92:	d7ffd0ef          	jal	80000c10 <acquire>
  xticks = ticks;
    80002e96:	00005497          	auipc	s1,0x5
    80002e9a:	a924a483          	lw	s1,-1390(s1) # 80007928 <ticks>
  release(&tickslock);
    80002e9e:	00013517          	auipc	a0,0x13
    80002ea2:	9ba50513          	addi	a0,a0,-1606 # 80015858 <tickslock>
    80002ea6:	e03fd0ef          	jal	80000ca8 <release>
  return xticks;
}
    80002eaa:	02049513          	slli	a0,s1,0x20
    80002eae:	9101                	srli	a0,a0,0x20
    80002eb0:	60e2                	ld	ra,24(sp)
    80002eb2:	6442                	ld	s0,16(sp)
    80002eb4:	64a2                	ld	s1,8(sp)
    80002eb6:	6105                	addi	sp,sp,32
    80002eb8:	8082                	ret

0000000080002eba <sys_getnice>:

//Added for project 01
uint64 sys_getnice(void) {
    80002eba:	1101                	addi	sp,sp,-32
    80002ebc:	ec06                	sd	ra,24(sp)
    80002ebe:	e822                	sd	s0,16(sp)
    80002ec0:	1000                	addi	s0,sp,32
    int pid;
    argint(0, &pid);
    80002ec2:	fec40593          	addi	a1,s0,-20
    80002ec6:	4501                	li	a0,0
    80002ec8:	d3fff0ef          	jal	80002c06 <argint>
    return getnice(pid);
    80002ecc:	fec42503          	lw	a0,-20(s0)
    80002ed0:	ce2ff0ef          	jal	800023b2 <getnice>
}
    80002ed4:	60e2                	ld	ra,24(sp)
    80002ed6:	6442                	ld	s0,16(sp)
    80002ed8:	6105                	addi	sp,sp,32
    80002eda:	8082                	ret

0000000080002edc <sys_setnice>:

uint64 sys_setnice(void) {
    80002edc:	1101                	addi	sp,sp,-32
    80002ede:	ec06                	sd	ra,24(sp)
    80002ee0:	e822                	sd	s0,16(sp)
    80002ee2:	1000                	addi	s0,sp,32
    int pid, value;
    argint(0, &pid);
    80002ee4:	fec40593          	addi	a1,s0,-20
    80002ee8:	4501                	li	a0,0
    80002eea:	d1dff0ef          	jal	80002c06 <argint>
    argint(1, &value);
    80002eee:	fe840593          	addi	a1,s0,-24
    80002ef2:	4505                	li	a0,1
    80002ef4:	d13ff0ef          	jal	80002c06 <argint>
    return setnice(pid, value);
    80002ef8:	fe842583          	lw	a1,-24(s0)
    80002efc:	fec42503          	lw	a0,-20(s0)
    80002f00:	d20ff0ef          	jal	80002420 <setnice>
}
    80002f04:	60e2                	ld	ra,24(sp)
    80002f06:	6442                	ld	s0,16(sp)
    80002f08:	6105                	addi	sp,sp,32
    80002f0a:	8082                	ret

0000000080002f0c <sys_ps>:

uint64 sys_ps(void) {
    80002f0c:	1101                	addi	sp,sp,-32
    80002f0e:	ec06                	sd	ra,24(sp)
    80002f10:	e822                	sd	s0,16(sp)
    80002f12:	1000                	addi	s0,sp,32
    int pid;
    argint(0, &pid);
    80002f14:	fec40593          	addi	a1,s0,-20
    80002f18:	4501                	li	a0,0
    80002f1a:	cedff0ef          	jal	80002c06 <argint>
    ps(pid);
    80002f1e:	fec42503          	lw	a0,-20(s0)
    80002f22:	d7eff0ef          	jal	800024a0 <ps>
    return 0;
}
    80002f26:	4501                	li	a0,0
    80002f28:	60e2                	ld	ra,24(sp)
    80002f2a:	6442                	ld	s0,16(sp)
    80002f2c:	6105                	addi	sp,sp,32
    80002f2e:	8082                	ret

0000000080002f30 <sys_meminfo>:

uint64 sys_meminfo(void) {
    80002f30:	1141                	addi	sp,sp,-16
    80002f32:	e406                	sd	ra,8(sp)
    80002f34:	e022                	sd	s0,0(sp)
    80002f36:	0800                	addi	s0,sp,16
    return meminfo();
    80002f38:	f66ff0ef          	jal	8000269e <meminfo>
}
    80002f3c:	60a2                	ld	ra,8(sp)
    80002f3e:	6402                	ld	s0,0(sp)
    80002f40:	0141                	addi	sp,sp,16
    80002f42:	8082                	ret

0000000080002f44 <sys_waitpid>:

uint64 sys_waitpid(void) {
    80002f44:	1101                	addi	sp,sp,-32
    80002f46:	ec06                	sd	ra,24(sp)
    80002f48:	e822                	sd	s0,16(sp)
    80002f4a:	1000                	addi	s0,sp,32
    int pid;
    argint(0, &pid);
    80002f4c:	fec40593          	addi	a1,s0,-20
    80002f50:	4501                	li	a0,0
    80002f52:	cb5ff0ef          	jal	80002c06 <argint>
    return waitpid(pid);
    80002f56:	fec42503          	lw	a0,-20(s0)
    80002f5a:	f58ff0ef          	jal	800026b2 <waitpid>
}
    80002f5e:	60e2                	ld	ra,24(sp)
    80002f60:	6442                	ld	s0,16(sp)
    80002f62:	6105                	addi	sp,sp,32
    80002f64:	8082                	ret

0000000080002f66 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002f66:	7179                	addi	sp,sp,-48
    80002f68:	f406                	sd	ra,40(sp)
    80002f6a:	f022                	sd	s0,32(sp)
    80002f6c:	ec26                	sd	s1,24(sp)
    80002f6e:	e84a                	sd	s2,16(sp)
    80002f70:	e44e                	sd	s3,8(sp)
    80002f72:	e052                	sd	s4,0(sp)
    80002f74:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002f76:	00004597          	auipc	a1,0x4
    80002f7a:	48a58593          	addi	a1,a1,1162 # 80007400 <etext+0x400>
    80002f7e:	00013517          	auipc	a0,0x13
    80002f82:	8f250513          	addi	a0,a0,-1806 # 80015870 <bcache>
    80002f86:	c0bfd0ef          	jal	80000b90 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002f8a:	0001b797          	auipc	a5,0x1b
    80002f8e:	8e678793          	addi	a5,a5,-1818 # 8001d870 <bcache+0x8000>
    80002f92:	0001b717          	auipc	a4,0x1b
    80002f96:	b4670713          	addi	a4,a4,-1210 # 8001dad8 <bcache+0x8268>
    80002f9a:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002f9e:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002fa2:	00013497          	auipc	s1,0x13
    80002fa6:	8e648493          	addi	s1,s1,-1818 # 80015888 <bcache+0x18>
    b->next = bcache.head.next;
    80002faa:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002fac:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002fae:	00004a17          	auipc	s4,0x4
    80002fb2:	45aa0a13          	addi	s4,s4,1114 # 80007408 <etext+0x408>
    b->next = bcache.head.next;
    80002fb6:	2b893783          	ld	a5,696(s2)
    80002fba:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002fbc:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002fc0:	85d2                	mv	a1,s4
    80002fc2:	01048513          	addi	a0,s1,16
    80002fc6:	322010ef          	jal	800042e8 <initsleeplock>
    bcache.head.next->prev = b;
    80002fca:	2b893783          	ld	a5,696(s2)
    80002fce:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002fd0:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002fd4:	45848493          	addi	s1,s1,1112
    80002fd8:	fd349fe3          	bne	s1,s3,80002fb6 <binit+0x50>
  }
}
    80002fdc:	70a2                	ld	ra,40(sp)
    80002fde:	7402                	ld	s0,32(sp)
    80002fe0:	64e2                	ld	s1,24(sp)
    80002fe2:	6942                	ld	s2,16(sp)
    80002fe4:	69a2                	ld	s3,8(sp)
    80002fe6:	6a02                	ld	s4,0(sp)
    80002fe8:	6145                	addi	sp,sp,48
    80002fea:	8082                	ret

0000000080002fec <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002fec:	7179                	addi	sp,sp,-48
    80002fee:	f406                	sd	ra,40(sp)
    80002ff0:	f022                	sd	s0,32(sp)
    80002ff2:	ec26                	sd	s1,24(sp)
    80002ff4:	e84a                	sd	s2,16(sp)
    80002ff6:	e44e                	sd	s3,8(sp)
    80002ff8:	1800                	addi	s0,sp,48
    80002ffa:	892a                	mv	s2,a0
    80002ffc:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002ffe:	00013517          	auipc	a0,0x13
    80003002:	87250513          	addi	a0,a0,-1934 # 80015870 <bcache>
    80003006:	c0bfd0ef          	jal	80000c10 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    8000300a:	0001b497          	auipc	s1,0x1b
    8000300e:	b1e4b483          	ld	s1,-1250(s1) # 8001db28 <bcache+0x82b8>
    80003012:	0001b797          	auipc	a5,0x1b
    80003016:	ac678793          	addi	a5,a5,-1338 # 8001dad8 <bcache+0x8268>
    8000301a:	02f48b63          	beq	s1,a5,80003050 <bread+0x64>
    8000301e:	873e                	mv	a4,a5
    80003020:	a021                	j	80003028 <bread+0x3c>
    80003022:	68a4                	ld	s1,80(s1)
    80003024:	02e48663          	beq	s1,a4,80003050 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80003028:	449c                	lw	a5,8(s1)
    8000302a:	ff279ce3          	bne	a5,s2,80003022 <bread+0x36>
    8000302e:	44dc                	lw	a5,12(s1)
    80003030:	ff3799e3          	bne	a5,s3,80003022 <bread+0x36>
      b->refcnt++;
    80003034:	40bc                	lw	a5,64(s1)
    80003036:	2785                	addiw	a5,a5,1
    80003038:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    8000303a:	00013517          	auipc	a0,0x13
    8000303e:	83650513          	addi	a0,a0,-1994 # 80015870 <bcache>
    80003042:	c67fd0ef          	jal	80000ca8 <release>
      acquiresleep(&b->lock);
    80003046:	01048513          	addi	a0,s1,16
    8000304a:	2d4010ef          	jal	8000431e <acquiresleep>
      return b;
    8000304e:	a889                	j	800030a0 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80003050:	0001b497          	auipc	s1,0x1b
    80003054:	ad04b483          	ld	s1,-1328(s1) # 8001db20 <bcache+0x82b0>
    80003058:	0001b797          	auipc	a5,0x1b
    8000305c:	a8078793          	addi	a5,a5,-1408 # 8001dad8 <bcache+0x8268>
    80003060:	00f48863          	beq	s1,a5,80003070 <bread+0x84>
    80003064:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80003066:	40bc                	lw	a5,64(s1)
    80003068:	cb91                	beqz	a5,8000307c <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    8000306a:	64a4                	ld	s1,72(s1)
    8000306c:	fee49de3          	bne	s1,a4,80003066 <bread+0x7a>
  panic("bget: no buffers");
    80003070:	00004517          	auipc	a0,0x4
    80003074:	3a050513          	addi	a0,a0,928 # 80007410 <etext+0x410>
    80003078:	f68fd0ef          	jal	800007e0 <panic>
      b->dev = dev;
    8000307c:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80003080:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80003084:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80003088:	4785                	li	a5,1
    8000308a:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    8000308c:	00012517          	auipc	a0,0x12
    80003090:	7e450513          	addi	a0,a0,2020 # 80015870 <bcache>
    80003094:	c15fd0ef          	jal	80000ca8 <release>
      acquiresleep(&b->lock);
    80003098:	01048513          	addi	a0,s1,16
    8000309c:	282010ef          	jal	8000431e <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    800030a0:	409c                	lw	a5,0(s1)
    800030a2:	cb89                	beqz	a5,800030b4 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    800030a4:	8526                	mv	a0,s1
    800030a6:	70a2                	ld	ra,40(sp)
    800030a8:	7402                	ld	s0,32(sp)
    800030aa:	64e2                	ld	s1,24(sp)
    800030ac:	6942                	ld	s2,16(sp)
    800030ae:	69a2                	ld	s3,8(sp)
    800030b0:	6145                	addi	sp,sp,48
    800030b2:	8082                	ret
    virtio_disk_rw(b, 0);
    800030b4:	4581                	li	a1,0
    800030b6:	8526                	mv	a0,s1
    800030b8:	2c9020ef          	jal	80005b80 <virtio_disk_rw>
    b->valid = 1;
    800030bc:	4785                	li	a5,1
    800030be:	c09c                	sw	a5,0(s1)
  return b;
    800030c0:	b7d5                	j	800030a4 <bread+0xb8>

00000000800030c2 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    800030c2:	1101                	addi	sp,sp,-32
    800030c4:	ec06                	sd	ra,24(sp)
    800030c6:	e822                	sd	s0,16(sp)
    800030c8:	e426                	sd	s1,8(sp)
    800030ca:	1000                	addi	s0,sp,32
    800030cc:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    800030ce:	0541                	addi	a0,a0,16
    800030d0:	2cc010ef          	jal	8000439c <holdingsleep>
    800030d4:	c911                	beqz	a0,800030e8 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    800030d6:	4585                	li	a1,1
    800030d8:	8526                	mv	a0,s1
    800030da:	2a7020ef          	jal	80005b80 <virtio_disk_rw>
}
    800030de:	60e2                	ld	ra,24(sp)
    800030e0:	6442                	ld	s0,16(sp)
    800030e2:	64a2                	ld	s1,8(sp)
    800030e4:	6105                	addi	sp,sp,32
    800030e6:	8082                	ret
    panic("bwrite");
    800030e8:	00004517          	auipc	a0,0x4
    800030ec:	34050513          	addi	a0,a0,832 # 80007428 <etext+0x428>
    800030f0:	ef0fd0ef          	jal	800007e0 <panic>

00000000800030f4 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    800030f4:	1101                	addi	sp,sp,-32
    800030f6:	ec06                	sd	ra,24(sp)
    800030f8:	e822                	sd	s0,16(sp)
    800030fa:	e426                	sd	s1,8(sp)
    800030fc:	e04a                	sd	s2,0(sp)
    800030fe:	1000                	addi	s0,sp,32
    80003100:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003102:	01050913          	addi	s2,a0,16
    80003106:	854a                	mv	a0,s2
    80003108:	294010ef          	jal	8000439c <holdingsleep>
    8000310c:	c135                	beqz	a0,80003170 <brelse+0x7c>
    panic("brelse");

  releasesleep(&b->lock);
    8000310e:	854a                	mv	a0,s2
    80003110:	254010ef          	jal	80004364 <releasesleep>

  acquire(&bcache.lock);
    80003114:	00012517          	auipc	a0,0x12
    80003118:	75c50513          	addi	a0,a0,1884 # 80015870 <bcache>
    8000311c:	af5fd0ef          	jal	80000c10 <acquire>
  b->refcnt--;
    80003120:	40bc                	lw	a5,64(s1)
    80003122:	37fd                	addiw	a5,a5,-1
    80003124:	0007871b          	sext.w	a4,a5
    80003128:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    8000312a:	e71d                	bnez	a4,80003158 <brelse+0x64>
    // no one is waiting for it.
    b->next->prev = b->prev;
    8000312c:	68b8                	ld	a4,80(s1)
    8000312e:	64bc                	ld	a5,72(s1)
    80003130:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80003132:	68b8                	ld	a4,80(s1)
    80003134:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80003136:	0001a797          	auipc	a5,0x1a
    8000313a:	73a78793          	addi	a5,a5,1850 # 8001d870 <bcache+0x8000>
    8000313e:	2b87b703          	ld	a4,696(a5)
    80003142:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80003144:	0001b717          	auipc	a4,0x1b
    80003148:	99470713          	addi	a4,a4,-1644 # 8001dad8 <bcache+0x8268>
    8000314c:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    8000314e:	2b87b703          	ld	a4,696(a5)
    80003152:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80003154:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80003158:	00012517          	auipc	a0,0x12
    8000315c:	71850513          	addi	a0,a0,1816 # 80015870 <bcache>
    80003160:	b49fd0ef          	jal	80000ca8 <release>
}
    80003164:	60e2                	ld	ra,24(sp)
    80003166:	6442                	ld	s0,16(sp)
    80003168:	64a2                	ld	s1,8(sp)
    8000316a:	6902                	ld	s2,0(sp)
    8000316c:	6105                	addi	sp,sp,32
    8000316e:	8082                	ret
    panic("brelse");
    80003170:	00004517          	auipc	a0,0x4
    80003174:	2c050513          	addi	a0,a0,704 # 80007430 <etext+0x430>
    80003178:	e68fd0ef          	jal	800007e0 <panic>

000000008000317c <bpin>:

void
bpin(struct buf *b) {
    8000317c:	1101                	addi	sp,sp,-32
    8000317e:	ec06                	sd	ra,24(sp)
    80003180:	e822                	sd	s0,16(sp)
    80003182:	e426                	sd	s1,8(sp)
    80003184:	1000                	addi	s0,sp,32
    80003186:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80003188:	00012517          	auipc	a0,0x12
    8000318c:	6e850513          	addi	a0,a0,1768 # 80015870 <bcache>
    80003190:	a81fd0ef          	jal	80000c10 <acquire>
  b->refcnt++;
    80003194:	40bc                	lw	a5,64(s1)
    80003196:	2785                	addiw	a5,a5,1
    80003198:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000319a:	00012517          	auipc	a0,0x12
    8000319e:	6d650513          	addi	a0,a0,1750 # 80015870 <bcache>
    800031a2:	b07fd0ef          	jal	80000ca8 <release>
}
    800031a6:	60e2                	ld	ra,24(sp)
    800031a8:	6442                	ld	s0,16(sp)
    800031aa:	64a2                	ld	s1,8(sp)
    800031ac:	6105                	addi	sp,sp,32
    800031ae:	8082                	ret

00000000800031b0 <bunpin>:

void
bunpin(struct buf *b) {
    800031b0:	1101                	addi	sp,sp,-32
    800031b2:	ec06                	sd	ra,24(sp)
    800031b4:	e822                	sd	s0,16(sp)
    800031b6:	e426                	sd	s1,8(sp)
    800031b8:	1000                	addi	s0,sp,32
    800031ba:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    800031bc:	00012517          	auipc	a0,0x12
    800031c0:	6b450513          	addi	a0,a0,1716 # 80015870 <bcache>
    800031c4:	a4dfd0ef          	jal	80000c10 <acquire>
  b->refcnt--;
    800031c8:	40bc                	lw	a5,64(s1)
    800031ca:	37fd                	addiw	a5,a5,-1
    800031cc:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800031ce:	00012517          	auipc	a0,0x12
    800031d2:	6a250513          	addi	a0,a0,1698 # 80015870 <bcache>
    800031d6:	ad3fd0ef          	jal	80000ca8 <release>
}
    800031da:	60e2                	ld	ra,24(sp)
    800031dc:	6442                	ld	s0,16(sp)
    800031de:	64a2                	ld	s1,8(sp)
    800031e0:	6105                	addi	sp,sp,32
    800031e2:	8082                	ret

00000000800031e4 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    800031e4:	1101                	addi	sp,sp,-32
    800031e6:	ec06                	sd	ra,24(sp)
    800031e8:	e822                	sd	s0,16(sp)
    800031ea:	e426                	sd	s1,8(sp)
    800031ec:	e04a                	sd	s2,0(sp)
    800031ee:	1000                	addi	s0,sp,32
    800031f0:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    800031f2:	00d5d59b          	srliw	a1,a1,0xd
    800031f6:	0001b797          	auipc	a5,0x1b
    800031fa:	d567a783          	lw	a5,-682(a5) # 8001df4c <sb+0x1c>
    800031fe:	9dbd                	addw	a1,a1,a5
    80003200:	dedff0ef          	jal	80002fec <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80003204:	0074f713          	andi	a4,s1,7
    80003208:	4785                	li	a5,1
    8000320a:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    8000320e:	14ce                	slli	s1,s1,0x33
    80003210:	90d9                	srli	s1,s1,0x36
    80003212:	00950733          	add	a4,a0,s1
    80003216:	05874703          	lbu	a4,88(a4)
    8000321a:	00e7f6b3          	and	a3,a5,a4
    8000321e:	c29d                	beqz	a3,80003244 <bfree+0x60>
    80003220:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80003222:	94aa                	add	s1,s1,a0
    80003224:	fff7c793          	not	a5,a5
    80003228:	8f7d                	and	a4,a4,a5
    8000322a:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    8000322e:	7f9000ef          	jal	80004226 <log_write>
  brelse(bp);
    80003232:	854a                	mv	a0,s2
    80003234:	ec1ff0ef          	jal	800030f4 <brelse>
}
    80003238:	60e2                	ld	ra,24(sp)
    8000323a:	6442                	ld	s0,16(sp)
    8000323c:	64a2                	ld	s1,8(sp)
    8000323e:	6902                	ld	s2,0(sp)
    80003240:	6105                	addi	sp,sp,32
    80003242:	8082                	ret
    panic("freeing free block");
    80003244:	00004517          	auipc	a0,0x4
    80003248:	1f450513          	addi	a0,a0,500 # 80007438 <etext+0x438>
    8000324c:	d94fd0ef          	jal	800007e0 <panic>

0000000080003250 <balloc>:
{
    80003250:	711d                	addi	sp,sp,-96
    80003252:	ec86                	sd	ra,88(sp)
    80003254:	e8a2                	sd	s0,80(sp)
    80003256:	e4a6                	sd	s1,72(sp)
    80003258:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    8000325a:	0001b797          	auipc	a5,0x1b
    8000325e:	cda7a783          	lw	a5,-806(a5) # 8001df34 <sb+0x4>
    80003262:	0e078f63          	beqz	a5,80003360 <balloc+0x110>
    80003266:	e0ca                	sd	s2,64(sp)
    80003268:	fc4e                	sd	s3,56(sp)
    8000326a:	f852                	sd	s4,48(sp)
    8000326c:	f456                	sd	s5,40(sp)
    8000326e:	f05a                	sd	s6,32(sp)
    80003270:	ec5e                	sd	s7,24(sp)
    80003272:	e862                	sd	s8,16(sp)
    80003274:	e466                	sd	s9,8(sp)
    80003276:	8baa                	mv	s7,a0
    80003278:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    8000327a:	0001bb17          	auipc	s6,0x1b
    8000327e:	cb6b0b13          	addi	s6,s6,-842 # 8001df30 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003282:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    80003284:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003286:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80003288:	6c89                	lui	s9,0x2
    8000328a:	a0b5                	j	800032f6 <balloc+0xa6>
        bp->data[bi/8] |= m;  // Mark block in use.
    8000328c:	97ca                	add	a5,a5,s2
    8000328e:	8e55                	or	a2,a2,a3
    80003290:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80003294:	854a                	mv	a0,s2
    80003296:	791000ef          	jal	80004226 <log_write>
        brelse(bp);
    8000329a:	854a                	mv	a0,s2
    8000329c:	e59ff0ef          	jal	800030f4 <brelse>
  bp = bread(dev, bno);
    800032a0:	85a6                	mv	a1,s1
    800032a2:	855e                	mv	a0,s7
    800032a4:	d49ff0ef          	jal	80002fec <bread>
    800032a8:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    800032aa:	40000613          	li	a2,1024
    800032ae:	4581                	li	a1,0
    800032b0:	05850513          	addi	a0,a0,88
    800032b4:	a31fd0ef          	jal	80000ce4 <memset>
  log_write(bp);
    800032b8:	854a                	mv	a0,s2
    800032ba:	76d000ef          	jal	80004226 <log_write>
  brelse(bp);
    800032be:	854a                	mv	a0,s2
    800032c0:	e35ff0ef          	jal	800030f4 <brelse>
}
    800032c4:	6906                	ld	s2,64(sp)
    800032c6:	79e2                	ld	s3,56(sp)
    800032c8:	7a42                	ld	s4,48(sp)
    800032ca:	7aa2                	ld	s5,40(sp)
    800032cc:	7b02                	ld	s6,32(sp)
    800032ce:	6be2                	ld	s7,24(sp)
    800032d0:	6c42                	ld	s8,16(sp)
    800032d2:	6ca2                	ld	s9,8(sp)
}
    800032d4:	8526                	mv	a0,s1
    800032d6:	60e6                	ld	ra,88(sp)
    800032d8:	6446                	ld	s0,80(sp)
    800032da:	64a6                	ld	s1,72(sp)
    800032dc:	6125                	addi	sp,sp,96
    800032de:	8082                	ret
    brelse(bp);
    800032e0:	854a                	mv	a0,s2
    800032e2:	e13ff0ef          	jal	800030f4 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    800032e6:	015c87bb          	addw	a5,s9,s5
    800032ea:	00078a9b          	sext.w	s5,a5
    800032ee:	004b2703          	lw	a4,4(s6)
    800032f2:	04eaff63          	bgeu	s5,a4,80003350 <balloc+0x100>
    bp = bread(dev, BBLOCK(b, sb));
    800032f6:	41fad79b          	sraiw	a5,s5,0x1f
    800032fa:	0137d79b          	srliw	a5,a5,0x13
    800032fe:	015787bb          	addw	a5,a5,s5
    80003302:	40d7d79b          	sraiw	a5,a5,0xd
    80003306:	01cb2583          	lw	a1,28(s6)
    8000330a:	9dbd                	addw	a1,a1,a5
    8000330c:	855e                	mv	a0,s7
    8000330e:	cdfff0ef          	jal	80002fec <bread>
    80003312:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003314:	004b2503          	lw	a0,4(s6)
    80003318:	000a849b          	sext.w	s1,s5
    8000331c:	8762                	mv	a4,s8
    8000331e:	fca4f1e3          	bgeu	s1,a0,800032e0 <balloc+0x90>
      m = 1 << (bi % 8);
    80003322:	00777693          	andi	a3,a4,7
    80003326:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    8000332a:	41f7579b          	sraiw	a5,a4,0x1f
    8000332e:	01d7d79b          	srliw	a5,a5,0x1d
    80003332:	9fb9                	addw	a5,a5,a4
    80003334:	4037d79b          	sraiw	a5,a5,0x3
    80003338:	00f90633          	add	a2,s2,a5
    8000333c:	05864603          	lbu	a2,88(a2)
    80003340:	00c6f5b3          	and	a1,a3,a2
    80003344:	d5a1                	beqz	a1,8000328c <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003346:	2705                	addiw	a4,a4,1
    80003348:	2485                	addiw	s1,s1,1
    8000334a:	fd471ae3          	bne	a4,s4,8000331e <balloc+0xce>
    8000334e:	bf49                	j	800032e0 <balloc+0x90>
    80003350:	6906                	ld	s2,64(sp)
    80003352:	79e2                	ld	s3,56(sp)
    80003354:	7a42                	ld	s4,48(sp)
    80003356:	7aa2                	ld	s5,40(sp)
    80003358:	7b02                	ld	s6,32(sp)
    8000335a:	6be2                	ld	s7,24(sp)
    8000335c:	6c42                	ld	s8,16(sp)
    8000335e:	6ca2                	ld	s9,8(sp)
  printf("balloc: out of blocks\n");
    80003360:	00004517          	auipc	a0,0x4
    80003364:	0f050513          	addi	a0,a0,240 # 80007450 <etext+0x450>
    80003368:	992fd0ef          	jal	800004fa <printf>
  return 0;
    8000336c:	4481                	li	s1,0
    8000336e:	b79d                	j	800032d4 <balloc+0x84>

0000000080003370 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80003370:	7179                	addi	sp,sp,-48
    80003372:	f406                	sd	ra,40(sp)
    80003374:	f022                	sd	s0,32(sp)
    80003376:	ec26                	sd	s1,24(sp)
    80003378:	e84a                	sd	s2,16(sp)
    8000337a:	e44e                	sd	s3,8(sp)
    8000337c:	1800                	addi	s0,sp,48
    8000337e:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80003380:	47ad                	li	a5,11
    80003382:	02b7e663          	bltu	a5,a1,800033ae <bmap+0x3e>
    if((addr = ip->addrs[bn]) == 0){
    80003386:	02059793          	slli	a5,a1,0x20
    8000338a:	01e7d593          	srli	a1,a5,0x1e
    8000338e:	00b504b3          	add	s1,a0,a1
    80003392:	0504a903          	lw	s2,80(s1)
    80003396:	06091a63          	bnez	s2,8000340a <bmap+0x9a>
      addr = balloc(ip->dev);
    8000339a:	4108                	lw	a0,0(a0)
    8000339c:	eb5ff0ef          	jal	80003250 <balloc>
    800033a0:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    800033a4:	06090363          	beqz	s2,8000340a <bmap+0x9a>
        return 0;
      ip->addrs[bn] = addr;
    800033a8:	0524a823          	sw	s2,80(s1)
    800033ac:	a8b9                	j	8000340a <bmap+0x9a>
    }
    return addr;
  }
  bn -= NDIRECT;
    800033ae:	ff45849b          	addiw	s1,a1,-12
    800033b2:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    800033b6:	0ff00793          	li	a5,255
    800033ba:	06e7ee63          	bltu	a5,a4,80003436 <bmap+0xc6>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    800033be:	08052903          	lw	s2,128(a0)
    800033c2:	00091d63          	bnez	s2,800033dc <bmap+0x6c>
      addr = balloc(ip->dev);
    800033c6:	4108                	lw	a0,0(a0)
    800033c8:	e89ff0ef          	jal	80003250 <balloc>
    800033cc:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    800033d0:	02090d63          	beqz	s2,8000340a <bmap+0x9a>
    800033d4:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    800033d6:	0929a023          	sw	s2,128(s3)
    800033da:	a011                	j	800033de <bmap+0x6e>
    800033dc:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    800033de:	85ca                	mv	a1,s2
    800033e0:	0009a503          	lw	a0,0(s3)
    800033e4:	c09ff0ef          	jal	80002fec <bread>
    800033e8:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    800033ea:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    800033ee:	02049713          	slli	a4,s1,0x20
    800033f2:	01e75593          	srli	a1,a4,0x1e
    800033f6:	00b784b3          	add	s1,a5,a1
    800033fa:	0004a903          	lw	s2,0(s1)
    800033fe:	00090e63          	beqz	s2,8000341a <bmap+0xaa>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80003402:	8552                	mv	a0,s4
    80003404:	cf1ff0ef          	jal	800030f4 <brelse>
    return addr;
    80003408:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    8000340a:	854a                	mv	a0,s2
    8000340c:	70a2                	ld	ra,40(sp)
    8000340e:	7402                	ld	s0,32(sp)
    80003410:	64e2                	ld	s1,24(sp)
    80003412:	6942                	ld	s2,16(sp)
    80003414:	69a2                	ld	s3,8(sp)
    80003416:	6145                	addi	sp,sp,48
    80003418:	8082                	ret
      addr = balloc(ip->dev);
    8000341a:	0009a503          	lw	a0,0(s3)
    8000341e:	e33ff0ef          	jal	80003250 <balloc>
    80003422:	0005091b          	sext.w	s2,a0
      if(addr){
    80003426:	fc090ee3          	beqz	s2,80003402 <bmap+0x92>
        a[bn] = addr;
    8000342a:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    8000342e:	8552                	mv	a0,s4
    80003430:	5f7000ef          	jal	80004226 <log_write>
    80003434:	b7f9                	j	80003402 <bmap+0x92>
    80003436:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80003438:	00004517          	auipc	a0,0x4
    8000343c:	03050513          	addi	a0,a0,48 # 80007468 <etext+0x468>
    80003440:	ba0fd0ef          	jal	800007e0 <panic>

0000000080003444 <iget>:
{
    80003444:	7179                	addi	sp,sp,-48
    80003446:	f406                	sd	ra,40(sp)
    80003448:	f022                	sd	s0,32(sp)
    8000344a:	ec26                	sd	s1,24(sp)
    8000344c:	e84a                	sd	s2,16(sp)
    8000344e:	e44e                	sd	s3,8(sp)
    80003450:	e052                	sd	s4,0(sp)
    80003452:	1800                	addi	s0,sp,48
    80003454:	89aa                	mv	s3,a0
    80003456:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80003458:	0001b517          	auipc	a0,0x1b
    8000345c:	af850513          	addi	a0,a0,-1288 # 8001df50 <itable>
    80003460:	fb0fd0ef          	jal	80000c10 <acquire>
  empty = 0;
    80003464:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003466:	0001b497          	auipc	s1,0x1b
    8000346a:	b0248493          	addi	s1,s1,-1278 # 8001df68 <itable+0x18>
    8000346e:	0001c697          	auipc	a3,0x1c
    80003472:	58a68693          	addi	a3,a3,1418 # 8001f9f8 <log>
    80003476:	a039                	j	80003484 <iget+0x40>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003478:	02090963          	beqz	s2,800034aa <iget+0x66>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    8000347c:	08848493          	addi	s1,s1,136
    80003480:	02d48863          	beq	s1,a3,800034b0 <iget+0x6c>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80003484:	449c                	lw	a5,8(s1)
    80003486:	fef059e3          	blez	a5,80003478 <iget+0x34>
    8000348a:	4098                	lw	a4,0(s1)
    8000348c:	ff3716e3          	bne	a4,s3,80003478 <iget+0x34>
    80003490:	40d8                	lw	a4,4(s1)
    80003492:	ff4713e3          	bne	a4,s4,80003478 <iget+0x34>
      ip->ref++;
    80003496:	2785                	addiw	a5,a5,1
    80003498:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    8000349a:	0001b517          	auipc	a0,0x1b
    8000349e:	ab650513          	addi	a0,a0,-1354 # 8001df50 <itable>
    800034a2:	807fd0ef          	jal	80000ca8 <release>
      return ip;
    800034a6:	8926                	mv	s2,s1
    800034a8:	a02d                	j	800034d2 <iget+0x8e>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800034aa:	fbe9                	bnez	a5,8000347c <iget+0x38>
      empty = ip;
    800034ac:	8926                	mv	s2,s1
    800034ae:	b7f9                	j	8000347c <iget+0x38>
  if(empty == 0)
    800034b0:	02090a63          	beqz	s2,800034e4 <iget+0xa0>
  ip->dev = dev;
    800034b4:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    800034b8:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    800034bc:	4785                	li	a5,1
    800034be:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    800034c2:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    800034c6:	0001b517          	auipc	a0,0x1b
    800034ca:	a8a50513          	addi	a0,a0,-1398 # 8001df50 <itable>
    800034ce:	fdafd0ef          	jal	80000ca8 <release>
}
    800034d2:	854a                	mv	a0,s2
    800034d4:	70a2                	ld	ra,40(sp)
    800034d6:	7402                	ld	s0,32(sp)
    800034d8:	64e2                	ld	s1,24(sp)
    800034da:	6942                	ld	s2,16(sp)
    800034dc:	69a2                	ld	s3,8(sp)
    800034de:	6a02                	ld	s4,0(sp)
    800034e0:	6145                	addi	sp,sp,48
    800034e2:	8082                	ret
    panic("iget: no inodes");
    800034e4:	00004517          	auipc	a0,0x4
    800034e8:	f9c50513          	addi	a0,a0,-100 # 80007480 <etext+0x480>
    800034ec:	af4fd0ef          	jal	800007e0 <panic>

00000000800034f0 <iinit>:
{
    800034f0:	7179                	addi	sp,sp,-48
    800034f2:	f406                	sd	ra,40(sp)
    800034f4:	f022                	sd	s0,32(sp)
    800034f6:	ec26                	sd	s1,24(sp)
    800034f8:	e84a                	sd	s2,16(sp)
    800034fa:	e44e                	sd	s3,8(sp)
    800034fc:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800034fe:	00004597          	auipc	a1,0x4
    80003502:	f9258593          	addi	a1,a1,-110 # 80007490 <etext+0x490>
    80003506:	0001b517          	auipc	a0,0x1b
    8000350a:	a4a50513          	addi	a0,a0,-1462 # 8001df50 <itable>
    8000350e:	e82fd0ef          	jal	80000b90 <initlock>
  for(i = 0; i < NINODE; i++) {
    80003512:	0001b497          	auipc	s1,0x1b
    80003516:	a6648493          	addi	s1,s1,-1434 # 8001df78 <itable+0x28>
    8000351a:	0001c997          	auipc	s3,0x1c
    8000351e:	4ee98993          	addi	s3,s3,1262 # 8001fa08 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80003522:	00004917          	auipc	s2,0x4
    80003526:	f7690913          	addi	s2,s2,-138 # 80007498 <etext+0x498>
    8000352a:	85ca                	mv	a1,s2
    8000352c:	8526                	mv	a0,s1
    8000352e:	5bb000ef          	jal	800042e8 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80003532:	08848493          	addi	s1,s1,136
    80003536:	ff349ae3          	bne	s1,s3,8000352a <iinit+0x3a>
}
    8000353a:	70a2                	ld	ra,40(sp)
    8000353c:	7402                	ld	s0,32(sp)
    8000353e:	64e2                	ld	s1,24(sp)
    80003540:	6942                	ld	s2,16(sp)
    80003542:	69a2                	ld	s3,8(sp)
    80003544:	6145                	addi	sp,sp,48
    80003546:	8082                	ret

0000000080003548 <ialloc>:
{
    80003548:	7139                	addi	sp,sp,-64
    8000354a:	fc06                	sd	ra,56(sp)
    8000354c:	f822                	sd	s0,48(sp)
    8000354e:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80003550:	0001b717          	auipc	a4,0x1b
    80003554:	9ec72703          	lw	a4,-1556(a4) # 8001df3c <sb+0xc>
    80003558:	4785                	li	a5,1
    8000355a:	06e7f063          	bgeu	a5,a4,800035ba <ialloc+0x72>
    8000355e:	f426                	sd	s1,40(sp)
    80003560:	f04a                	sd	s2,32(sp)
    80003562:	ec4e                	sd	s3,24(sp)
    80003564:	e852                	sd	s4,16(sp)
    80003566:	e456                	sd	s5,8(sp)
    80003568:	e05a                	sd	s6,0(sp)
    8000356a:	8aaa                	mv	s5,a0
    8000356c:	8b2e                	mv	s6,a1
    8000356e:	4905                	li	s2,1
    bp = bread(dev, IBLOCK(inum, sb));
    80003570:	0001ba17          	auipc	s4,0x1b
    80003574:	9c0a0a13          	addi	s4,s4,-1600 # 8001df30 <sb>
    80003578:	00495593          	srli	a1,s2,0x4
    8000357c:	018a2783          	lw	a5,24(s4)
    80003580:	9dbd                	addw	a1,a1,a5
    80003582:	8556                	mv	a0,s5
    80003584:	a69ff0ef          	jal	80002fec <bread>
    80003588:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    8000358a:	05850993          	addi	s3,a0,88
    8000358e:	00f97793          	andi	a5,s2,15
    80003592:	079a                	slli	a5,a5,0x6
    80003594:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80003596:	00099783          	lh	a5,0(s3)
    8000359a:	cb9d                	beqz	a5,800035d0 <ialloc+0x88>
    brelse(bp);
    8000359c:	b59ff0ef          	jal	800030f4 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    800035a0:	0905                	addi	s2,s2,1
    800035a2:	00ca2703          	lw	a4,12(s4)
    800035a6:	0009079b          	sext.w	a5,s2
    800035aa:	fce7e7e3          	bltu	a5,a4,80003578 <ialloc+0x30>
    800035ae:	74a2                	ld	s1,40(sp)
    800035b0:	7902                	ld	s2,32(sp)
    800035b2:	69e2                	ld	s3,24(sp)
    800035b4:	6a42                	ld	s4,16(sp)
    800035b6:	6aa2                	ld	s5,8(sp)
    800035b8:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    800035ba:	00004517          	auipc	a0,0x4
    800035be:	ee650513          	addi	a0,a0,-282 # 800074a0 <etext+0x4a0>
    800035c2:	f39fc0ef          	jal	800004fa <printf>
  return 0;
    800035c6:	4501                	li	a0,0
}
    800035c8:	70e2                	ld	ra,56(sp)
    800035ca:	7442                	ld	s0,48(sp)
    800035cc:	6121                	addi	sp,sp,64
    800035ce:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800035d0:	04000613          	li	a2,64
    800035d4:	4581                	li	a1,0
    800035d6:	854e                	mv	a0,s3
    800035d8:	f0cfd0ef          	jal	80000ce4 <memset>
      dip->type = type;
    800035dc:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    800035e0:	8526                	mv	a0,s1
    800035e2:	445000ef          	jal	80004226 <log_write>
      brelse(bp);
    800035e6:	8526                	mv	a0,s1
    800035e8:	b0dff0ef          	jal	800030f4 <brelse>
      return iget(dev, inum);
    800035ec:	0009059b          	sext.w	a1,s2
    800035f0:	8556                	mv	a0,s5
    800035f2:	e53ff0ef          	jal	80003444 <iget>
    800035f6:	74a2                	ld	s1,40(sp)
    800035f8:	7902                	ld	s2,32(sp)
    800035fa:	69e2                	ld	s3,24(sp)
    800035fc:	6a42                	ld	s4,16(sp)
    800035fe:	6aa2                	ld	s5,8(sp)
    80003600:	6b02                	ld	s6,0(sp)
    80003602:	b7d9                	j	800035c8 <ialloc+0x80>

0000000080003604 <iupdate>:
{
    80003604:	1101                	addi	sp,sp,-32
    80003606:	ec06                	sd	ra,24(sp)
    80003608:	e822                	sd	s0,16(sp)
    8000360a:	e426                	sd	s1,8(sp)
    8000360c:	e04a                	sd	s2,0(sp)
    8000360e:	1000                	addi	s0,sp,32
    80003610:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003612:	415c                	lw	a5,4(a0)
    80003614:	0047d79b          	srliw	a5,a5,0x4
    80003618:	0001b597          	auipc	a1,0x1b
    8000361c:	9305a583          	lw	a1,-1744(a1) # 8001df48 <sb+0x18>
    80003620:	9dbd                	addw	a1,a1,a5
    80003622:	4108                	lw	a0,0(a0)
    80003624:	9c9ff0ef          	jal	80002fec <bread>
    80003628:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000362a:	05850793          	addi	a5,a0,88
    8000362e:	40d8                	lw	a4,4(s1)
    80003630:	8b3d                	andi	a4,a4,15
    80003632:	071a                	slli	a4,a4,0x6
    80003634:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003636:	04449703          	lh	a4,68(s1)
    8000363a:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    8000363e:	04649703          	lh	a4,70(s1)
    80003642:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003646:	04849703          	lh	a4,72(s1)
    8000364a:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    8000364e:	04a49703          	lh	a4,74(s1)
    80003652:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003656:	44f8                	lw	a4,76(s1)
    80003658:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8000365a:	03400613          	li	a2,52
    8000365e:	05048593          	addi	a1,s1,80
    80003662:	00c78513          	addi	a0,a5,12
    80003666:	edafd0ef          	jal	80000d40 <memmove>
  log_write(bp);
    8000366a:	854a                	mv	a0,s2
    8000366c:	3bb000ef          	jal	80004226 <log_write>
  brelse(bp);
    80003670:	854a                	mv	a0,s2
    80003672:	a83ff0ef          	jal	800030f4 <brelse>
}
    80003676:	60e2                	ld	ra,24(sp)
    80003678:	6442                	ld	s0,16(sp)
    8000367a:	64a2                	ld	s1,8(sp)
    8000367c:	6902                	ld	s2,0(sp)
    8000367e:	6105                	addi	sp,sp,32
    80003680:	8082                	ret

0000000080003682 <idup>:
{
    80003682:	1101                	addi	sp,sp,-32
    80003684:	ec06                	sd	ra,24(sp)
    80003686:	e822                	sd	s0,16(sp)
    80003688:	e426                	sd	s1,8(sp)
    8000368a:	1000                	addi	s0,sp,32
    8000368c:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000368e:	0001b517          	auipc	a0,0x1b
    80003692:	8c250513          	addi	a0,a0,-1854 # 8001df50 <itable>
    80003696:	d7afd0ef          	jal	80000c10 <acquire>
  ip->ref++;
    8000369a:	449c                	lw	a5,8(s1)
    8000369c:	2785                	addiw	a5,a5,1
    8000369e:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800036a0:	0001b517          	auipc	a0,0x1b
    800036a4:	8b050513          	addi	a0,a0,-1872 # 8001df50 <itable>
    800036a8:	e00fd0ef          	jal	80000ca8 <release>
}
    800036ac:	8526                	mv	a0,s1
    800036ae:	60e2                	ld	ra,24(sp)
    800036b0:	6442                	ld	s0,16(sp)
    800036b2:	64a2                	ld	s1,8(sp)
    800036b4:	6105                	addi	sp,sp,32
    800036b6:	8082                	ret

00000000800036b8 <ilock>:
{
    800036b8:	1101                	addi	sp,sp,-32
    800036ba:	ec06                	sd	ra,24(sp)
    800036bc:	e822                	sd	s0,16(sp)
    800036be:	e426                	sd	s1,8(sp)
    800036c0:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    800036c2:	cd19                	beqz	a0,800036e0 <ilock+0x28>
    800036c4:	84aa                	mv	s1,a0
    800036c6:	451c                	lw	a5,8(a0)
    800036c8:	00f05c63          	blez	a5,800036e0 <ilock+0x28>
  acquiresleep(&ip->lock);
    800036cc:	0541                	addi	a0,a0,16
    800036ce:	451000ef          	jal	8000431e <acquiresleep>
  if(ip->valid == 0){
    800036d2:	40bc                	lw	a5,64(s1)
    800036d4:	cf89                	beqz	a5,800036ee <ilock+0x36>
}
    800036d6:	60e2                	ld	ra,24(sp)
    800036d8:	6442                	ld	s0,16(sp)
    800036da:	64a2                	ld	s1,8(sp)
    800036dc:	6105                	addi	sp,sp,32
    800036de:	8082                	ret
    800036e0:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800036e2:	00004517          	auipc	a0,0x4
    800036e6:	dd650513          	addi	a0,a0,-554 # 800074b8 <etext+0x4b8>
    800036ea:	8f6fd0ef          	jal	800007e0 <panic>
    800036ee:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800036f0:	40dc                	lw	a5,4(s1)
    800036f2:	0047d79b          	srliw	a5,a5,0x4
    800036f6:	0001b597          	auipc	a1,0x1b
    800036fa:	8525a583          	lw	a1,-1966(a1) # 8001df48 <sb+0x18>
    800036fe:	9dbd                	addw	a1,a1,a5
    80003700:	4088                	lw	a0,0(s1)
    80003702:	8ebff0ef          	jal	80002fec <bread>
    80003706:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003708:	05850593          	addi	a1,a0,88
    8000370c:	40dc                	lw	a5,4(s1)
    8000370e:	8bbd                	andi	a5,a5,15
    80003710:	079a                	slli	a5,a5,0x6
    80003712:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003714:	00059783          	lh	a5,0(a1)
    80003718:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    8000371c:	00259783          	lh	a5,2(a1)
    80003720:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003724:	00459783          	lh	a5,4(a1)
    80003728:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    8000372c:	00659783          	lh	a5,6(a1)
    80003730:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003734:	459c                	lw	a5,8(a1)
    80003736:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003738:	03400613          	li	a2,52
    8000373c:	05b1                	addi	a1,a1,12
    8000373e:	05048513          	addi	a0,s1,80
    80003742:	dfefd0ef          	jal	80000d40 <memmove>
    brelse(bp);
    80003746:	854a                	mv	a0,s2
    80003748:	9adff0ef          	jal	800030f4 <brelse>
    ip->valid = 1;
    8000374c:	4785                	li	a5,1
    8000374e:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80003750:	04449783          	lh	a5,68(s1)
    80003754:	c399                	beqz	a5,8000375a <ilock+0xa2>
    80003756:	6902                	ld	s2,0(sp)
    80003758:	bfbd                	j	800036d6 <ilock+0x1e>
      panic("ilock: no type");
    8000375a:	00004517          	auipc	a0,0x4
    8000375e:	d6650513          	addi	a0,a0,-666 # 800074c0 <etext+0x4c0>
    80003762:	87efd0ef          	jal	800007e0 <panic>

0000000080003766 <iunlock>:
{
    80003766:	1101                	addi	sp,sp,-32
    80003768:	ec06                	sd	ra,24(sp)
    8000376a:	e822                	sd	s0,16(sp)
    8000376c:	e426                	sd	s1,8(sp)
    8000376e:	e04a                	sd	s2,0(sp)
    80003770:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003772:	c505                	beqz	a0,8000379a <iunlock+0x34>
    80003774:	84aa                	mv	s1,a0
    80003776:	01050913          	addi	s2,a0,16
    8000377a:	854a                	mv	a0,s2
    8000377c:	421000ef          	jal	8000439c <holdingsleep>
    80003780:	cd09                	beqz	a0,8000379a <iunlock+0x34>
    80003782:	449c                	lw	a5,8(s1)
    80003784:	00f05b63          	blez	a5,8000379a <iunlock+0x34>
  releasesleep(&ip->lock);
    80003788:	854a                	mv	a0,s2
    8000378a:	3db000ef          	jal	80004364 <releasesleep>
}
    8000378e:	60e2                	ld	ra,24(sp)
    80003790:	6442                	ld	s0,16(sp)
    80003792:	64a2                	ld	s1,8(sp)
    80003794:	6902                	ld	s2,0(sp)
    80003796:	6105                	addi	sp,sp,32
    80003798:	8082                	ret
    panic("iunlock");
    8000379a:	00004517          	auipc	a0,0x4
    8000379e:	d3650513          	addi	a0,a0,-714 # 800074d0 <etext+0x4d0>
    800037a2:	83efd0ef          	jal	800007e0 <panic>

00000000800037a6 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800037a6:	7179                	addi	sp,sp,-48
    800037a8:	f406                	sd	ra,40(sp)
    800037aa:	f022                	sd	s0,32(sp)
    800037ac:	ec26                	sd	s1,24(sp)
    800037ae:	e84a                	sd	s2,16(sp)
    800037b0:	e44e                	sd	s3,8(sp)
    800037b2:	1800                	addi	s0,sp,48
    800037b4:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    800037b6:	05050493          	addi	s1,a0,80
    800037ba:	08050913          	addi	s2,a0,128
    800037be:	a021                	j	800037c6 <itrunc+0x20>
    800037c0:	0491                	addi	s1,s1,4
    800037c2:	01248b63          	beq	s1,s2,800037d8 <itrunc+0x32>
    if(ip->addrs[i]){
    800037c6:	408c                	lw	a1,0(s1)
    800037c8:	dde5                	beqz	a1,800037c0 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    800037ca:	0009a503          	lw	a0,0(s3)
    800037ce:	a17ff0ef          	jal	800031e4 <bfree>
      ip->addrs[i] = 0;
    800037d2:	0004a023          	sw	zero,0(s1)
    800037d6:	b7ed                	j	800037c0 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    800037d8:	0809a583          	lw	a1,128(s3)
    800037dc:	ed89                	bnez	a1,800037f6 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800037de:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800037e2:	854e                	mv	a0,s3
    800037e4:	e21ff0ef          	jal	80003604 <iupdate>
}
    800037e8:	70a2                	ld	ra,40(sp)
    800037ea:	7402                	ld	s0,32(sp)
    800037ec:	64e2                	ld	s1,24(sp)
    800037ee:	6942                	ld	s2,16(sp)
    800037f0:	69a2                	ld	s3,8(sp)
    800037f2:	6145                	addi	sp,sp,48
    800037f4:	8082                	ret
    800037f6:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800037f8:	0009a503          	lw	a0,0(s3)
    800037fc:	ff0ff0ef          	jal	80002fec <bread>
    80003800:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003802:	05850493          	addi	s1,a0,88
    80003806:	45850913          	addi	s2,a0,1112
    8000380a:	a021                	j	80003812 <itrunc+0x6c>
    8000380c:	0491                	addi	s1,s1,4
    8000380e:	01248963          	beq	s1,s2,80003820 <itrunc+0x7a>
      if(a[j])
    80003812:	408c                	lw	a1,0(s1)
    80003814:	dde5                	beqz	a1,8000380c <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80003816:	0009a503          	lw	a0,0(s3)
    8000381a:	9cbff0ef          	jal	800031e4 <bfree>
    8000381e:	b7fd                	j	8000380c <itrunc+0x66>
    brelse(bp);
    80003820:	8552                	mv	a0,s4
    80003822:	8d3ff0ef          	jal	800030f4 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003826:	0809a583          	lw	a1,128(s3)
    8000382a:	0009a503          	lw	a0,0(s3)
    8000382e:	9b7ff0ef          	jal	800031e4 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003832:	0809a023          	sw	zero,128(s3)
    80003836:	6a02                	ld	s4,0(sp)
    80003838:	b75d                	j	800037de <itrunc+0x38>

000000008000383a <iput>:
{
    8000383a:	1101                	addi	sp,sp,-32
    8000383c:	ec06                	sd	ra,24(sp)
    8000383e:	e822                	sd	s0,16(sp)
    80003840:	e426                	sd	s1,8(sp)
    80003842:	1000                	addi	s0,sp,32
    80003844:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003846:	0001a517          	auipc	a0,0x1a
    8000384a:	70a50513          	addi	a0,a0,1802 # 8001df50 <itable>
    8000384e:	bc2fd0ef          	jal	80000c10 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003852:	4498                	lw	a4,8(s1)
    80003854:	4785                	li	a5,1
    80003856:	02f70063          	beq	a4,a5,80003876 <iput+0x3c>
  ip->ref--;
    8000385a:	449c                	lw	a5,8(s1)
    8000385c:	37fd                	addiw	a5,a5,-1
    8000385e:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003860:	0001a517          	auipc	a0,0x1a
    80003864:	6f050513          	addi	a0,a0,1776 # 8001df50 <itable>
    80003868:	c40fd0ef          	jal	80000ca8 <release>
}
    8000386c:	60e2                	ld	ra,24(sp)
    8000386e:	6442                	ld	s0,16(sp)
    80003870:	64a2                	ld	s1,8(sp)
    80003872:	6105                	addi	sp,sp,32
    80003874:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003876:	40bc                	lw	a5,64(s1)
    80003878:	d3ed                	beqz	a5,8000385a <iput+0x20>
    8000387a:	04a49783          	lh	a5,74(s1)
    8000387e:	fff1                	bnez	a5,8000385a <iput+0x20>
    80003880:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80003882:	01048913          	addi	s2,s1,16
    80003886:	854a                	mv	a0,s2
    80003888:	297000ef          	jal	8000431e <acquiresleep>
    release(&itable.lock);
    8000388c:	0001a517          	auipc	a0,0x1a
    80003890:	6c450513          	addi	a0,a0,1732 # 8001df50 <itable>
    80003894:	c14fd0ef          	jal	80000ca8 <release>
    itrunc(ip);
    80003898:	8526                	mv	a0,s1
    8000389a:	f0dff0ef          	jal	800037a6 <itrunc>
    ip->type = 0;
    8000389e:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    800038a2:	8526                	mv	a0,s1
    800038a4:	d61ff0ef          	jal	80003604 <iupdate>
    ip->valid = 0;
    800038a8:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    800038ac:	854a                	mv	a0,s2
    800038ae:	2b7000ef          	jal	80004364 <releasesleep>
    acquire(&itable.lock);
    800038b2:	0001a517          	auipc	a0,0x1a
    800038b6:	69e50513          	addi	a0,a0,1694 # 8001df50 <itable>
    800038ba:	b56fd0ef          	jal	80000c10 <acquire>
    800038be:	6902                	ld	s2,0(sp)
    800038c0:	bf69                	j	8000385a <iput+0x20>

00000000800038c2 <iunlockput>:
{
    800038c2:	1101                	addi	sp,sp,-32
    800038c4:	ec06                	sd	ra,24(sp)
    800038c6:	e822                	sd	s0,16(sp)
    800038c8:	e426                	sd	s1,8(sp)
    800038ca:	1000                	addi	s0,sp,32
    800038cc:	84aa                	mv	s1,a0
  iunlock(ip);
    800038ce:	e99ff0ef          	jal	80003766 <iunlock>
  iput(ip);
    800038d2:	8526                	mv	a0,s1
    800038d4:	f67ff0ef          	jal	8000383a <iput>
}
    800038d8:	60e2                	ld	ra,24(sp)
    800038da:	6442                	ld	s0,16(sp)
    800038dc:	64a2                	ld	s1,8(sp)
    800038de:	6105                	addi	sp,sp,32
    800038e0:	8082                	ret

00000000800038e2 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800038e2:	0001a717          	auipc	a4,0x1a
    800038e6:	65a72703          	lw	a4,1626(a4) # 8001df3c <sb+0xc>
    800038ea:	4785                	li	a5,1
    800038ec:	0ae7ff63          	bgeu	a5,a4,800039aa <ireclaim+0xc8>
{
    800038f0:	7139                	addi	sp,sp,-64
    800038f2:	fc06                	sd	ra,56(sp)
    800038f4:	f822                	sd	s0,48(sp)
    800038f6:	f426                	sd	s1,40(sp)
    800038f8:	f04a                	sd	s2,32(sp)
    800038fa:	ec4e                	sd	s3,24(sp)
    800038fc:	e852                	sd	s4,16(sp)
    800038fe:	e456                	sd	s5,8(sp)
    80003900:	e05a                	sd	s6,0(sp)
    80003902:	0080                	addi	s0,sp,64
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003904:	4485                	li	s1,1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003906:	00050a1b          	sext.w	s4,a0
    8000390a:	0001aa97          	auipc	s5,0x1a
    8000390e:	626a8a93          	addi	s5,s5,1574 # 8001df30 <sb>
      printf("ireclaim: orphaned inode %d\n", inum);
    80003912:	00004b17          	auipc	s6,0x4
    80003916:	bc6b0b13          	addi	s6,s6,-1082 # 800074d8 <etext+0x4d8>
    8000391a:	a099                	j	80003960 <ireclaim+0x7e>
    8000391c:	85ce                	mv	a1,s3
    8000391e:	855a                	mv	a0,s6
    80003920:	bdbfc0ef          	jal	800004fa <printf>
      ip = iget(dev, inum);
    80003924:	85ce                	mv	a1,s3
    80003926:	8552                	mv	a0,s4
    80003928:	b1dff0ef          	jal	80003444 <iget>
    8000392c:	89aa                	mv	s3,a0
    brelse(bp);
    8000392e:	854a                	mv	a0,s2
    80003930:	fc4ff0ef          	jal	800030f4 <brelse>
    if (ip) {
    80003934:	00098f63          	beqz	s3,80003952 <ireclaim+0x70>
      begin_op();
    80003938:	76a000ef          	jal	800040a2 <begin_op>
      ilock(ip);
    8000393c:	854e                	mv	a0,s3
    8000393e:	d7bff0ef          	jal	800036b8 <ilock>
      iunlock(ip);
    80003942:	854e                	mv	a0,s3
    80003944:	e23ff0ef          	jal	80003766 <iunlock>
      iput(ip);
    80003948:	854e                	mv	a0,s3
    8000394a:	ef1ff0ef          	jal	8000383a <iput>
      end_op();
    8000394e:	7be000ef          	jal	8000410c <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003952:	0485                	addi	s1,s1,1
    80003954:	00caa703          	lw	a4,12(s5)
    80003958:	0004879b          	sext.w	a5,s1
    8000395c:	02e7fd63          	bgeu	a5,a4,80003996 <ireclaim+0xb4>
    80003960:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003964:	0044d593          	srli	a1,s1,0x4
    80003968:	018aa783          	lw	a5,24(s5)
    8000396c:	9dbd                	addw	a1,a1,a5
    8000396e:	8552                	mv	a0,s4
    80003970:	e7cff0ef          	jal	80002fec <bread>
    80003974:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003976:	05850793          	addi	a5,a0,88
    8000397a:	00f9f713          	andi	a4,s3,15
    8000397e:	071a                	slli	a4,a4,0x6
    80003980:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) {  // is an orphaned inode
    80003982:	00079703          	lh	a4,0(a5)
    80003986:	c701                	beqz	a4,8000398e <ireclaim+0xac>
    80003988:	00679783          	lh	a5,6(a5)
    8000398c:	dbc1                	beqz	a5,8000391c <ireclaim+0x3a>
    brelse(bp);
    8000398e:	854a                	mv	a0,s2
    80003990:	f64ff0ef          	jal	800030f4 <brelse>
    if (ip) {
    80003994:	bf7d                	j	80003952 <ireclaim+0x70>
}
    80003996:	70e2                	ld	ra,56(sp)
    80003998:	7442                	ld	s0,48(sp)
    8000399a:	74a2                	ld	s1,40(sp)
    8000399c:	7902                	ld	s2,32(sp)
    8000399e:	69e2                	ld	s3,24(sp)
    800039a0:	6a42                	ld	s4,16(sp)
    800039a2:	6aa2                	ld	s5,8(sp)
    800039a4:	6b02                	ld	s6,0(sp)
    800039a6:	6121                	addi	sp,sp,64
    800039a8:	8082                	ret
    800039aa:	8082                	ret

00000000800039ac <fsinit>:
fsinit(int dev) {
    800039ac:	7179                	addi	sp,sp,-48
    800039ae:	f406                	sd	ra,40(sp)
    800039b0:	f022                	sd	s0,32(sp)
    800039b2:	ec26                	sd	s1,24(sp)
    800039b4:	e84a                	sd	s2,16(sp)
    800039b6:	e44e                	sd	s3,8(sp)
    800039b8:	1800                	addi	s0,sp,48
    800039ba:	84aa                	mv	s1,a0
  bp = bread(dev, 1);
    800039bc:	4585                	li	a1,1
    800039be:	e2eff0ef          	jal	80002fec <bread>
    800039c2:	892a                	mv	s2,a0
  memmove(sb, bp->data, sizeof(*sb));
    800039c4:	0001a997          	auipc	s3,0x1a
    800039c8:	56c98993          	addi	s3,s3,1388 # 8001df30 <sb>
    800039cc:	02000613          	li	a2,32
    800039d0:	05850593          	addi	a1,a0,88
    800039d4:	854e                	mv	a0,s3
    800039d6:	b6afd0ef          	jal	80000d40 <memmove>
  brelse(bp);
    800039da:	854a                	mv	a0,s2
    800039dc:	f18ff0ef          	jal	800030f4 <brelse>
  if(sb.magic != FSMAGIC)
    800039e0:	0009a703          	lw	a4,0(s3)
    800039e4:	102037b7          	lui	a5,0x10203
    800039e8:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    800039ec:	02f71363          	bne	a4,a5,80003a12 <fsinit+0x66>
  initlog(dev, &sb);
    800039f0:	0001a597          	auipc	a1,0x1a
    800039f4:	54058593          	addi	a1,a1,1344 # 8001df30 <sb>
    800039f8:	8526                	mv	a0,s1
    800039fa:	62a000ef          	jal	80004024 <initlog>
  ireclaim(dev);
    800039fe:	8526                	mv	a0,s1
    80003a00:	ee3ff0ef          	jal	800038e2 <ireclaim>
}
    80003a04:	70a2                	ld	ra,40(sp)
    80003a06:	7402                	ld	s0,32(sp)
    80003a08:	64e2                	ld	s1,24(sp)
    80003a0a:	6942                	ld	s2,16(sp)
    80003a0c:	69a2                	ld	s3,8(sp)
    80003a0e:	6145                	addi	sp,sp,48
    80003a10:	8082                	ret
    panic("invalid file system");
    80003a12:	00004517          	auipc	a0,0x4
    80003a16:	ae650513          	addi	a0,a0,-1306 # 800074f8 <etext+0x4f8>
    80003a1a:	dc7fc0ef          	jal	800007e0 <panic>

0000000080003a1e <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003a1e:	1141                	addi	sp,sp,-16
    80003a20:	e422                	sd	s0,8(sp)
    80003a22:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003a24:	411c                	lw	a5,0(a0)
    80003a26:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003a28:	415c                	lw	a5,4(a0)
    80003a2a:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003a2c:	04451783          	lh	a5,68(a0)
    80003a30:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003a34:	04a51783          	lh	a5,74(a0)
    80003a38:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003a3c:	04c56783          	lwu	a5,76(a0)
    80003a40:	e99c                	sd	a5,16(a1)
}
    80003a42:	6422                	ld	s0,8(sp)
    80003a44:	0141                	addi	sp,sp,16
    80003a46:	8082                	ret

0000000080003a48 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003a48:	457c                	lw	a5,76(a0)
    80003a4a:	0ed7eb63          	bltu	a5,a3,80003b40 <readi+0xf8>
{
    80003a4e:	7159                	addi	sp,sp,-112
    80003a50:	f486                	sd	ra,104(sp)
    80003a52:	f0a2                	sd	s0,96(sp)
    80003a54:	eca6                	sd	s1,88(sp)
    80003a56:	e0d2                	sd	s4,64(sp)
    80003a58:	fc56                	sd	s5,56(sp)
    80003a5a:	f85a                	sd	s6,48(sp)
    80003a5c:	f45e                	sd	s7,40(sp)
    80003a5e:	1880                	addi	s0,sp,112
    80003a60:	8b2a                	mv	s6,a0
    80003a62:	8bae                	mv	s7,a1
    80003a64:	8a32                	mv	s4,a2
    80003a66:	84b6                	mv	s1,a3
    80003a68:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003a6a:	9f35                	addw	a4,a4,a3
    return 0;
    80003a6c:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80003a6e:	0cd76063          	bltu	a4,a3,80003b2e <readi+0xe6>
    80003a72:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80003a74:	00e7f463          	bgeu	a5,a4,80003a7c <readi+0x34>
    n = ip->size - off;
    80003a78:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003a7c:	080a8f63          	beqz	s5,80003b1a <readi+0xd2>
    80003a80:	e8ca                	sd	s2,80(sp)
    80003a82:	f062                	sd	s8,32(sp)
    80003a84:	ec66                	sd	s9,24(sp)
    80003a86:	e86a                	sd	s10,16(sp)
    80003a88:	e46e                	sd	s11,8(sp)
    80003a8a:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003a8c:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003a90:	5c7d                	li	s8,-1
    80003a92:	a80d                	j	80003ac4 <readi+0x7c>
    80003a94:	020d1d93          	slli	s11,s10,0x20
    80003a98:	020ddd93          	srli	s11,s11,0x20
    80003a9c:	05890613          	addi	a2,s2,88
    80003aa0:	86ee                	mv	a3,s11
    80003aa2:	963a                	add	a2,a2,a4
    80003aa4:	85d2                	mv	a1,s4
    80003aa6:	855e                	mv	a0,s7
    80003aa8:	fd2fe0ef          	jal	8000227a <either_copyout>
    80003aac:	05850763          	beq	a0,s8,80003afa <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003ab0:	854a                	mv	a0,s2
    80003ab2:	e42ff0ef          	jal	800030f4 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003ab6:	013d09bb          	addw	s3,s10,s3
    80003aba:	009d04bb          	addw	s1,s10,s1
    80003abe:	9a6e                	add	s4,s4,s11
    80003ac0:	0559f763          	bgeu	s3,s5,80003b0e <readi+0xc6>
    uint addr = bmap(ip, off/BSIZE);
    80003ac4:	00a4d59b          	srliw	a1,s1,0xa
    80003ac8:	855a                	mv	a0,s6
    80003aca:	8a7ff0ef          	jal	80003370 <bmap>
    80003ace:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003ad2:	c5b1                	beqz	a1,80003b1e <readi+0xd6>
    bp = bread(ip->dev, addr);
    80003ad4:	000b2503          	lw	a0,0(s6)
    80003ad8:	d14ff0ef          	jal	80002fec <bread>
    80003adc:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003ade:	3ff4f713          	andi	a4,s1,1023
    80003ae2:	40ec87bb          	subw	a5,s9,a4
    80003ae6:	413a86bb          	subw	a3,s5,s3
    80003aea:	8d3e                	mv	s10,a5
    80003aec:	2781                	sext.w	a5,a5
    80003aee:	0006861b          	sext.w	a2,a3
    80003af2:	faf671e3          	bgeu	a2,a5,80003a94 <readi+0x4c>
    80003af6:	8d36                	mv	s10,a3
    80003af8:	bf71                	j	80003a94 <readi+0x4c>
      brelse(bp);
    80003afa:	854a                	mv	a0,s2
    80003afc:	df8ff0ef          	jal	800030f4 <brelse>
      tot = -1;
    80003b00:	59fd                	li	s3,-1
      break;
    80003b02:	6946                	ld	s2,80(sp)
    80003b04:	7c02                	ld	s8,32(sp)
    80003b06:	6ce2                	ld	s9,24(sp)
    80003b08:	6d42                	ld	s10,16(sp)
    80003b0a:	6da2                	ld	s11,8(sp)
    80003b0c:	a831                	j	80003b28 <readi+0xe0>
    80003b0e:	6946                	ld	s2,80(sp)
    80003b10:	7c02                	ld	s8,32(sp)
    80003b12:	6ce2                	ld	s9,24(sp)
    80003b14:	6d42                	ld	s10,16(sp)
    80003b16:	6da2                	ld	s11,8(sp)
    80003b18:	a801                	j	80003b28 <readi+0xe0>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003b1a:	89d6                	mv	s3,s5
    80003b1c:	a031                	j	80003b28 <readi+0xe0>
    80003b1e:	6946                	ld	s2,80(sp)
    80003b20:	7c02                	ld	s8,32(sp)
    80003b22:	6ce2                	ld	s9,24(sp)
    80003b24:	6d42                	ld	s10,16(sp)
    80003b26:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003b28:	0009851b          	sext.w	a0,s3
    80003b2c:	69a6                	ld	s3,72(sp)
}
    80003b2e:	70a6                	ld	ra,104(sp)
    80003b30:	7406                	ld	s0,96(sp)
    80003b32:	64e6                	ld	s1,88(sp)
    80003b34:	6a06                	ld	s4,64(sp)
    80003b36:	7ae2                	ld	s5,56(sp)
    80003b38:	7b42                	ld	s6,48(sp)
    80003b3a:	7ba2                	ld	s7,40(sp)
    80003b3c:	6165                	addi	sp,sp,112
    80003b3e:	8082                	ret
    return 0;
    80003b40:	4501                	li	a0,0
}
    80003b42:	8082                	ret

0000000080003b44 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003b44:	457c                	lw	a5,76(a0)
    80003b46:	10d7e063          	bltu	a5,a3,80003c46 <writei+0x102>
{
    80003b4a:	7159                	addi	sp,sp,-112
    80003b4c:	f486                	sd	ra,104(sp)
    80003b4e:	f0a2                	sd	s0,96(sp)
    80003b50:	e8ca                	sd	s2,80(sp)
    80003b52:	e0d2                	sd	s4,64(sp)
    80003b54:	fc56                	sd	s5,56(sp)
    80003b56:	f85a                	sd	s6,48(sp)
    80003b58:	f45e                	sd	s7,40(sp)
    80003b5a:	1880                	addi	s0,sp,112
    80003b5c:	8aaa                	mv	s5,a0
    80003b5e:	8bae                	mv	s7,a1
    80003b60:	8a32                	mv	s4,a2
    80003b62:	8936                	mv	s2,a3
    80003b64:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003b66:	00e687bb          	addw	a5,a3,a4
    80003b6a:	0ed7e063          	bltu	a5,a3,80003c4a <writei+0x106>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80003b6e:	00043737          	lui	a4,0x43
    80003b72:	0cf76e63          	bltu	a4,a5,80003c4e <writei+0x10a>
    80003b76:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003b78:	0a0b0f63          	beqz	s6,80003c36 <writei+0xf2>
    80003b7c:	eca6                	sd	s1,88(sp)
    80003b7e:	f062                	sd	s8,32(sp)
    80003b80:	ec66                	sd	s9,24(sp)
    80003b82:	e86a                	sd	s10,16(sp)
    80003b84:	e46e                	sd	s11,8(sp)
    80003b86:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003b88:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003b8c:	5c7d                	li	s8,-1
    80003b8e:	a825                	j	80003bc6 <writei+0x82>
    80003b90:	020d1d93          	slli	s11,s10,0x20
    80003b94:	020ddd93          	srli	s11,s11,0x20
    80003b98:	05848513          	addi	a0,s1,88
    80003b9c:	86ee                	mv	a3,s11
    80003b9e:	8652                	mv	a2,s4
    80003ba0:	85de                	mv	a1,s7
    80003ba2:	953a                	add	a0,a0,a4
    80003ba4:	f20fe0ef          	jal	800022c4 <either_copyin>
    80003ba8:	05850a63          	beq	a0,s8,80003bfc <writei+0xb8>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003bac:	8526                	mv	a0,s1
    80003bae:	678000ef          	jal	80004226 <log_write>
    brelse(bp);
    80003bb2:	8526                	mv	a0,s1
    80003bb4:	d40ff0ef          	jal	800030f4 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003bb8:	013d09bb          	addw	s3,s10,s3
    80003bbc:	012d093b          	addw	s2,s10,s2
    80003bc0:	9a6e                	add	s4,s4,s11
    80003bc2:	0569f063          	bgeu	s3,s6,80003c02 <writei+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80003bc6:	00a9559b          	srliw	a1,s2,0xa
    80003bca:	8556                	mv	a0,s5
    80003bcc:	fa4ff0ef          	jal	80003370 <bmap>
    80003bd0:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003bd4:	c59d                	beqz	a1,80003c02 <writei+0xbe>
    bp = bread(ip->dev, addr);
    80003bd6:	000aa503          	lw	a0,0(s5)
    80003bda:	c12ff0ef          	jal	80002fec <bread>
    80003bde:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003be0:	3ff97713          	andi	a4,s2,1023
    80003be4:	40ec87bb          	subw	a5,s9,a4
    80003be8:	413b06bb          	subw	a3,s6,s3
    80003bec:	8d3e                	mv	s10,a5
    80003bee:	2781                	sext.w	a5,a5
    80003bf0:	0006861b          	sext.w	a2,a3
    80003bf4:	f8f67ee3          	bgeu	a2,a5,80003b90 <writei+0x4c>
    80003bf8:	8d36                	mv	s10,a3
    80003bfa:	bf59                	j	80003b90 <writei+0x4c>
      brelse(bp);
    80003bfc:	8526                	mv	a0,s1
    80003bfe:	cf6ff0ef          	jal	800030f4 <brelse>
  }

  if(off > ip->size)
    80003c02:	04caa783          	lw	a5,76(s5)
    80003c06:	0327fa63          	bgeu	a5,s2,80003c3a <writei+0xf6>
    ip->size = off;
    80003c0a:	052aa623          	sw	s2,76(s5)
    80003c0e:	64e6                	ld	s1,88(sp)
    80003c10:	7c02                	ld	s8,32(sp)
    80003c12:	6ce2                	ld	s9,24(sp)
    80003c14:	6d42                	ld	s10,16(sp)
    80003c16:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003c18:	8556                	mv	a0,s5
    80003c1a:	9ebff0ef          	jal	80003604 <iupdate>

  return tot;
    80003c1e:	0009851b          	sext.w	a0,s3
    80003c22:	69a6                	ld	s3,72(sp)
}
    80003c24:	70a6                	ld	ra,104(sp)
    80003c26:	7406                	ld	s0,96(sp)
    80003c28:	6946                	ld	s2,80(sp)
    80003c2a:	6a06                	ld	s4,64(sp)
    80003c2c:	7ae2                	ld	s5,56(sp)
    80003c2e:	7b42                	ld	s6,48(sp)
    80003c30:	7ba2                	ld	s7,40(sp)
    80003c32:	6165                	addi	sp,sp,112
    80003c34:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003c36:	89da                	mv	s3,s6
    80003c38:	b7c5                	j	80003c18 <writei+0xd4>
    80003c3a:	64e6                	ld	s1,88(sp)
    80003c3c:	7c02                	ld	s8,32(sp)
    80003c3e:	6ce2                	ld	s9,24(sp)
    80003c40:	6d42                	ld	s10,16(sp)
    80003c42:	6da2                	ld	s11,8(sp)
    80003c44:	bfd1                	j	80003c18 <writei+0xd4>
    return -1;
    80003c46:	557d                	li	a0,-1
}
    80003c48:	8082                	ret
    return -1;
    80003c4a:	557d                	li	a0,-1
    80003c4c:	bfe1                	j	80003c24 <writei+0xe0>
    return -1;
    80003c4e:	557d                	li	a0,-1
    80003c50:	bfd1                	j	80003c24 <writei+0xe0>

0000000080003c52 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003c52:	1141                	addi	sp,sp,-16
    80003c54:	e406                	sd	ra,8(sp)
    80003c56:	e022                	sd	s0,0(sp)
    80003c58:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003c5a:	4639                	li	a2,14
    80003c5c:	954fd0ef          	jal	80000db0 <strncmp>
}
    80003c60:	60a2                	ld	ra,8(sp)
    80003c62:	6402                	ld	s0,0(sp)
    80003c64:	0141                	addi	sp,sp,16
    80003c66:	8082                	ret

0000000080003c68 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003c68:	7139                	addi	sp,sp,-64
    80003c6a:	fc06                	sd	ra,56(sp)
    80003c6c:	f822                	sd	s0,48(sp)
    80003c6e:	f426                	sd	s1,40(sp)
    80003c70:	f04a                	sd	s2,32(sp)
    80003c72:	ec4e                	sd	s3,24(sp)
    80003c74:	e852                	sd	s4,16(sp)
    80003c76:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003c78:	04451703          	lh	a4,68(a0)
    80003c7c:	4785                	li	a5,1
    80003c7e:	00f71a63          	bne	a4,a5,80003c92 <dirlookup+0x2a>
    80003c82:	892a                	mv	s2,a0
    80003c84:	89ae                	mv	s3,a1
    80003c86:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003c88:	457c                	lw	a5,76(a0)
    80003c8a:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003c8c:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003c8e:	e39d                	bnez	a5,80003cb4 <dirlookup+0x4c>
    80003c90:	a095                	j	80003cf4 <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80003c92:	00004517          	auipc	a0,0x4
    80003c96:	87e50513          	addi	a0,a0,-1922 # 80007510 <etext+0x510>
    80003c9a:	b47fc0ef          	jal	800007e0 <panic>
      panic("dirlookup read");
    80003c9e:	00004517          	auipc	a0,0x4
    80003ca2:	88a50513          	addi	a0,a0,-1910 # 80007528 <etext+0x528>
    80003ca6:	b3bfc0ef          	jal	800007e0 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003caa:	24c1                	addiw	s1,s1,16
    80003cac:	04c92783          	lw	a5,76(s2)
    80003cb0:	04f4f163          	bgeu	s1,a5,80003cf2 <dirlookup+0x8a>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003cb4:	4741                	li	a4,16
    80003cb6:	86a6                	mv	a3,s1
    80003cb8:	fc040613          	addi	a2,s0,-64
    80003cbc:	4581                	li	a1,0
    80003cbe:	854a                	mv	a0,s2
    80003cc0:	d89ff0ef          	jal	80003a48 <readi>
    80003cc4:	47c1                	li	a5,16
    80003cc6:	fcf51ce3          	bne	a0,a5,80003c9e <dirlookup+0x36>
    if(de.inum == 0)
    80003cca:	fc045783          	lhu	a5,-64(s0)
    80003cce:	dff1                	beqz	a5,80003caa <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
    80003cd0:	fc240593          	addi	a1,s0,-62
    80003cd4:	854e                	mv	a0,s3
    80003cd6:	f7dff0ef          	jal	80003c52 <namecmp>
    80003cda:	f961                	bnez	a0,80003caa <dirlookup+0x42>
      if(poff)
    80003cdc:	000a0463          	beqz	s4,80003ce4 <dirlookup+0x7c>
        *poff = off;
    80003ce0:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003ce4:	fc045583          	lhu	a1,-64(s0)
    80003ce8:	00092503          	lw	a0,0(s2)
    80003cec:	f58ff0ef          	jal	80003444 <iget>
    80003cf0:	a011                	j	80003cf4 <dirlookup+0x8c>
  return 0;
    80003cf2:	4501                	li	a0,0
}
    80003cf4:	70e2                	ld	ra,56(sp)
    80003cf6:	7442                	ld	s0,48(sp)
    80003cf8:	74a2                	ld	s1,40(sp)
    80003cfa:	7902                	ld	s2,32(sp)
    80003cfc:	69e2                	ld	s3,24(sp)
    80003cfe:	6a42                	ld	s4,16(sp)
    80003d00:	6121                	addi	sp,sp,64
    80003d02:	8082                	ret

0000000080003d04 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003d04:	711d                	addi	sp,sp,-96
    80003d06:	ec86                	sd	ra,88(sp)
    80003d08:	e8a2                	sd	s0,80(sp)
    80003d0a:	e4a6                	sd	s1,72(sp)
    80003d0c:	e0ca                	sd	s2,64(sp)
    80003d0e:	fc4e                	sd	s3,56(sp)
    80003d10:	f852                	sd	s4,48(sp)
    80003d12:	f456                	sd	s5,40(sp)
    80003d14:	f05a                	sd	s6,32(sp)
    80003d16:	ec5e                	sd	s7,24(sp)
    80003d18:	e862                	sd	s8,16(sp)
    80003d1a:	e466                	sd	s9,8(sp)
    80003d1c:	1080                	addi	s0,sp,96
    80003d1e:	84aa                	mv	s1,a0
    80003d20:	8b2e                	mv	s6,a1
    80003d22:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003d24:	00054703          	lbu	a4,0(a0)
    80003d28:	02f00793          	li	a5,47
    80003d2c:	00f70e63          	beq	a4,a5,80003d48 <namex+0x44>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003d30:	be1fd0ef          	jal	80001910 <myproc>
    80003d34:	15053503          	ld	a0,336(a0)
    80003d38:	94bff0ef          	jal	80003682 <idup>
    80003d3c:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003d3e:	02f00913          	li	s2,47
  if(len >= DIRSIZ)
    80003d42:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003d44:	4b85                	li	s7,1
    80003d46:	a871                	j	80003de2 <namex+0xde>
    ip = iget(ROOTDEV, ROOTINO);
    80003d48:	4585                	li	a1,1
    80003d4a:	4505                	li	a0,1
    80003d4c:	ef8ff0ef          	jal	80003444 <iget>
    80003d50:	8a2a                	mv	s4,a0
    80003d52:	b7f5                	j	80003d3e <namex+0x3a>
      iunlockput(ip);
    80003d54:	8552                	mv	a0,s4
    80003d56:	b6dff0ef          	jal	800038c2 <iunlockput>
      return 0;
    80003d5a:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003d5c:	8552                	mv	a0,s4
    80003d5e:	60e6                	ld	ra,88(sp)
    80003d60:	6446                	ld	s0,80(sp)
    80003d62:	64a6                	ld	s1,72(sp)
    80003d64:	6906                	ld	s2,64(sp)
    80003d66:	79e2                	ld	s3,56(sp)
    80003d68:	7a42                	ld	s4,48(sp)
    80003d6a:	7aa2                	ld	s5,40(sp)
    80003d6c:	7b02                	ld	s6,32(sp)
    80003d6e:	6be2                	ld	s7,24(sp)
    80003d70:	6c42                	ld	s8,16(sp)
    80003d72:	6ca2                	ld	s9,8(sp)
    80003d74:	6125                	addi	sp,sp,96
    80003d76:	8082                	ret
      iunlock(ip);
    80003d78:	8552                	mv	a0,s4
    80003d7a:	9edff0ef          	jal	80003766 <iunlock>
      return ip;
    80003d7e:	bff9                	j	80003d5c <namex+0x58>
      iunlockput(ip);
    80003d80:	8552                	mv	a0,s4
    80003d82:	b41ff0ef          	jal	800038c2 <iunlockput>
      return 0;
    80003d86:	8a4e                	mv	s4,s3
    80003d88:	bfd1                	j	80003d5c <namex+0x58>
  len = path - s;
    80003d8a:	40998633          	sub	a2,s3,s1
    80003d8e:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80003d92:	099c5063          	bge	s8,s9,80003e12 <namex+0x10e>
    memmove(name, s, DIRSIZ);
    80003d96:	4639                	li	a2,14
    80003d98:	85a6                	mv	a1,s1
    80003d9a:	8556                	mv	a0,s5
    80003d9c:	fa5fc0ef          	jal	80000d40 <memmove>
    80003da0:	84ce                	mv	s1,s3
  while(*path == '/')
    80003da2:	0004c783          	lbu	a5,0(s1)
    80003da6:	01279763          	bne	a5,s2,80003db4 <namex+0xb0>
    path++;
    80003daa:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003dac:	0004c783          	lbu	a5,0(s1)
    80003db0:	ff278de3          	beq	a5,s2,80003daa <namex+0xa6>
    ilock(ip);
    80003db4:	8552                	mv	a0,s4
    80003db6:	903ff0ef          	jal	800036b8 <ilock>
    if(ip->type != T_DIR){
    80003dba:	044a1783          	lh	a5,68(s4)
    80003dbe:	f9779be3          	bne	a5,s7,80003d54 <namex+0x50>
    if(nameiparent && *path == '\0'){
    80003dc2:	000b0563          	beqz	s6,80003dcc <namex+0xc8>
    80003dc6:	0004c783          	lbu	a5,0(s1)
    80003dca:	d7dd                	beqz	a5,80003d78 <namex+0x74>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003dcc:	4601                	li	a2,0
    80003dce:	85d6                	mv	a1,s5
    80003dd0:	8552                	mv	a0,s4
    80003dd2:	e97ff0ef          	jal	80003c68 <dirlookup>
    80003dd6:	89aa                	mv	s3,a0
    80003dd8:	d545                	beqz	a0,80003d80 <namex+0x7c>
    iunlockput(ip);
    80003dda:	8552                	mv	a0,s4
    80003ddc:	ae7ff0ef          	jal	800038c2 <iunlockput>
    ip = next;
    80003de0:	8a4e                	mv	s4,s3
  while(*path == '/')
    80003de2:	0004c783          	lbu	a5,0(s1)
    80003de6:	01279763          	bne	a5,s2,80003df4 <namex+0xf0>
    path++;
    80003dea:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003dec:	0004c783          	lbu	a5,0(s1)
    80003df0:	ff278de3          	beq	a5,s2,80003dea <namex+0xe6>
  if(*path == 0)
    80003df4:	cb8d                	beqz	a5,80003e26 <namex+0x122>
  while(*path != '/' && *path != 0)
    80003df6:	0004c783          	lbu	a5,0(s1)
    80003dfa:	89a6                	mv	s3,s1
  len = path - s;
    80003dfc:	4c81                	li	s9,0
    80003dfe:	4601                	li	a2,0
  while(*path != '/' && *path != 0)
    80003e00:	01278963          	beq	a5,s2,80003e12 <namex+0x10e>
    80003e04:	d3d9                	beqz	a5,80003d8a <namex+0x86>
    path++;
    80003e06:	0985                	addi	s3,s3,1
  while(*path != '/' && *path != 0)
    80003e08:	0009c783          	lbu	a5,0(s3)
    80003e0c:	ff279ce3          	bne	a5,s2,80003e04 <namex+0x100>
    80003e10:	bfad                	j	80003d8a <namex+0x86>
    memmove(name, s, len);
    80003e12:	2601                	sext.w	a2,a2
    80003e14:	85a6                	mv	a1,s1
    80003e16:	8556                	mv	a0,s5
    80003e18:	f29fc0ef          	jal	80000d40 <memmove>
    name[len] = 0;
    80003e1c:	9cd6                	add	s9,s9,s5
    80003e1e:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80003e22:	84ce                	mv	s1,s3
    80003e24:	bfbd                	j	80003da2 <namex+0x9e>
  if(nameiparent){
    80003e26:	f20b0be3          	beqz	s6,80003d5c <namex+0x58>
    iput(ip);
    80003e2a:	8552                	mv	a0,s4
    80003e2c:	a0fff0ef          	jal	8000383a <iput>
    return 0;
    80003e30:	4a01                	li	s4,0
    80003e32:	b72d                	j	80003d5c <namex+0x58>

0000000080003e34 <dirlink>:
{
    80003e34:	7139                	addi	sp,sp,-64
    80003e36:	fc06                	sd	ra,56(sp)
    80003e38:	f822                	sd	s0,48(sp)
    80003e3a:	f04a                	sd	s2,32(sp)
    80003e3c:	ec4e                	sd	s3,24(sp)
    80003e3e:	e852                	sd	s4,16(sp)
    80003e40:	0080                	addi	s0,sp,64
    80003e42:	892a                	mv	s2,a0
    80003e44:	8a2e                	mv	s4,a1
    80003e46:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003e48:	4601                	li	a2,0
    80003e4a:	e1fff0ef          	jal	80003c68 <dirlookup>
    80003e4e:	e535                	bnez	a0,80003eba <dirlink+0x86>
    80003e50:	f426                	sd	s1,40(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003e52:	04c92483          	lw	s1,76(s2)
    80003e56:	c48d                	beqz	s1,80003e80 <dirlink+0x4c>
    80003e58:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003e5a:	4741                	li	a4,16
    80003e5c:	86a6                	mv	a3,s1
    80003e5e:	fc040613          	addi	a2,s0,-64
    80003e62:	4581                	li	a1,0
    80003e64:	854a                	mv	a0,s2
    80003e66:	be3ff0ef          	jal	80003a48 <readi>
    80003e6a:	47c1                	li	a5,16
    80003e6c:	04f51b63          	bne	a0,a5,80003ec2 <dirlink+0x8e>
    if(de.inum == 0)
    80003e70:	fc045783          	lhu	a5,-64(s0)
    80003e74:	c791                	beqz	a5,80003e80 <dirlink+0x4c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003e76:	24c1                	addiw	s1,s1,16
    80003e78:	04c92783          	lw	a5,76(s2)
    80003e7c:	fcf4efe3          	bltu	s1,a5,80003e5a <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80003e80:	4639                	li	a2,14
    80003e82:	85d2                	mv	a1,s4
    80003e84:	fc240513          	addi	a0,s0,-62
    80003e88:	f5ffc0ef          	jal	80000de6 <strncpy>
  de.inum = inum;
    80003e8c:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003e90:	4741                	li	a4,16
    80003e92:	86a6                	mv	a3,s1
    80003e94:	fc040613          	addi	a2,s0,-64
    80003e98:	4581                	li	a1,0
    80003e9a:	854a                	mv	a0,s2
    80003e9c:	ca9ff0ef          	jal	80003b44 <writei>
    80003ea0:	1541                	addi	a0,a0,-16
    80003ea2:	00a03533          	snez	a0,a0
    80003ea6:	40a00533          	neg	a0,a0
    80003eaa:	74a2                	ld	s1,40(sp)
}
    80003eac:	70e2                	ld	ra,56(sp)
    80003eae:	7442                	ld	s0,48(sp)
    80003eb0:	7902                	ld	s2,32(sp)
    80003eb2:	69e2                	ld	s3,24(sp)
    80003eb4:	6a42                	ld	s4,16(sp)
    80003eb6:	6121                	addi	sp,sp,64
    80003eb8:	8082                	ret
    iput(ip);
    80003eba:	981ff0ef          	jal	8000383a <iput>
    return -1;
    80003ebe:	557d                	li	a0,-1
    80003ec0:	b7f5                	j	80003eac <dirlink+0x78>
      panic("dirlink read");
    80003ec2:	00003517          	auipc	a0,0x3
    80003ec6:	67650513          	addi	a0,a0,1654 # 80007538 <etext+0x538>
    80003eca:	917fc0ef          	jal	800007e0 <panic>

0000000080003ece <namei>:

struct inode*
namei(char *path)
{
    80003ece:	1101                	addi	sp,sp,-32
    80003ed0:	ec06                	sd	ra,24(sp)
    80003ed2:	e822                	sd	s0,16(sp)
    80003ed4:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003ed6:	fe040613          	addi	a2,s0,-32
    80003eda:	4581                	li	a1,0
    80003edc:	e29ff0ef          	jal	80003d04 <namex>
}
    80003ee0:	60e2                	ld	ra,24(sp)
    80003ee2:	6442                	ld	s0,16(sp)
    80003ee4:	6105                	addi	sp,sp,32
    80003ee6:	8082                	ret

0000000080003ee8 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003ee8:	1141                	addi	sp,sp,-16
    80003eea:	e406                	sd	ra,8(sp)
    80003eec:	e022                	sd	s0,0(sp)
    80003eee:	0800                	addi	s0,sp,16
    80003ef0:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003ef2:	4585                	li	a1,1
    80003ef4:	e11ff0ef          	jal	80003d04 <namex>
}
    80003ef8:	60a2                	ld	ra,8(sp)
    80003efa:	6402                	ld	s0,0(sp)
    80003efc:	0141                	addi	sp,sp,16
    80003efe:	8082                	ret

0000000080003f00 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003f00:	1101                	addi	sp,sp,-32
    80003f02:	ec06                	sd	ra,24(sp)
    80003f04:	e822                	sd	s0,16(sp)
    80003f06:	e426                	sd	s1,8(sp)
    80003f08:	e04a                	sd	s2,0(sp)
    80003f0a:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003f0c:	0001c917          	auipc	s2,0x1c
    80003f10:	aec90913          	addi	s2,s2,-1300 # 8001f9f8 <log>
    80003f14:	01892583          	lw	a1,24(s2)
    80003f18:	02492503          	lw	a0,36(s2)
    80003f1c:	8d0ff0ef          	jal	80002fec <bread>
    80003f20:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003f22:	02892603          	lw	a2,40(s2)
    80003f26:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003f28:	00c05f63          	blez	a2,80003f46 <write_head+0x46>
    80003f2c:	0001c717          	auipc	a4,0x1c
    80003f30:	af870713          	addi	a4,a4,-1288 # 8001fa24 <log+0x2c>
    80003f34:	87aa                	mv	a5,a0
    80003f36:	060a                	slli	a2,a2,0x2
    80003f38:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003f3a:	4314                	lw	a3,0(a4)
    80003f3c:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003f3e:	0711                	addi	a4,a4,4
    80003f40:	0791                	addi	a5,a5,4
    80003f42:	fec79ce3          	bne	a5,a2,80003f3a <write_head+0x3a>
  }
  bwrite(buf);
    80003f46:	8526                	mv	a0,s1
    80003f48:	97aff0ef          	jal	800030c2 <bwrite>
  brelse(buf);
    80003f4c:	8526                	mv	a0,s1
    80003f4e:	9a6ff0ef          	jal	800030f4 <brelse>
}
    80003f52:	60e2                	ld	ra,24(sp)
    80003f54:	6442                	ld	s0,16(sp)
    80003f56:	64a2                	ld	s1,8(sp)
    80003f58:	6902                	ld	s2,0(sp)
    80003f5a:	6105                	addi	sp,sp,32
    80003f5c:	8082                	ret

0000000080003f5e <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003f5e:	0001c797          	auipc	a5,0x1c
    80003f62:	ac27a783          	lw	a5,-1342(a5) # 8001fa20 <log+0x28>
    80003f66:	0af05e63          	blez	a5,80004022 <install_trans+0xc4>
{
    80003f6a:	715d                	addi	sp,sp,-80
    80003f6c:	e486                	sd	ra,72(sp)
    80003f6e:	e0a2                	sd	s0,64(sp)
    80003f70:	fc26                	sd	s1,56(sp)
    80003f72:	f84a                	sd	s2,48(sp)
    80003f74:	f44e                	sd	s3,40(sp)
    80003f76:	f052                	sd	s4,32(sp)
    80003f78:	ec56                	sd	s5,24(sp)
    80003f7a:	e85a                	sd	s6,16(sp)
    80003f7c:	e45e                	sd	s7,8(sp)
    80003f7e:	0880                	addi	s0,sp,80
    80003f80:	8b2a                	mv	s6,a0
    80003f82:	0001ca97          	auipc	s5,0x1c
    80003f86:	aa2a8a93          	addi	s5,s5,-1374 # 8001fa24 <log+0x2c>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003f8a:	4981                	li	s3,0
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003f8c:	00003b97          	auipc	s7,0x3
    80003f90:	5bcb8b93          	addi	s7,s7,1468 # 80007548 <etext+0x548>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003f94:	0001ca17          	auipc	s4,0x1c
    80003f98:	a64a0a13          	addi	s4,s4,-1436 # 8001f9f8 <log>
    80003f9c:	a025                	j	80003fc4 <install_trans+0x66>
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003f9e:	000aa603          	lw	a2,0(s5)
    80003fa2:	85ce                	mv	a1,s3
    80003fa4:	855e                	mv	a0,s7
    80003fa6:	d54fc0ef          	jal	800004fa <printf>
    80003faa:	a839                	j	80003fc8 <install_trans+0x6a>
    brelse(lbuf);
    80003fac:	854a                	mv	a0,s2
    80003fae:	946ff0ef          	jal	800030f4 <brelse>
    brelse(dbuf);
    80003fb2:	8526                	mv	a0,s1
    80003fb4:	940ff0ef          	jal	800030f4 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003fb8:	2985                	addiw	s3,s3,1
    80003fba:	0a91                	addi	s5,s5,4
    80003fbc:	028a2783          	lw	a5,40(s4)
    80003fc0:	04f9d663          	bge	s3,a5,8000400c <install_trans+0xae>
    if(recovering) {
    80003fc4:	fc0b1de3          	bnez	s6,80003f9e <install_trans+0x40>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003fc8:	018a2583          	lw	a1,24(s4)
    80003fcc:	013585bb          	addw	a1,a1,s3
    80003fd0:	2585                	addiw	a1,a1,1
    80003fd2:	024a2503          	lw	a0,36(s4)
    80003fd6:	816ff0ef          	jal	80002fec <bread>
    80003fda:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003fdc:	000aa583          	lw	a1,0(s5)
    80003fe0:	024a2503          	lw	a0,36(s4)
    80003fe4:	808ff0ef          	jal	80002fec <bread>
    80003fe8:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003fea:	40000613          	li	a2,1024
    80003fee:	05890593          	addi	a1,s2,88
    80003ff2:	05850513          	addi	a0,a0,88
    80003ff6:	d4bfc0ef          	jal	80000d40 <memmove>
    bwrite(dbuf);  // write dst to disk
    80003ffa:	8526                	mv	a0,s1
    80003ffc:	8c6ff0ef          	jal	800030c2 <bwrite>
    if(recovering == 0)
    80004000:	fa0b16e3          	bnez	s6,80003fac <install_trans+0x4e>
      bunpin(dbuf);
    80004004:	8526                	mv	a0,s1
    80004006:	9aaff0ef          	jal	800031b0 <bunpin>
    8000400a:	b74d                	j	80003fac <install_trans+0x4e>
}
    8000400c:	60a6                	ld	ra,72(sp)
    8000400e:	6406                	ld	s0,64(sp)
    80004010:	74e2                	ld	s1,56(sp)
    80004012:	7942                	ld	s2,48(sp)
    80004014:	79a2                	ld	s3,40(sp)
    80004016:	7a02                	ld	s4,32(sp)
    80004018:	6ae2                	ld	s5,24(sp)
    8000401a:	6b42                	ld	s6,16(sp)
    8000401c:	6ba2                	ld	s7,8(sp)
    8000401e:	6161                	addi	sp,sp,80
    80004020:	8082                	ret
    80004022:	8082                	ret

0000000080004024 <initlog>:
{
    80004024:	7179                	addi	sp,sp,-48
    80004026:	f406                	sd	ra,40(sp)
    80004028:	f022                	sd	s0,32(sp)
    8000402a:	ec26                	sd	s1,24(sp)
    8000402c:	e84a                	sd	s2,16(sp)
    8000402e:	e44e                	sd	s3,8(sp)
    80004030:	1800                	addi	s0,sp,48
    80004032:	892a                	mv	s2,a0
    80004034:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80004036:	0001c497          	auipc	s1,0x1c
    8000403a:	9c248493          	addi	s1,s1,-1598 # 8001f9f8 <log>
    8000403e:	00003597          	auipc	a1,0x3
    80004042:	52a58593          	addi	a1,a1,1322 # 80007568 <etext+0x568>
    80004046:	8526                	mv	a0,s1
    80004048:	b49fc0ef          	jal	80000b90 <initlock>
  log.start = sb->logstart;
    8000404c:	0149a583          	lw	a1,20(s3)
    80004050:	cc8c                	sw	a1,24(s1)
  log.dev = dev;
    80004052:	0324a223          	sw	s2,36(s1)
  struct buf *buf = bread(log.dev, log.start);
    80004056:	854a                	mv	a0,s2
    80004058:	f95fe0ef          	jal	80002fec <bread>
  log.lh.n = lh->n;
    8000405c:	4d30                	lw	a2,88(a0)
    8000405e:	d490                	sw	a2,40(s1)
  for (i = 0; i < log.lh.n; i++) {
    80004060:	00c05f63          	blez	a2,8000407e <initlog+0x5a>
    80004064:	87aa                	mv	a5,a0
    80004066:	0001c717          	auipc	a4,0x1c
    8000406a:	9be70713          	addi	a4,a4,-1602 # 8001fa24 <log+0x2c>
    8000406e:	060a                	slli	a2,a2,0x2
    80004070:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80004072:	4ff4                	lw	a3,92(a5)
    80004074:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80004076:	0791                	addi	a5,a5,4
    80004078:	0711                	addi	a4,a4,4
    8000407a:	fec79ce3          	bne	a5,a2,80004072 <initlog+0x4e>
  brelse(buf);
    8000407e:	876ff0ef          	jal	800030f4 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80004082:	4505                	li	a0,1
    80004084:	edbff0ef          	jal	80003f5e <install_trans>
  log.lh.n = 0;
    80004088:	0001c797          	auipc	a5,0x1c
    8000408c:	9807ac23          	sw	zero,-1640(a5) # 8001fa20 <log+0x28>
  write_head(); // clear the log
    80004090:	e71ff0ef          	jal	80003f00 <write_head>
}
    80004094:	70a2                	ld	ra,40(sp)
    80004096:	7402                	ld	s0,32(sp)
    80004098:	64e2                	ld	s1,24(sp)
    8000409a:	6942                	ld	s2,16(sp)
    8000409c:	69a2                	ld	s3,8(sp)
    8000409e:	6145                	addi	sp,sp,48
    800040a0:	8082                	ret

00000000800040a2 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    800040a2:	1101                	addi	sp,sp,-32
    800040a4:	ec06                	sd	ra,24(sp)
    800040a6:	e822                	sd	s0,16(sp)
    800040a8:	e426                	sd	s1,8(sp)
    800040aa:	e04a                	sd	s2,0(sp)
    800040ac:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    800040ae:	0001c517          	auipc	a0,0x1c
    800040b2:	94a50513          	addi	a0,a0,-1718 # 8001f9f8 <log>
    800040b6:	b5bfc0ef          	jal	80000c10 <acquire>
  while(1){
    if(log.committing){
    800040ba:	0001c497          	auipc	s1,0x1c
    800040be:	93e48493          	addi	s1,s1,-1730 # 8001f9f8 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    800040c2:	4979                	li	s2,30
    800040c4:	a029                	j	800040ce <begin_op+0x2c>
      sleep(&log, &log.lock);
    800040c6:	85a6                	mv	a1,s1
    800040c8:	8526                	mv	a0,s1
    800040ca:	e55fd0ef          	jal	80001f1e <sleep>
    if(log.committing){
    800040ce:	509c                	lw	a5,32(s1)
    800040d0:	fbfd                	bnez	a5,800040c6 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    800040d2:	4cd8                	lw	a4,28(s1)
    800040d4:	2705                	addiw	a4,a4,1
    800040d6:	0027179b          	slliw	a5,a4,0x2
    800040da:	9fb9                	addw	a5,a5,a4
    800040dc:	0017979b          	slliw	a5,a5,0x1
    800040e0:	5494                	lw	a3,40(s1)
    800040e2:	9fb5                	addw	a5,a5,a3
    800040e4:	00f95763          	bge	s2,a5,800040f2 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    800040e8:	85a6                	mv	a1,s1
    800040ea:	8526                	mv	a0,s1
    800040ec:	e33fd0ef          	jal	80001f1e <sleep>
    800040f0:	bff9                	j	800040ce <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    800040f2:	0001c517          	auipc	a0,0x1c
    800040f6:	90650513          	addi	a0,a0,-1786 # 8001f9f8 <log>
    800040fa:	cd58                	sw	a4,28(a0)
      release(&log.lock);
    800040fc:	badfc0ef          	jal	80000ca8 <release>
      break;
    }
  }
}
    80004100:	60e2                	ld	ra,24(sp)
    80004102:	6442                	ld	s0,16(sp)
    80004104:	64a2                	ld	s1,8(sp)
    80004106:	6902                	ld	s2,0(sp)
    80004108:	6105                	addi	sp,sp,32
    8000410a:	8082                	ret

000000008000410c <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    8000410c:	7139                	addi	sp,sp,-64
    8000410e:	fc06                	sd	ra,56(sp)
    80004110:	f822                	sd	s0,48(sp)
    80004112:	f426                	sd	s1,40(sp)
    80004114:	f04a                	sd	s2,32(sp)
    80004116:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80004118:	0001c497          	auipc	s1,0x1c
    8000411c:	8e048493          	addi	s1,s1,-1824 # 8001f9f8 <log>
    80004120:	8526                	mv	a0,s1
    80004122:	aeffc0ef          	jal	80000c10 <acquire>
  log.outstanding -= 1;
    80004126:	4cdc                	lw	a5,28(s1)
    80004128:	37fd                	addiw	a5,a5,-1
    8000412a:	0007891b          	sext.w	s2,a5
    8000412e:	ccdc                	sw	a5,28(s1)
  if(log.committing)
    80004130:	509c                	lw	a5,32(s1)
    80004132:	ef9d                	bnez	a5,80004170 <end_op+0x64>
    panic("log.committing");
  if(log.outstanding == 0){
    80004134:	04091763          	bnez	s2,80004182 <end_op+0x76>
    do_commit = 1;
    log.committing = 1;
    80004138:	0001c497          	auipc	s1,0x1c
    8000413c:	8c048493          	addi	s1,s1,-1856 # 8001f9f8 <log>
    80004140:	4785                	li	a5,1
    80004142:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80004144:	8526                	mv	a0,s1
    80004146:	b63fc0ef          	jal	80000ca8 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    8000414a:	549c                	lw	a5,40(s1)
    8000414c:	04f04b63          	bgtz	a5,800041a2 <end_op+0x96>
    acquire(&log.lock);
    80004150:	0001c497          	auipc	s1,0x1c
    80004154:	8a848493          	addi	s1,s1,-1880 # 8001f9f8 <log>
    80004158:	8526                	mv	a0,s1
    8000415a:	ab7fc0ef          	jal	80000c10 <acquire>
    log.committing = 0;
    8000415e:	0204a023          	sw	zero,32(s1)
    wakeup(&log);
    80004162:	8526                	mv	a0,s1
    80004164:	e07fd0ef          	jal	80001f6a <wakeup>
    release(&log.lock);
    80004168:	8526                	mv	a0,s1
    8000416a:	b3ffc0ef          	jal	80000ca8 <release>
}
    8000416e:	a025                	j	80004196 <end_op+0x8a>
    80004170:	ec4e                	sd	s3,24(sp)
    80004172:	e852                	sd	s4,16(sp)
    80004174:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80004176:	00003517          	auipc	a0,0x3
    8000417a:	3fa50513          	addi	a0,a0,1018 # 80007570 <etext+0x570>
    8000417e:	e62fc0ef          	jal	800007e0 <panic>
    wakeup(&log);
    80004182:	0001c497          	auipc	s1,0x1c
    80004186:	87648493          	addi	s1,s1,-1930 # 8001f9f8 <log>
    8000418a:	8526                	mv	a0,s1
    8000418c:	ddffd0ef          	jal	80001f6a <wakeup>
  release(&log.lock);
    80004190:	8526                	mv	a0,s1
    80004192:	b17fc0ef          	jal	80000ca8 <release>
}
    80004196:	70e2                	ld	ra,56(sp)
    80004198:	7442                	ld	s0,48(sp)
    8000419a:	74a2                	ld	s1,40(sp)
    8000419c:	7902                	ld	s2,32(sp)
    8000419e:	6121                	addi	sp,sp,64
    800041a0:	8082                	ret
    800041a2:	ec4e                	sd	s3,24(sp)
    800041a4:	e852                	sd	s4,16(sp)
    800041a6:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    800041a8:	0001ca97          	auipc	s5,0x1c
    800041ac:	87ca8a93          	addi	s5,s5,-1924 # 8001fa24 <log+0x2c>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    800041b0:	0001ca17          	auipc	s4,0x1c
    800041b4:	848a0a13          	addi	s4,s4,-1976 # 8001f9f8 <log>
    800041b8:	018a2583          	lw	a1,24(s4)
    800041bc:	012585bb          	addw	a1,a1,s2
    800041c0:	2585                	addiw	a1,a1,1
    800041c2:	024a2503          	lw	a0,36(s4)
    800041c6:	e27fe0ef          	jal	80002fec <bread>
    800041ca:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    800041cc:	000aa583          	lw	a1,0(s5)
    800041d0:	024a2503          	lw	a0,36(s4)
    800041d4:	e19fe0ef          	jal	80002fec <bread>
    800041d8:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    800041da:	40000613          	li	a2,1024
    800041de:	05850593          	addi	a1,a0,88
    800041e2:	05848513          	addi	a0,s1,88
    800041e6:	b5bfc0ef          	jal	80000d40 <memmove>
    bwrite(to);  // write the log
    800041ea:	8526                	mv	a0,s1
    800041ec:	ed7fe0ef          	jal	800030c2 <bwrite>
    brelse(from);
    800041f0:	854e                	mv	a0,s3
    800041f2:	f03fe0ef          	jal	800030f4 <brelse>
    brelse(to);
    800041f6:	8526                	mv	a0,s1
    800041f8:	efdfe0ef          	jal	800030f4 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800041fc:	2905                	addiw	s2,s2,1
    800041fe:	0a91                	addi	s5,s5,4
    80004200:	028a2783          	lw	a5,40(s4)
    80004204:	faf94ae3          	blt	s2,a5,800041b8 <end_op+0xac>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80004208:	cf9ff0ef          	jal	80003f00 <write_head>
    install_trans(0); // Now install writes to home locations
    8000420c:	4501                	li	a0,0
    8000420e:	d51ff0ef          	jal	80003f5e <install_trans>
    log.lh.n = 0;
    80004212:	0001c797          	auipc	a5,0x1c
    80004216:	8007a723          	sw	zero,-2034(a5) # 8001fa20 <log+0x28>
    write_head();    // Erase the transaction from the log
    8000421a:	ce7ff0ef          	jal	80003f00 <write_head>
    8000421e:	69e2                	ld	s3,24(sp)
    80004220:	6a42                	ld	s4,16(sp)
    80004222:	6aa2                	ld	s5,8(sp)
    80004224:	b735                	j	80004150 <end_op+0x44>

0000000080004226 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80004226:	1101                	addi	sp,sp,-32
    80004228:	ec06                	sd	ra,24(sp)
    8000422a:	e822                	sd	s0,16(sp)
    8000422c:	e426                	sd	s1,8(sp)
    8000422e:	e04a                	sd	s2,0(sp)
    80004230:	1000                	addi	s0,sp,32
    80004232:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80004234:	0001b917          	auipc	s2,0x1b
    80004238:	7c490913          	addi	s2,s2,1988 # 8001f9f8 <log>
    8000423c:	854a                	mv	a0,s2
    8000423e:	9d3fc0ef          	jal	80000c10 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80004242:	02892603          	lw	a2,40(s2)
    80004246:	47f5                	li	a5,29
    80004248:	04c7cc63          	blt	a5,a2,800042a0 <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    8000424c:	0001b797          	auipc	a5,0x1b
    80004250:	7c87a783          	lw	a5,1992(a5) # 8001fa14 <log+0x1c>
    80004254:	04f05c63          	blez	a5,800042ac <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80004258:	4781                	li	a5,0
    8000425a:	04c05f63          	blez	a2,800042b8 <log_write+0x92>
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000425e:	44cc                	lw	a1,12(s1)
    80004260:	0001b717          	auipc	a4,0x1b
    80004264:	7c470713          	addi	a4,a4,1988 # 8001fa24 <log+0x2c>
  for (i = 0; i < log.lh.n; i++) {
    80004268:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000426a:	4314                	lw	a3,0(a4)
    8000426c:	04b68663          	beq	a3,a1,800042b8 <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    80004270:	2785                	addiw	a5,a5,1
    80004272:	0711                	addi	a4,a4,4
    80004274:	fef61be3          	bne	a2,a5,8000426a <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80004278:	0621                	addi	a2,a2,8
    8000427a:	060a                	slli	a2,a2,0x2
    8000427c:	0001b797          	auipc	a5,0x1b
    80004280:	77c78793          	addi	a5,a5,1916 # 8001f9f8 <log>
    80004284:	97b2                	add	a5,a5,a2
    80004286:	44d8                	lw	a4,12(s1)
    80004288:	c7d8                	sw	a4,12(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    8000428a:	8526                	mv	a0,s1
    8000428c:	ef1fe0ef          	jal	8000317c <bpin>
    log.lh.n++;
    80004290:	0001b717          	auipc	a4,0x1b
    80004294:	76870713          	addi	a4,a4,1896 # 8001f9f8 <log>
    80004298:	571c                	lw	a5,40(a4)
    8000429a:	2785                	addiw	a5,a5,1
    8000429c:	d71c                	sw	a5,40(a4)
    8000429e:	a80d                	j	800042d0 <log_write+0xaa>
    panic("too big a transaction");
    800042a0:	00003517          	auipc	a0,0x3
    800042a4:	2e050513          	addi	a0,a0,736 # 80007580 <etext+0x580>
    800042a8:	d38fc0ef          	jal	800007e0 <panic>
    panic("log_write outside of trans");
    800042ac:	00003517          	auipc	a0,0x3
    800042b0:	2ec50513          	addi	a0,a0,748 # 80007598 <etext+0x598>
    800042b4:	d2cfc0ef          	jal	800007e0 <panic>
  log.lh.block[i] = b->blockno;
    800042b8:	00878693          	addi	a3,a5,8
    800042bc:	068a                	slli	a3,a3,0x2
    800042be:	0001b717          	auipc	a4,0x1b
    800042c2:	73a70713          	addi	a4,a4,1850 # 8001f9f8 <log>
    800042c6:	9736                	add	a4,a4,a3
    800042c8:	44d4                	lw	a3,12(s1)
    800042ca:	c754                	sw	a3,12(a4)
  if (i == log.lh.n) {  // Add new block to log?
    800042cc:	faf60fe3          	beq	a2,a5,8000428a <log_write+0x64>
  }
  release(&log.lock);
    800042d0:	0001b517          	auipc	a0,0x1b
    800042d4:	72850513          	addi	a0,a0,1832 # 8001f9f8 <log>
    800042d8:	9d1fc0ef          	jal	80000ca8 <release>
}
    800042dc:	60e2                	ld	ra,24(sp)
    800042de:	6442                	ld	s0,16(sp)
    800042e0:	64a2                	ld	s1,8(sp)
    800042e2:	6902                	ld	s2,0(sp)
    800042e4:	6105                	addi	sp,sp,32
    800042e6:	8082                	ret

00000000800042e8 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800042e8:	1101                	addi	sp,sp,-32
    800042ea:	ec06                	sd	ra,24(sp)
    800042ec:	e822                	sd	s0,16(sp)
    800042ee:	e426                	sd	s1,8(sp)
    800042f0:	e04a                	sd	s2,0(sp)
    800042f2:	1000                	addi	s0,sp,32
    800042f4:	84aa                	mv	s1,a0
    800042f6:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800042f8:	00003597          	auipc	a1,0x3
    800042fc:	2c058593          	addi	a1,a1,704 # 800075b8 <etext+0x5b8>
    80004300:	0521                	addi	a0,a0,8
    80004302:	88ffc0ef          	jal	80000b90 <initlock>
  lk->name = name;
    80004306:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    8000430a:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000430e:	0204a423          	sw	zero,40(s1)
}
    80004312:	60e2                	ld	ra,24(sp)
    80004314:	6442                	ld	s0,16(sp)
    80004316:	64a2                	ld	s1,8(sp)
    80004318:	6902                	ld	s2,0(sp)
    8000431a:	6105                	addi	sp,sp,32
    8000431c:	8082                	ret

000000008000431e <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    8000431e:	1101                	addi	sp,sp,-32
    80004320:	ec06                	sd	ra,24(sp)
    80004322:	e822                	sd	s0,16(sp)
    80004324:	e426                	sd	s1,8(sp)
    80004326:	e04a                	sd	s2,0(sp)
    80004328:	1000                	addi	s0,sp,32
    8000432a:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000432c:	00850913          	addi	s2,a0,8
    80004330:	854a                	mv	a0,s2
    80004332:	8dffc0ef          	jal	80000c10 <acquire>
  while (lk->locked) {
    80004336:	409c                	lw	a5,0(s1)
    80004338:	c799                	beqz	a5,80004346 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    8000433a:	85ca                	mv	a1,s2
    8000433c:	8526                	mv	a0,s1
    8000433e:	be1fd0ef          	jal	80001f1e <sleep>
  while (lk->locked) {
    80004342:	409c                	lw	a5,0(s1)
    80004344:	fbfd                	bnez	a5,8000433a <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80004346:	4785                	li	a5,1
    80004348:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    8000434a:	dc6fd0ef          	jal	80001910 <myproc>
    8000434e:	591c                	lw	a5,48(a0)
    80004350:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80004352:	854a                	mv	a0,s2
    80004354:	955fc0ef          	jal	80000ca8 <release>
}
    80004358:	60e2                	ld	ra,24(sp)
    8000435a:	6442                	ld	s0,16(sp)
    8000435c:	64a2                	ld	s1,8(sp)
    8000435e:	6902                	ld	s2,0(sp)
    80004360:	6105                	addi	sp,sp,32
    80004362:	8082                	ret

0000000080004364 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80004364:	1101                	addi	sp,sp,-32
    80004366:	ec06                	sd	ra,24(sp)
    80004368:	e822                	sd	s0,16(sp)
    8000436a:	e426                	sd	s1,8(sp)
    8000436c:	e04a                	sd	s2,0(sp)
    8000436e:	1000                	addi	s0,sp,32
    80004370:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004372:	00850913          	addi	s2,a0,8
    80004376:	854a                	mv	a0,s2
    80004378:	899fc0ef          	jal	80000c10 <acquire>
  lk->locked = 0;
    8000437c:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004380:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80004384:	8526                	mv	a0,s1
    80004386:	be5fd0ef          	jal	80001f6a <wakeup>
  release(&lk->lk);
    8000438a:	854a                	mv	a0,s2
    8000438c:	91dfc0ef          	jal	80000ca8 <release>
}
    80004390:	60e2                	ld	ra,24(sp)
    80004392:	6442                	ld	s0,16(sp)
    80004394:	64a2                	ld	s1,8(sp)
    80004396:	6902                	ld	s2,0(sp)
    80004398:	6105                	addi	sp,sp,32
    8000439a:	8082                	ret

000000008000439c <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000439c:	7179                	addi	sp,sp,-48
    8000439e:	f406                	sd	ra,40(sp)
    800043a0:	f022                	sd	s0,32(sp)
    800043a2:	ec26                	sd	s1,24(sp)
    800043a4:	e84a                	sd	s2,16(sp)
    800043a6:	1800                	addi	s0,sp,48
    800043a8:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    800043aa:	00850913          	addi	s2,a0,8
    800043ae:	854a                	mv	a0,s2
    800043b0:	861fc0ef          	jal	80000c10 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800043b4:	409c                	lw	a5,0(s1)
    800043b6:	ef81                	bnez	a5,800043ce <holdingsleep+0x32>
    800043b8:	4481                	li	s1,0
  release(&lk->lk);
    800043ba:	854a                	mv	a0,s2
    800043bc:	8edfc0ef          	jal	80000ca8 <release>
  return r;
}
    800043c0:	8526                	mv	a0,s1
    800043c2:	70a2                	ld	ra,40(sp)
    800043c4:	7402                	ld	s0,32(sp)
    800043c6:	64e2                	ld	s1,24(sp)
    800043c8:	6942                	ld	s2,16(sp)
    800043ca:	6145                	addi	sp,sp,48
    800043cc:	8082                	ret
    800043ce:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    800043d0:	0284a983          	lw	s3,40(s1)
    800043d4:	d3cfd0ef          	jal	80001910 <myproc>
    800043d8:	5904                	lw	s1,48(a0)
    800043da:	413484b3          	sub	s1,s1,s3
    800043de:	0014b493          	seqz	s1,s1
    800043e2:	69a2                	ld	s3,8(sp)
    800043e4:	bfd9                	j	800043ba <holdingsleep+0x1e>

00000000800043e6 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800043e6:	1141                	addi	sp,sp,-16
    800043e8:	e406                	sd	ra,8(sp)
    800043ea:	e022                	sd	s0,0(sp)
    800043ec:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800043ee:	00003597          	auipc	a1,0x3
    800043f2:	1da58593          	addi	a1,a1,474 # 800075c8 <etext+0x5c8>
    800043f6:	0001b517          	auipc	a0,0x1b
    800043fa:	74a50513          	addi	a0,a0,1866 # 8001fb40 <ftable>
    800043fe:	f92fc0ef          	jal	80000b90 <initlock>
}
    80004402:	60a2                	ld	ra,8(sp)
    80004404:	6402                	ld	s0,0(sp)
    80004406:	0141                	addi	sp,sp,16
    80004408:	8082                	ret

000000008000440a <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    8000440a:	1101                	addi	sp,sp,-32
    8000440c:	ec06                	sd	ra,24(sp)
    8000440e:	e822                	sd	s0,16(sp)
    80004410:	e426                	sd	s1,8(sp)
    80004412:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004414:	0001b517          	auipc	a0,0x1b
    80004418:	72c50513          	addi	a0,a0,1836 # 8001fb40 <ftable>
    8000441c:	ff4fc0ef          	jal	80000c10 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004420:	0001b497          	auipc	s1,0x1b
    80004424:	73848493          	addi	s1,s1,1848 # 8001fb58 <ftable+0x18>
    80004428:	0001c717          	auipc	a4,0x1c
    8000442c:	6d070713          	addi	a4,a4,1744 # 80020af8 <disk>
    if(f->ref == 0){
    80004430:	40dc                	lw	a5,4(s1)
    80004432:	cf89                	beqz	a5,8000444c <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004434:	02848493          	addi	s1,s1,40
    80004438:	fee49ce3          	bne	s1,a4,80004430 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    8000443c:	0001b517          	auipc	a0,0x1b
    80004440:	70450513          	addi	a0,a0,1796 # 8001fb40 <ftable>
    80004444:	865fc0ef          	jal	80000ca8 <release>
  return 0;
    80004448:	4481                	li	s1,0
    8000444a:	a809                	j	8000445c <filealloc+0x52>
      f->ref = 1;
    8000444c:	4785                	li	a5,1
    8000444e:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004450:	0001b517          	auipc	a0,0x1b
    80004454:	6f050513          	addi	a0,a0,1776 # 8001fb40 <ftable>
    80004458:	851fc0ef          	jal	80000ca8 <release>
}
    8000445c:	8526                	mv	a0,s1
    8000445e:	60e2                	ld	ra,24(sp)
    80004460:	6442                	ld	s0,16(sp)
    80004462:	64a2                	ld	s1,8(sp)
    80004464:	6105                	addi	sp,sp,32
    80004466:	8082                	ret

0000000080004468 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80004468:	1101                	addi	sp,sp,-32
    8000446a:	ec06                	sd	ra,24(sp)
    8000446c:	e822                	sd	s0,16(sp)
    8000446e:	e426                	sd	s1,8(sp)
    80004470:	1000                	addi	s0,sp,32
    80004472:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80004474:	0001b517          	auipc	a0,0x1b
    80004478:	6cc50513          	addi	a0,a0,1740 # 8001fb40 <ftable>
    8000447c:	f94fc0ef          	jal	80000c10 <acquire>
  if(f->ref < 1)
    80004480:	40dc                	lw	a5,4(s1)
    80004482:	02f05063          	blez	a5,800044a2 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80004486:	2785                	addiw	a5,a5,1
    80004488:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000448a:	0001b517          	auipc	a0,0x1b
    8000448e:	6b650513          	addi	a0,a0,1718 # 8001fb40 <ftable>
    80004492:	817fc0ef          	jal	80000ca8 <release>
  return f;
}
    80004496:	8526                	mv	a0,s1
    80004498:	60e2                	ld	ra,24(sp)
    8000449a:	6442                	ld	s0,16(sp)
    8000449c:	64a2                	ld	s1,8(sp)
    8000449e:	6105                	addi	sp,sp,32
    800044a0:	8082                	ret
    panic("filedup");
    800044a2:	00003517          	auipc	a0,0x3
    800044a6:	12e50513          	addi	a0,a0,302 # 800075d0 <etext+0x5d0>
    800044aa:	b36fc0ef          	jal	800007e0 <panic>

00000000800044ae <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800044ae:	7139                	addi	sp,sp,-64
    800044b0:	fc06                	sd	ra,56(sp)
    800044b2:	f822                	sd	s0,48(sp)
    800044b4:	f426                	sd	s1,40(sp)
    800044b6:	0080                	addi	s0,sp,64
    800044b8:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800044ba:	0001b517          	auipc	a0,0x1b
    800044be:	68650513          	addi	a0,a0,1670 # 8001fb40 <ftable>
    800044c2:	f4efc0ef          	jal	80000c10 <acquire>
  if(f->ref < 1)
    800044c6:	40dc                	lw	a5,4(s1)
    800044c8:	04f05a63          	blez	a5,8000451c <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    800044cc:	37fd                	addiw	a5,a5,-1
    800044ce:	0007871b          	sext.w	a4,a5
    800044d2:	c0dc                	sw	a5,4(s1)
    800044d4:	04e04e63          	bgtz	a4,80004530 <fileclose+0x82>
    800044d8:	f04a                	sd	s2,32(sp)
    800044da:	ec4e                	sd	s3,24(sp)
    800044dc:	e852                	sd	s4,16(sp)
    800044de:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800044e0:	0004a903          	lw	s2,0(s1)
    800044e4:	0094ca83          	lbu	s5,9(s1)
    800044e8:	0104ba03          	ld	s4,16(s1)
    800044ec:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    800044f0:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800044f4:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800044f8:	0001b517          	auipc	a0,0x1b
    800044fc:	64850513          	addi	a0,a0,1608 # 8001fb40 <ftable>
    80004500:	fa8fc0ef          	jal	80000ca8 <release>

  if(ff.type == FD_PIPE){
    80004504:	4785                	li	a5,1
    80004506:	04f90063          	beq	s2,a5,80004546 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    8000450a:	3979                	addiw	s2,s2,-2
    8000450c:	4785                	li	a5,1
    8000450e:	0527f563          	bgeu	a5,s2,80004558 <fileclose+0xaa>
    80004512:	7902                	ld	s2,32(sp)
    80004514:	69e2                	ld	s3,24(sp)
    80004516:	6a42                	ld	s4,16(sp)
    80004518:	6aa2                	ld	s5,8(sp)
    8000451a:	a00d                	j	8000453c <fileclose+0x8e>
    8000451c:	f04a                	sd	s2,32(sp)
    8000451e:	ec4e                	sd	s3,24(sp)
    80004520:	e852                	sd	s4,16(sp)
    80004522:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80004524:	00003517          	auipc	a0,0x3
    80004528:	0b450513          	addi	a0,a0,180 # 800075d8 <etext+0x5d8>
    8000452c:	ab4fc0ef          	jal	800007e0 <panic>
    release(&ftable.lock);
    80004530:	0001b517          	auipc	a0,0x1b
    80004534:	61050513          	addi	a0,a0,1552 # 8001fb40 <ftable>
    80004538:	f70fc0ef          	jal	80000ca8 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    8000453c:	70e2                	ld	ra,56(sp)
    8000453e:	7442                	ld	s0,48(sp)
    80004540:	74a2                	ld	s1,40(sp)
    80004542:	6121                	addi	sp,sp,64
    80004544:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004546:	85d6                	mv	a1,s5
    80004548:	8552                	mv	a0,s4
    8000454a:	336000ef          	jal	80004880 <pipeclose>
    8000454e:	7902                	ld	s2,32(sp)
    80004550:	69e2                	ld	s3,24(sp)
    80004552:	6a42                	ld	s4,16(sp)
    80004554:	6aa2                	ld	s5,8(sp)
    80004556:	b7dd                	j	8000453c <fileclose+0x8e>
    begin_op();
    80004558:	b4bff0ef          	jal	800040a2 <begin_op>
    iput(ff.ip);
    8000455c:	854e                	mv	a0,s3
    8000455e:	adcff0ef          	jal	8000383a <iput>
    end_op();
    80004562:	babff0ef          	jal	8000410c <end_op>
    80004566:	7902                	ld	s2,32(sp)
    80004568:	69e2                	ld	s3,24(sp)
    8000456a:	6a42                	ld	s4,16(sp)
    8000456c:	6aa2                	ld	s5,8(sp)
    8000456e:	b7f9                	j	8000453c <fileclose+0x8e>

0000000080004570 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80004570:	715d                	addi	sp,sp,-80
    80004572:	e486                	sd	ra,72(sp)
    80004574:	e0a2                	sd	s0,64(sp)
    80004576:	fc26                	sd	s1,56(sp)
    80004578:	f44e                	sd	s3,40(sp)
    8000457a:	0880                	addi	s0,sp,80
    8000457c:	84aa                	mv	s1,a0
    8000457e:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    80004580:	b90fd0ef          	jal	80001910 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80004584:	409c                	lw	a5,0(s1)
    80004586:	37f9                	addiw	a5,a5,-2
    80004588:	4705                	li	a4,1
    8000458a:	04f76063          	bltu	a4,a5,800045ca <filestat+0x5a>
    8000458e:	f84a                	sd	s2,48(sp)
    80004590:	892a                	mv	s2,a0
    ilock(f->ip);
    80004592:	6c88                	ld	a0,24(s1)
    80004594:	924ff0ef          	jal	800036b8 <ilock>
    stati(f->ip, &st);
    80004598:	fb840593          	addi	a1,s0,-72
    8000459c:	6c88                	ld	a0,24(s1)
    8000459e:	c80ff0ef          	jal	80003a1e <stati>
    iunlock(f->ip);
    800045a2:	6c88                	ld	a0,24(s1)
    800045a4:	9c2ff0ef          	jal	80003766 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800045a8:	46e1                	li	a3,24
    800045aa:	fb840613          	addi	a2,s0,-72
    800045ae:	85ce                	mv	a1,s3
    800045b0:	05093503          	ld	a0,80(s2)
    800045b4:	870fd0ef          	jal	80001624 <copyout>
    800045b8:	41f5551b          	sraiw	a0,a0,0x1f
    800045bc:	7942                	ld	s2,48(sp)
      return -1;
    return 0;
  }
  return -1;
}
    800045be:	60a6                	ld	ra,72(sp)
    800045c0:	6406                	ld	s0,64(sp)
    800045c2:	74e2                	ld	s1,56(sp)
    800045c4:	79a2                	ld	s3,40(sp)
    800045c6:	6161                	addi	sp,sp,80
    800045c8:	8082                	ret
  return -1;
    800045ca:	557d                	li	a0,-1
    800045cc:	bfcd                	j	800045be <filestat+0x4e>

00000000800045ce <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800045ce:	7179                	addi	sp,sp,-48
    800045d0:	f406                	sd	ra,40(sp)
    800045d2:	f022                	sd	s0,32(sp)
    800045d4:	e84a                	sd	s2,16(sp)
    800045d6:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    800045d8:	00854783          	lbu	a5,8(a0)
    800045dc:	cfd1                	beqz	a5,80004678 <fileread+0xaa>
    800045de:	ec26                	sd	s1,24(sp)
    800045e0:	e44e                	sd	s3,8(sp)
    800045e2:	84aa                	mv	s1,a0
    800045e4:	89ae                	mv	s3,a1
    800045e6:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    800045e8:	411c                	lw	a5,0(a0)
    800045ea:	4705                	li	a4,1
    800045ec:	04e78363          	beq	a5,a4,80004632 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800045f0:	470d                	li	a4,3
    800045f2:	04e78763          	beq	a5,a4,80004640 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    800045f6:	4709                	li	a4,2
    800045f8:	06e79a63          	bne	a5,a4,8000466c <fileread+0x9e>
    ilock(f->ip);
    800045fc:	6d08                	ld	a0,24(a0)
    800045fe:	8baff0ef          	jal	800036b8 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004602:	874a                	mv	a4,s2
    80004604:	5094                	lw	a3,32(s1)
    80004606:	864e                	mv	a2,s3
    80004608:	4585                	li	a1,1
    8000460a:	6c88                	ld	a0,24(s1)
    8000460c:	c3cff0ef          	jal	80003a48 <readi>
    80004610:	892a                	mv	s2,a0
    80004612:	00a05563          	blez	a0,8000461c <fileread+0x4e>
      f->off += r;
    80004616:	509c                	lw	a5,32(s1)
    80004618:	9fa9                	addw	a5,a5,a0
    8000461a:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    8000461c:	6c88                	ld	a0,24(s1)
    8000461e:	948ff0ef          	jal	80003766 <iunlock>
    80004622:	64e2                	ld	s1,24(sp)
    80004624:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80004626:	854a                	mv	a0,s2
    80004628:	70a2                	ld	ra,40(sp)
    8000462a:	7402                	ld	s0,32(sp)
    8000462c:	6942                	ld	s2,16(sp)
    8000462e:	6145                	addi	sp,sp,48
    80004630:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004632:	6908                	ld	a0,16(a0)
    80004634:	388000ef          	jal	800049bc <piperead>
    80004638:	892a                	mv	s2,a0
    8000463a:	64e2                	ld	s1,24(sp)
    8000463c:	69a2                	ld	s3,8(sp)
    8000463e:	b7e5                	j	80004626 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004640:	02451783          	lh	a5,36(a0)
    80004644:	03079693          	slli	a3,a5,0x30
    80004648:	92c1                	srli	a3,a3,0x30
    8000464a:	4725                	li	a4,9
    8000464c:	02d76863          	bltu	a4,a3,8000467c <fileread+0xae>
    80004650:	0792                	slli	a5,a5,0x4
    80004652:	0001b717          	auipc	a4,0x1b
    80004656:	44e70713          	addi	a4,a4,1102 # 8001faa0 <devsw>
    8000465a:	97ba                	add	a5,a5,a4
    8000465c:	639c                	ld	a5,0(a5)
    8000465e:	c39d                	beqz	a5,80004684 <fileread+0xb6>
    r = devsw[f->major].read(1, addr, n);
    80004660:	4505                	li	a0,1
    80004662:	9782                	jalr	a5
    80004664:	892a                	mv	s2,a0
    80004666:	64e2                	ld	s1,24(sp)
    80004668:	69a2                	ld	s3,8(sp)
    8000466a:	bf75                	j	80004626 <fileread+0x58>
    panic("fileread");
    8000466c:	00003517          	auipc	a0,0x3
    80004670:	f7c50513          	addi	a0,a0,-132 # 800075e8 <etext+0x5e8>
    80004674:	96cfc0ef          	jal	800007e0 <panic>
    return -1;
    80004678:	597d                	li	s2,-1
    8000467a:	b775                	j	80004626 <fileread+0x58>
      return -1;
    8000467c:	597d                	li	s2,-1
    8000467e:	64e2                	ld	s1,24(sp)
    80004680:	69a2                	ld	s3,8(sp)
    80004682:	b755                	j	80004626 <fileread+0x58>
    80004684:	597d                	li	s2,-1
    80004686:	64e2                	ld	s1,24(sp)
    80004688:	69a2                	ld	s3,8(sp)
    8000468a:	bf71                	j	80004626 <fileread+0x58>

000000008000468c <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    8000468c:	00954783          	lbu	a5,9(a0)
    80004690:	10078b63          	beqz	a5,800047a6 <filewrite+0x11a>
{
    80004694:	715d                	addi	sp,sp,-80
    80004696:	e486                	sd	ra,72(sp)
    80004698:	e0a2                	sd	s0,64(sp)
    8000469a:	f84a                	sd	s2,48(sp)
    8000469c:	f052                	sd	s4,32(sp)
    8000469e:	e85a                	sd	s6,16(sp)
    800046a0:	0880                	addi	s0,sp,80
    800046a2:	892a                	mv	s2,a0
    800046a4:	8b2e                	mv	s6,a1
    800046a6:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    800046a8:	411c                	lw	a5,0(a0)
    800046aa:	4705                	li	a4,1
    800046ac:	02e78763          	beq	a5,a4,800046da <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800046b0:	470d                	li	a4,3
    800046b2:	02e78863          	beq	a5,a4,800046e2 <filewrite+0x56>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800046b6:	4709                	li	a4,2
    800046b8:	0ce79c63          	bne	a5,a4,80004790 <filewrite+0x104>
    800046bc:	f44e                	sd	s3,40(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800046be:	0ac05863          	blez	a2,8000476e <filewrite+0xe2>
    800046c2:	fc26                	sd	s1,56(sp)
    800046c4:	ec56                	sd	s5,24(sp)
    800046c6:	e45e                	sd	s7,8(sp)
    800046c8:	e062                	sd	s8,0(sp)
    int i = 0;
    800046ca:	4981                	li	s3,0
      int n1 = n - i;
      if(n1 > max)
    800046cc:	6b85                	lui	s7,0x1
    800046ce:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800046d2:	6c05                	lui	s8,0x1
    800046d4:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    800046d8:	a8b5                	j	80004754 <filewrite+0xc8>
    ret = pipewrite(f->pipe, addr, n);
    800046da:	6908                	ld	a0,16(a0)
    800046dc:	1fc000ef          	jal	800048d8 <pipewrite>
    800046e0:	a04d                	j	80004782 <filewrite+0xf6>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800046e2:	02451783          	lh	a5,36(a0)
    800046e6:	03079693          	slli	a3,a5,0x30
    800046ea:	92c1                	srli	a3,a3,0x30
    800046ec:	4725                	li	a4,9
    800046ee:	0ad76e63          	bltu	a4,a3,800047aa <filewrite+0x11e>
    800046f2:	0792                	slli	a5,a5,0x4
    800046f4:	0001b717          	auipc	a4,0x1b
    800046f8:	3ac70713          	addi	a4,a4,940 # 8001faa0 <devsw>
    800046fc:	97ba                	add	a5,a5,a4
    800046fe:	679c                	ld	a5,8(a5)
    80004700:	c7dd                	beqz	a5,800047ae <filewrite+0x122>
    ret = devsw[f->major].write(1, addr, n);
    80004702:	4505                	li	a0,1
    80004704:	9782                	jalr	a5
    80004706:	a8b5                	j	80004782 <filewrite+0xf6>
      if(n1 > max)
    80004708:	00048a9b          	sext.w	s5,s1
        n1 = max;

      begin_op();
    8000470c:	997ff0ef          	jal	800040a2 <begin_op>
      ilock(f->ip);
    80004710:	01893503          	ld	a0,24(s2)
    80004714:	fa5fe0ef          	jal	800036b8 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004718:	8756                	mv	a4,s5
    8000471a:	02092683          	lw	a3,32(s2)
    8000471e:	01698633          	add	a2,s3,s6
    80004722:	4585                	li	a1,1
    80004724:	01893503          	ld	a0,24(s2)
    80004728:	c1cff0ef          	jal	80003b44 <writei>
    8000472c:	84aa                	mv	s1,a0
    8000472e:	00a05763          	blez	a0,8000473c <filewrite+0xb0>
        f->off += r;
    80004732:	02092783          	lw	a5,32(s2)
    80004736:	9fa9                	addw	a5,a5,a0
    80004738:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000473c:	01893503          	ld	a0,24(s2)
    80004740:	826ff0ef          	jal	80003766 <iunlock>
      end_op();
    80004744:	9c9ff0ef          	jal	8000410c <end_op>

      if(r != n1){
    80004748:	029a9563          	bne	s5,s1,80004772 <filewrite+0xe6>
        // error from writei
        break;
      }
      i += r;
    8000474c:	013489bb          	addw	s3,s1,s3
    while(i < n){
    80004750:	0149da63          	bge	s3,s4,80004764 <filewrite+0xd8>
      int n1 = n - i;
    80004754:	413a04bb          	subw	s1,s4,s3
      if(n1 > max)
    80004758:	0004879b          	sext.w	a5,s1
    8000475c:	fafbd6e3          	bge	s7,a5,80004708 <filewrite+0x7c>
    80004760:	84e2                	mv	s1,s8
    80004762:	b75d                	j	80004708 <filewrite+0x7c>
    80004764:	74e2                	ld	s1,56(sp)
    80004766:	6ae2                	ld	s5,24(sp)
    80004768:	6ba2                	ld	s7,8(sp)
    8000476a:	6c02                	ld	s8,0(sp)
    8000476c:	a039                	j	8000477a <filewrite+0xee>
    int i = 0;
    8000476e:	4981                	li	s3,0
    80004770:	a029                	j	8000477a <filewrite+0xee>
    80004772:	74e2                	ld	s1,56(sp)
    80004774:	6ae2                	ld	s5,24(sp)
    80004776:	6ba2                	ld	s7,8(sp)
    80004778:	6c02                	ld	s8,0(sp)
    }
    ret = (i == n ? n : -1);
    8000477a:	033a1c63          	bne	s4,s3,800047b2 <filewrite+0x126>
    8000477e:	8552                	mv	a0,s4
    80004780:	79a2                	ld	s3,40(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004782:	60a6                	ld	ra,72(sp)
    80004784:	6406                	ld	s0,64(sp)
    80004786:	7942                	ld	s2,48(sp)
    80004788:	7a02                	ld	s4,32(sp)
    8000478a:	6b42                	ld	s6,16(sp)
    8000478c:	6161                	addi	sp,sp,80
    8000478e:	8082                	ret
    80004790:	fc26                	sd	s1,56(sp)
    80004792:	f44e                	sd	s3,40(sp)
    80004794:	ec56                	sd	s5,24(sp)
    80004796:	e45e                	sd	s7,8(sp)
    80004798:	e062                	sd	s8,0(sp)
    panic("filewrite");
    8000479a:	00003517          	auipc	a0,0x3
    8000479e:	e5e50513          	addi	a0,a0,-418 # 800075f8 <etext+0x5f8>
    800047a2:	83efc0ef          	jal	800007e0 <panic>
    return -1;
    800047a6:	557d                	li	a0,-1
}
    800047a8:	8082                	ret
      return -1;
    800047aa:	557d                	li	a0,-1
    800047ac:	bfd9                	j	80004782 <filewrite+0xf6>
    800047ae:	557d                	li	a0,-1
    800047b0:	bfc9                	j	80004782 <filewrite+0xf6>
    ret = (i == n ? n : -1);
    800047b2:	557d                	li	a0,-1
    800047b4:	79a2                	ld	s3,40(sp)
    800047b6:	b7f1                	j	80004782 <filewrite+0xf6>

00000000800047b8 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800047b8:	7179                	addi	sp,sp,-48
    800047ba:	f406                	sd	ra,40(sp)
    800047bc:	f022                	sd	s0,32(sp)
    800047be:	ec26                	sd	s1,24(sp)
    800047c0:	e052                	sd	s4,0(sp)
    800047c2:	1800                	addi	s0,sp,48
    800047c4:	84aa                	mv	s1,a0
    800047c6:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800047c8:	0005b023          	sd	zero,0(a1)
    800047cc:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800047d0:	c3bff0ef          	jal	8000440a <filealloc>
    800047d4:	e088                	sd	a0,0(s1)
    800047d6:	c549                	beqz	a0,80004860 <pipealloc+0xa8>
    800047d8:	c33ff0ef          	jal	8000440a <filealloc>
    800047dc:	00aa3023          	sd	a0,0(s4)
    800047e0:	cd25                	beqz	a0,80004858 <pipealloc+0xa0>
    800047e2:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800047e4:	b1afc0ef          	jal	80000afe <kalloc>
    800047e8:	892a                	mv	s2,a0
    800047ea:	c12d                	beqz	a0,8000484c <pipealloc+0x94>
    800047ec:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    800047ee:	4985                	li	s3,1
    800047f0:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800047f4:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800047f8:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800047fc:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004800:	00003597          	auipc	a1,0x3
    80004804:	e0858593          	addi	a1,a1,-504 # 80007608 <etext+0x608>
    80004808:	b88fc0ef          	jal	80000b90 <initlock>
  (*f0)->type = FD_PIPE;
    8000480c:	609c                	ld	a5,0(s1)
    8000480e:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004812:	609c                	ld	a5,0(s1)
    80004814:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004818:	609c                	ld	a5,0(s1)
    8000481a:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    8000481e:	609c                	ld	a5,0(s1)
    80004820:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004824:	000a3783          	ld	a5,0(s4)
    80004828:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000482c:	000a3783          	ld	a5,0(s4)
    80004830:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004834:	000a3783          	ld	a5,0(s4)
    80004838:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000483c:	000a3783          	ld	a5,0(s4)
    80004840:	0127b823          	sd	s2,16(a5)
  return 0;
    80004844:	4501                	li	a0,0
    80004846:	6942                	ld	s2,16(sp)
    80004848:	69a2                	ld	s3,8(sp)
    8000484a:	a01d                	j	80004870 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    8000484c:	6088                	ld	a0,0(s1)
    8000484e:	c119                	beqz	a0,80004854 <pipealloc+0x9c>
    80004850:	6942                	ld	s2,16(sp)
    80004852:	a029                	j	8000485c <pipealloc+0xa4>
    80004854:	6942                	ld	s2,16(sp)
    80004856:	a029                	j	80004860 <pipealloc+0xa8>
    80004858:	6088                	ld	a0,0(s1)
    8000485a:	c10d                	beqz	a0,8000487c <pipealloc+0xc4>
    fileclose(*f0);
    8000485c:	c53ff0ef          	jal	800044ae <fileclose>
  if(*f1)
    80004860:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004864:	557d                	li	a0,-1
  if(*f1)
    80004866:	c789                	beqz	a5,80004870 <pipealloc+0xb8>
    fileclose(*f1);
    80004868:	853e                	mv	a0,a5
    8000486a:	c45ff0ef          	jal	800044ae <fileclose>
  return -1;
    8000486e:	557d                	li	a0,-1
}
    80004870:	70a2                	ld	ra,40(sp)
    80004872:	7402                	ld	s0,32(sp)
    80004874:	64e2                	ld	s1,24(sp)
    80004876:	6a02                	ld	s4,0(sp)
    80004878:	6145                	addi	sp,sp,48
    8000487a:	8082                	ret
  return -1;
    8000487c:	557d                	li	a0,-1
    8000487e:	bfcd                	j	80004870 <pipealloc+0xb8>

0000000080004880 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004880:	1101                	addi	sp,sp,-32
    80004882:	ec06                	sd	ra,24(sp)
    80004884:	e822                	sd	s0,16(sp)
    80004886:	e426                	sd	s1,8(sp)
    80004888:	e04a                	sd	s2,0(sp)
    8000488a:	1000                	addi	s0,sp,32
    8000488c:	84aa                	mv	s1,a0
    8000488e:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004890:	b80fc0ef          	jal	80000c10 <acquire>
  if(writable){
    80004894:	02090763          	beqz	s2,800048c2 <pipeclose+0x42>
    pi->writeopen = 0;
    80004898:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    8000489c:	21848513          	addi	a0,s1,536
    800048a0:	ecafd0ef          	jal	80001f6a <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800048a4:	2204b783          	ld	a5,544(s1)
    800048a8:	e785                	bnez	a5,800048d0 <pipeclose+0x50>
    release(&pi->lock);
    800048aa:	8526                	mv	a0,s1
    800048ac:	bfcfc0ef          	jal	80000ca8 <release>
    kfree((char*)pi);
    800048b0:	8526                	mv	a0,s1
    800048b2:	96afc0ef          	jal	80000a1c <kfree>
  } else
    release(&pi->lock);
}
    800048b6:	60e2                	ld	ra,24(sp)
    800048b8:	6442                	ld	s0,16(sp)
    800048ba:	64a2                	ld	s1,8(sp)
    800048bc:	6902                	ld	s2,0(sp)
    800048be:	6105                	addi	sp,sp,32
    800048c0:	8082                	ret
    pi->readopen = 0;
    800048c2:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800048c6:	21c48513          	addi	a0,s1,540
    800048ca:	ea0fd0ef          	jal	80001f6a <wakeup>
    800048ce:	bfd9                	j	800048a4 <pipeclose+0x24>
    release(&pi->lock);
    800048d0:	8526                	mv	a0,s1
    800048d2:	bd6fc0ef          	jal	80000ca8 <release>
}
    800048d6:	b7c5                	j	800048b6 <pipeclose+0x36>

00000000800048d8 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800048d8:	711d                	addi	sp,sp,-96
    800048da:	ec86                	sd	ra,88(sp)
    800048dc:	e8a2                	sd	s0,80(sp)
    800048de:	e4a6                	sd	s1,72(sp)
    800048e0:	e0ca                	sd	s2,64(sp)
    800048e2:	fc4e                	sd	s3,56(sp)
    800048e4:	f852                	sd	s4,48(sp)
    800048e6:	f456                	sd	s5,40(sp)
    800048e8:	1080                	addi	s0,sp,96
    800048ea:	84aa                	mv	s1,a0
    800048ec:	8aae                	mv	s5,a1
    800048ee:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800048f0:	820fd0ef          	jal	80001910 <myproc>
    800048f4:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800048f6:	8526                	mv	a0,s1
    800048f8:	b18fc0ef          	jal	80000c10 <acquire>
  while(i < n){
    800048fc:	0b405a63          	blez	s4,800049b0 <pipewrite+0xd8>
    80004900:	f05a                	sd	s6,32(sp)
    80004902:	ec5e                	sd	s7,24(sp)
    80004904:	e862                	sd	s8,16(sp)
  int i = 0;
    80004906:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004908:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    8000490a:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    8000490e:	21c48b93          	addi	s7,s1,540
    80004912:	a81d                	j	80004948 <pipewrite+0x70>
      release(&pi->lock);
    80004914:	8526                	mv	a0,s1
    80004916:	b92fc0ef          	jal	80000ca8 <release>
      return -1;
    8000491a:	597d                	li	s2,-1
    8000491c:	7b02                	ld	s6,32(sp)
    8000491e:	6be2                	ld	s7,24(sp)
    80004920:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004922:	854a                	mv	a0,s2
    80004924:	60e6                	ld	ra,88(sp)
    80004926:	6446                	ld	s0,80(sp)
    80004928:	64a6                	ld	s1,72(sp)
    8000492a:	6906                	ld	s2,64(sp)
    8000492c:	79e2                	ld	s3,56(sp)
    8000492e:	7a42                	ld	s4,48(sp)
    80004930:	7aa2                	ld	s5,40(sp)
    80004932:	6125                	addi	sp,sp,96
    80004934:	8082                	ret
      wakeup(&pi->nread);
    80004936:	8562                	mv	a0,s8
    80004938:	e32fd0ef          	jal	80001f6a <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    8000493c:	85a6                	mv	a1,s1
    8000493e:	855e                	mv	a0,s7
    80004940:	ddefd0ef          	jal	80001f1e <sleep>
  while(i < n){
    80004944:	05495b63          	bge	s2,s4,8000499a <pipewrite+0xc2>
    if(pi->readopen == 0 || killed(pr)){
    80004948:	2204a783          	lw	a5,544(s1)
    8000494c:	d7e1                	beqz	a5,80004914 <pipewrite+0x3c>
    8000494e:	854e                	mv	a0,s3
    80004950:	807fd0ef          	jal	80002156 <killed>
    80004954:	f161                	bnez	a0,80004914 <pipewrite+0x3c>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004956:	2184a783          	lw	a5,536(s1)
    8000495a:	21c4a703          	lw	a4,540(s1)
    8000495e:	2007879b          	addiw	a5,a5,512
    80004962:	fcf70ae3          	beq	a4,a5,80004936 <pipewrite+0x5e>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004966:	4685                	li	a3,1
    80004968:	01590633          	add	a2,s2,s5
    8000496c:	faf40593          	addi	a1,s0,-81
    80004970:	0509b503          	ld	a0,80(s3)
    80004974:	d95fc0ef          	jal	80001708 <copyin>
    80004978:	03650e63          	beq	a0,s6,800049b4 <pipewrite+0xdc>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    8000497c:	21c4a783          	lw	a5,540(s1)
    80004980:	0017871b          	addiw	a4,a5,1
    80004984:	20e4ae23          	sw	a4,540(s1)
    80004988:	1ff7f793          	andi	a5,a5,511
    8000498c:	97a6                	add	a5,a5,s1
    8000498e:	faf44703          	lbu	a4,-81(s0)
    80004992:	00e78c23          	sb	a4,24(a5)
      i++;
    80004996:	2905                	addiw	s2,s2,1
    80004998:	b775                	j	80004944 <pipewrite+0x6c>
    8000499a:	7b02                	ld	s6,32(sp)
    8000499c:	6be2                	ld	s7,24(sp)
    8000499e:	6c42                	ld	s8,16(sp)
  wakeup(&pi->nread);
    800049a0:	21848513          	addi	a0,s1,536
    800049a4:	dc6fd0ef          	jal	80001f6a <wakeup>
  release(&pi->lock);
    800049a8:	8526                	mv	a0,s1
    800049aa:	afefc0ef          	jal	80000ca8 <release>
  return i;
    800049ae:	bf95                	j	80004922 <pipewrite+0x4a>
  int i = 0;
    800049b0:	4901                	li	s2,0
    800049b2:	b7fd                	j	800049a0 <pipewrite+0xc8>
    800049b4:	7b02                	ld	s6,32(sp)
    800049b6:	6be2                	ld	s7,24(sp)
    800049b8:	6c42                	ld	s8,16(sp)
    800049ba:	b7dd                	j	800049a0 <pipewrite+0xc8>

00000000800049bc <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800049bc:	715d                	addi	sp,sp,-80
    800049be:	e486                	sd	ra,72(sp)
    800049c0:	e0a2                	sd	s0,64(sp)
    800049c2:	fc26                	sd	s1,56(sp)
    800049c4:	f84a                	sd	s2,48(sp)
    800049c6:	f44e                	sd	s3,40(sp)
    800049c8:	f052                	sd	s4,32(sp)
    800049ca:	ec56                	sd	s5,24(sp)
    800049cc:	0880                	addi	s0,sp,80
    800049ce:	84aa                	mv	s1,a0
    800049d0:	892e                	mv	s2,a1
    800049d2:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800049d4:	f3dfc0ef          	jal	80001910 <myproc>
    800049d8:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800049da:	8526                	mv	a0,s1
    800049dc:	a34fc0ef          	jal	80000c10 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800049e0:	2184a703          	lw	a4,536(s1)
    800049e4:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800049e8:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800049ec:	02f71563          	bne	a4,a5,80004a16 <piperead+0x5a>
    800049f0:	2244a783          	lw	a5,548(s1)
    800049f4:	cb85                	beqz	a5,80004a24 <piperead+0x68>
    if(killed(pr)){
    800049f6:	8552                	mv	a0,s4
    800049f8:	f5efd0ef          	jal	80002156 <killed>
    800049fc:	ed19                	bnez	a0,80004a1a <piperead+0x5e>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800049fe:	85a6                	mv	a1,s1
    80004a00:	854e                	mv	a0,s3
    80004a02:	d1cfd0ef          	jal	80001f1e <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004a06:	2184a703          	lw	a4,536(s1)
    80004a0a:	21c4a783          	lw	a5,540(s1)
    80004a0e:	fef701e3          	beq	a4,a5,800049f0 <piperead+0x34>
    80004a12:	e85a                	sd	s6,16(sp)
    80004a14:	a809                	j	80004a26 <piperead+0x6a>
    80004a16:	e85a                	sd	s6,16(sp)
    80004a18:	a039                	j	80004a26 <piperead+0x6a>
      release(&pi->lock);
    80004a1a:	8526                	mv	a0,s1
    80004a1c:	a8cfc0ef          	jal	80000ca8 <release>
      return -1;
    80004a20:	59fd                	li	s3,-1
    80004a22:	a8b9                	j	80004a80 <piperead+0xc4>
    80004a24:	e85a                	sd	s6,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004a26:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    80004a28:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004a2a:	05505363          	blez	s5,80004a70 <piperead+0xb4>
    if(pi->nread == pi->nwrite)
    80004a2e:	2184a783          	lw	a5,536(s1)
    80004a32:	21c4a703          	lw	a4,540(s1)
    80004a36:	02f70d63          	beq	a4,a5,80004a70 <piperead+0xb4>
    ch = pi->data[pi->nread % PIPESIZE];
    80004a3a:	1ff7f793          	andi	a5,a5,511
    80004a3e:	97a6                	add	a5,a5,s1
    80004a40:	0187c783          	lbu	a5,24(a5)
    80004a44:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    80004a48:	4685                	li	a3,1
    80004a4a:	fbf40613          	addi	a2,s0,-65
    80004a4e:	85ca                	mv	a1,s2
    80004a50:	050a3503          	ld	a0,80(s4)
    80004a54:	bd1fc0ef          	jal	80001624 <copyout>
    80004a58:	03650e63          	beq	a0,s6,80004a94 <piperead+0xd8>
      if(i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    80004a5c:	2184a783          	lw	a5,536(s1)
    80004a60:	2785                	addiw	a5,a5,1
    80004a62:	20f4ac23          	sw	a5,536(s1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004a66:	2985                	addiw	s3,s3,1
    80004a68:	0905                	addi	s2,s2,1
    80004a6a:	fd3a92e3          	bne	s5,s3,80004a2e <piperead+0x72>
    80004a6e:	89d6                	mv	s3,s5
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004a70:	21c48513          	addi	a0,s1,540
    80004a74:	cf6fd0ef          	jal	80001f6a <wakeup>
  release(&pi->lock);
    80004a78:	8526                	mv	a0,s1
    80004a7a:	a2efc0ef          	jal	80000ca8 <release>
    80004a7e:	6b42                	ld	s6,16(sp)
  return i;
}
    80004a80:	854e                	mv	a0,s3
    80004a82:	60a6                	ld	ra,72(sp)
    80004a84:	6406                	ld	s0,64(sp)
    80004a86:	74e2                	ld	s1,56(sp)
    80004a88:	7942                	ld	s2,48(sp)
    80004a8a:	79a2                	ld	s3,40(sp)
    80004a8c:	7a02                	ld	s4,32(sp)
    80004a8e:	6ae2                	ld	s5,24(sp)
    80004a90:	6161                	addi	sp,sp,80
    80004a92:	8082                	ret
      if(i == 0)
    80004a94:	fc099ee3          	bnez	s3,80004a70 <piperead+0xb4>
        i = -1;
    80004a98:	89aa                	mv	s3,a0
    80004a9a:	bfd9                	j	80004a70 <piperead+0xb4>

0000000080004a9c <flags2perm>:

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int flags2perm(int flags)
{
    80004a9c:	1141                	addi	sp,sp,-16
    80004a9e:	e422                	sd	s0,8(sp)
    80004aa0:	0800                	addi	s0,sp,16
    80004aa2:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004aa4:	8905                	andi	a0,a0,1
    80004aa6:	050e                	slli	a0,a0,0x3
      perm = PTE_X;
    if(flags & 0x2)
    80004aa8:	8b89                	andi	a5,a5,2
    80004aaa:	c399                	beqz	a5,80004ab0 <flags2perm+0x14>
      perm |= PTE_W;
    80004aac:	00456513          	ori	a0,a0,4
    return perm;
}
    80004ab0:	6422                	ld	s0,8(sp)
    80004ab2:	0141                	addi	sp,sp,16
    80004ab4:	8082                	ret

0000000080004ab6 <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    80004ab6:	df010113          	addi	sp,sp,-528
    80004aba:	20113423          	sd	ra,520(sp)
    80004abe:	20813023          	sd	s0,512(sp)
    80004ac2:	ffa6                	sd	s1,504(sp)
    80004ac4:	fbca                	sd	s2,496(sp)
    80004ac6:	0c00                	addi	s0,sp,528
    80004ac8:	892a                	mv	s2,a0
    80004aca:	dea43c23          	sd	a0,-520(s0)
    80004ace:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004ad2:	e3ffc0ef          	jal	80001910 <myproc>
    80004ad6:	84aa                	mv	s1,a0

  begin_op();
    80004ad8:	dcaff0ef          	jal	800040a2 <begin_op>

  // Open the executable file.
  if((ip = namei(path)) == 0){
    80004adc:	854a                	mv	a0,s2
    80004ade:	bf0ff0ef          	jal	80003ece <namei>
    80004ae2:	c931                	beqz	a0,80004b36 <kexec+0x80>
    80004ae4:	f3d2                	sd	s4,480(sp)
    80004ae6:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004ae8:	bd1fe0ef          	jal	800036b8 <ilock>

  // Read the ELF header.
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004aec:	04000713          	li	a4,64
    80004af0:	4681                	li	a3,0
    80004af2:	e5040613          	addi	a2,s0,-432
    80004af6:	4581                	li	a1,0
    80004af8:	8552                	mv	a0,s4
    80004afa:	f4ffe0ef          	jal	80003a48 <readi>
    80004afe:	04000793          	li	a5,64
    80004b02:	00f51a63          	bne	a0,a5,80004b16 <kexec+0x60>
    goto bad;

  // Is this really an ELF file?
  if(elf.magic != ELF_MAGIC)
    80004b06:	e5042703          	lw	a4,-432(s0)
    80004b0a:	464c47b7          	lui	a5,0x464c4
    80004b0e:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004b12:	02f70663          	beq	a4,a5,80004b3e <kexec+0x88>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004b16:	8552                	mv	a0,s4
    80004b18:	dabfe0ef          	jal	800038c2 <iunlockput>
    end_op();
    80004b1c:	df0ff0ef          	jal	8000410c <end_op>
  }
  return -1;
    80004b20:	557d                	li	a0,-1
    80004b22:	7a1e                	ld	s4,480(sp)
}
    80004b24:	20813083          	ld	ra,520(sp)
    80004b28:	20013403          	ld	s0,512(sp)
    80004b2c:	74fe                	ld	s1,504(sp)
    80004b2e:	795e                	ld	s2,496(sp)
    80004b30:	21010113          	addi	sp,sp,528
    80004b34:	8082                	ret
    end_op();
    80004b36:	dd6ff0ef          	jal	8000410c <end_op>
    return -1;
    80004b3a:	557d                	li	a0,-1
    80004b3c:	b7e5                	j	80004b24 <kexec+0x6e>
    80004b3e:	ebda                	sd	s6,464(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80004b40:	8526                	mv	a0,s1
    80004b42:	ed5fc0ef          	jal	80001a16 <proc_pagetable>
    80004b46:	8b2a                	mv	s6,a0
    80004b48:	2c050b63          	beqz	a0,80004e1e <kexec+0x368>
    80004b4c:	f7ce                	sd	s3,488(sp)
    80004b4e:	efd6                	sd	s5,472(sp)
    80004b50:	e7de                	sd	s7,456(sp)
    80004b52:	e3e2                	sd	s8,448(sp)
    80004b54:	ff66                	sd	s9,440(sp)
    80004b56:	fb6a                	sd	s10,432(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004b58:	e7042d03          	lw	s10,-400(s0)
    80004b5c:	e8845783          	lhu	a5,-376(s0)
    80004b60:	12078963          	beqz	a5,80004c92 <kexec+0x1dc>
    80004b64:	f76e                	sd	s11,424(sp)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004b66:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004b68:	4d81                	li	s11,0
    if(ph.vaddr % PGSIZE != 0)
    80004b6a:	6c85                	lui	s9,0x1
    80004b6c:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80004b70:	def43823          	sd	a5,-528(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80004b74:	6a85                	lui	s5,0x1
    80004b76:	a085                	j	80004bd6 <kexec+0x120>
      panic("loadseg: address should exist");
    80004b78:	00003517          	auipc	a0,0x3
    80004b7c:	a9850513          	addi	a0,a0,-1384 # 80007610 <etext+0x610>
    80004b80:	c61fb0ef          	jal	800007e0 <panic>
    if(sz - i < PGSIZE)
    80004b84:	2481                	sext.w	s1,s1
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004b86:	8726                	mv	a4,s1
    80004b88:	012c06bb          	addw	a3,s8,s2
    80004b8c:	4581                	li	a1,0
    80004b8e:	8552                	mv	a0,s4
    80004b90:	eb9fe0ef          	jal	80003a48 <readi>
    80004b94:	2501                	sext.w	a0,a0
    80004b96:	24a49a63          	bne	s1,a0,80004dea <kexec+0x334>
  for(i = 0; i < sz; i += PGSIZE){
    80004b9a:	012a893b          	addw	s2,s5,s2
    80004b9e:	03397363          	bgeu	s2,s3,80004bc4 <kexec+0x10e>
    pa = walkaddr(pagetable, va + i);
    80004ba2:	02091593          	slli	a1,s2,0x20
    80004ba6:	9181                	srli	a1,a1,0x20
    80004ba8:	95de                	add	a1,a1,s7
    80004baa:	855a                	mv	a0,s6
    80004bac:	c46fc0ef          	jal	80000ff2 <walkaddr>
    80004bb0:	862a                	mv	a2,a0
    if(pa == 0)
    80004bb2:	d179                	beqz	a0,80004b78 <kexec+0xc2>
    if(sz - i < PGSIZE)
    80004bb4:	412984bb          	subw	s1,s3,s2
    80004bb8:	0004879b          	sext.w	a5,s1
    80004bbc:	fcfcf4e3          	bgeu	s9,a5,80004b84 <kexec+0xce>
    80004bc0:	84d6                	mv	s1,s5
    80004bc2:	b7c9                	j	80004b84 <kexec+0xce>
    sz = sz1;
    80004bc4:	e0843903          	ld	s2,-504(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004bc8:	2d85                	addiw	s11,s11,1
    80004bca:	038d0d1b          	addiw	s10,s10,56
    80004bce:	e8845783          	lhu	a5,-376(s0)
    80004bd2:	08fdd063          	bge	s11,a5,80004c52 <kexec+0x19c>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004bd6:	2d01                	sext.w	s10,s10
    80004bd8:	03800713          	li	a4,56
    80004bdc:	86ea                	mv	a3,s10
    80004bde:	e1840613          	addi	a2,s0,-488
    80004be2:	4581                	li	a1,0
    80004be4:	8552                	mv	a0,s4
    80004be6:	e63fe0ef          	jal	80003a48 <readi>
    80004bea:	03800793          	li	a5,56
    80004bee:	1cf51663          	bne	a0,a5,80004dba <kexec+0x304>
    if(ph.type != ELF_PROG_LOAD)
    80004bf2:	e1842783          	lw	a5,-488(s0)
    80004bf6:	4705                	li	a4,1
    80004bf8:	fce798e3          	bne	a5,a4,80004bc8 <kexec+0x112>
    if(ph.memsz < ph.filesz)
    80004bfc:	e4043483          	ld	s1,-448(s0)
    80004c00:	e3843783          	ld	a5,-456(s0)
    80004c04:	1af4ef63          	bltu	s1,a5,80004dc2 <kexec+0x30c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004c08:	e2843783          	ld	a5,-472(s0)
    80004c0c:	94be                	add	s1,s1,a5
    80004c0e:	1af4ee63          	bltu	s1,a5,80004dca <kexec+0x314>
    if(ph.vaddr % PGSIZE != 0)
    80004c12:	df043703          	ld	a4,-528(s0)
    80004c16:	8ff9                	and	a5,a5,a4
    80004c18:	1a079d63          	bnez	a5,80004dd2 <kexec+0x31c>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004c1c:	e1c42503          	lw	a0,-484(s0)
    80004c20:	e7dff0ef          	jal	80004a9c <flags2perm>
    80004c24:	86aa                	mv	a3,a0
    80004c26:	8626                	mv	a2,s1
    80004c28:	85ca                	mv	a1,s2
    80004c2a:	855a                	mv	a0,s6
    80004c2c:	e9efc0ef          	jal	800012ca <uvmalloc>
    80004c30:	e0a43423          	sd	a0,-504(s0)
    80004c34:	1a050363          	beqz	a0,80004dda <kexec+0x324>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004c38:	e2843b83          	ld	s7,-472(s0)
    80004c3c:	e2042c03          	lw	s8,-480(s0)
    80004c40:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004c44:	00098463          	beqz	s3,80004c4c <kexec+0x196>
    80004c48:	4901                	li	s2,0
    80004c4a:	bfa1                	j	80004ba2 <kexec+0xec>
    sz = sz1;
    80004c4c:	e0843903          	ld	s2,-504(s0)
    80004c50:	bfa5                	j	80004bc8 <kexec+0x112>
    80004c52:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    80004c54:	8552                	mv	a0,s4
    80004c56:	c6dfe0ef          	jal	800038c2 <iunlockput>
  end_op();
    80004c5a:	cb2ff0ef          	jal	8000410c <end_op>
  p = myproc();
    80004c5e:	cb3fc0ef          	jal	80001910 <myproc>
    80004c62:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80004c64:	04853c83          	ld	s9,72(a0)
  sz = PGROUNDUP(sz);
    80004c68:	6985                	lui	s3,0x1
    80004c6a:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80004c6c:	99ca                	add	s3,s3,s2
    80004c6e:	77fd                	lui	a5,0xfffff
    80004c70:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80004c74:	4691                	li	a3,4
    80004c76:	6609                	lui	a2,0x2
    80004c78:	964e                	add	a2,a2,s3
    80004c7a:	85ce                	mv	a1,s3
    80004c7c:	855a                	mv	a0,s6
    80004c7e:	e4cfc0ef          	jal	800012ca <uvmalloc>
    80004c82:	892a                	mv	s2,a0
    80004c84:	e0a43423          	sd	a0,-504(s0)
    80004c88:	e519                	bnez	a0,80004c96 <kexec+0x1e0>
  if(pagetable)
    80004c8a:	e1343423          	sd	s3,-504(s0)
    80004c8e:	4a01                	li	s4,0
    80004c90:	aab1                	j	80004dec <kexec+0x336>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004c92:	4901                	li	s2,0
    80004c94:	b7c1                	j	80004c54 <kexec+0x19e>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80004c96:	75f9                	lui	a1,0xffffe
    80004c98:	95aa                	add	a1,a1,a0
    80004c9a:	855a                	mv	a0,s6
    80004c9c:	805fc0ef          	jal	800014a0 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80004ca0:	7bfd                	lui	s7,0xfffff
    80004ca2:	9bca                	add	s7,s7,s2
  for(argc = 0; argv[argc]; argc++) {
    80004ca4:	e0043783          	ld	a5,-512(s0)
    80004ca8:	6388                	ld	a0,0(a5)
    80004caa:	cd39                	beqz	a0,80004d08 <kexec+0x252>
    80004cac:	e9040993          	addi	s3,s0,-368
    80004cb0:	f9040c13          	addi	s8,s0,-112
    80004cb4:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004cb6:	99efc0ef          	jal	80000e54 <strlen>
    80004cba:	0015079b          	addiw	a5,a0,1
    80004cbe:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004cc2:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004cc6:	11796e63          	bltu	s2,s7,80004de2 <kexec+0x32c>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004cca:	e0043d03          	ld	s10,-512(s0)
    80004cce:	000d3a03          	ld	s4,0(s10)
    80004cd2:	8552                	mv	a0,s4
    80004cd4:	980fc0ef          	jal	80000e54 <strlen>
    80004cd8:	0015069b          	addiw	a3,a0,1
    80004cdc:	8652                	mv	a2,s4
    80004cde:	85ca                	mv	a1,s2
    80004ce0:	855a                	mv	a0,s6
    80004ce2:	943fc0ef          	jal	80001624 <copyout>
    80004ce6:	10054063          	bltz	a0,80004de6 <kexec+0x330>
    ustack[argc] = sp;
    80004cea:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80004cee:	0485                	addi	s1,s1,1
    80004cf0:	008d0793          	addi	a5,s10,8
    80004cf4:	e0f43023          	sd	a5,-512(s0)
    80004cf8:	008d3503          	ld	a0,8(s10)
    80004cfc:	c909                	beqz	a0,80004d0e <kexec+0x258>
    if(argc >= MAXARG)
    80004cfe:	09a1                	addi	s3,s3,8
    80004d00:	fb899be3          	bne	s3,s8,80004cb6 <kexec+0x200>
  ip = 0;
    80004d04:	4a01                	li	s4,0
    80004d06:	a0dd                	j	80004dec <kexec+0x336>
  sp = sz;
    80004d08:	e0843903          	ld	s2,-504(s0)
  for(argc = 0; argv[argc]; argc++) {
    80004d0c:	4481                	li	s1,0
  ustack[argc] = 0;
    80004d0e:	00349793          	slli	a5,s1,0x3
    80004d12:	f9078793          	addi	a5,a5,-112 # ffffffffffffef90 <end+0xffffffff7ffde358>
    80004d16:	97a2                	add	a5,a5,s0
    80004d18:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004d1c:	00148693          	addi	a3,s1,1
    80004d20:	068e                	slli	a3,a3,0x3
    80004d22:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004d26:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004d2a:	e0843983          	ld	s3,-504(s0)
  if(sp < stackbase)
    80004d2e:	f5796ee3          	bltu	s2,s7,80004c8a <kexec+0x1d4>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004d32:	e9040613          	addi	a2,s0,-368
    80004d36:	85ca                	mv	a1,s2
    80004d38:	855a                	mv	a0,s6
    80004d3a:	8ebfc0ef          	jal	80001624 <copyout>
    80004d3e:	0e054263          	bltz	a0,80004e22 <kexec+0x36c>
  p->trapframe->a1 = sp;
    80004d42:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80004d46:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004d4a:	df843783          	ld	a5,-520(s0)
    80004d4e:	0007c703          	lbu	a4,0(a5)
    80004d52:	cf11                	beqz	a4,80004d6e <kexec+0x2b8>
    80004d54:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004d56:	02f00693          	li	a3,47
    80004d5a:	a039                	j	80004d68 <kexec+0x2b2>
      last = s+1;
    80004d5c:	def43c23          	sd	a5,-520(s0)
  for(last=s=path; *s; s++)
    80004d60:	0785                	addi	a5,a5,1
    80004d62:	fff7c703          	lbu	a4,-1(a5)
    80004d66:	c701                	beqz	a4,80004d6e <kexec+0x2b8>
    if(*s == '/')
    80004d68:	fed71ce3          	bne	a4,a3,80004d60 <kexec+0x2aa>
    80004d6c:	bfc5                	j	80004d5c <kexec+0x2a6>
  safestrcpy(p->name, last, sizeof(p->name));
    80004d6e:	4641                	li	a2,16
    80004d70:	df843583          	ld	a1,-520(s0)
    80004d74:	158a8513          	addi	a0,s5,344
    80004d78:	8aafc0ef          	jal	80000e22 <safestrcpy>
  oldpagetable = p->pagetable;
    80004d7c:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80004d80:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80004d84:	e0843783          	ld	a5,-504(s0)
    80004d88:	04fab423          	sd	a5,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = ulib.c:start()
    80004d8c:	058ab783          	ld	a5,88(s5)
    80004d90:	e6843703          	ld	a4,-408(s0)
    80004d94:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80004d96:	058ab783          	ld	a5,88(s5)
    80004d9a:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004d9e:	85e6                	mv	a1,s9
    80004da0:	cfbfc0ef          	jal	80001a9a <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004da4:	0004851b          	sext.w	a0,s1
    80004da8:	79be                	ld	s3,488(sp)
    80004daa:	7a1e                	ld	s4,480(sp)
    80004dac:	6afe                	ld	s5,472(sp)
    80004dae:	6b5e                	ld	s6,464(sp)
    80004db0:	6bbe                	ld	s7,456(sp)
    80004db2:	6c1e                	ld	s8,448(sp)
    80004db4:	7cfa                	ld	s9,440(sp)
    80004db6:	7d5a                	ld	s10,432(sp)
    80004db8:	b3b5                	j	80004b24 <kexec+0x6e>
    80004dba:	e1243423          	sd	s2,-504(s0)
    80004dbe:	7dba                	ld	s11,424(sp)
    80004dc0:	a035                	j	80004dec <kexec+0x336>
    80004dc2:	e1243423          	sd	s2,-504(s0)
    80004dc6:	7dba                	ld	s11,424(sp)
    80004dc8:	a015                	j	80004dec <kexec+0x336>
    80004dca:	e1243423          	sd	s2,-504(s0)
    80004dce:	7dba                	ld	s11,424(sp)
    80004dd0:	a831                	j	80004dec <kexec+0x336>
    80004dd2:	e1243423          	sd	s2,-504(s0)
    80004dd6:	7dba                	ld	s11,424(sp)
    80004dd8:	a811                	j	80004dec <kexec+0x336>
    80004dda:	e1243423          	sd	s2,-504(s0)
    80004dde:	7dba                	ld	s11,424(sp)
    80004de0:	a031                	j	80004dec <kexec+0x336>
  ip = 0;
    80004de2:	4a01                	li	s4,0
    80004de4:	a021                	j	80004dec <kexec+0x336>
    80004de6:	4a01                	li	s4,0
  if(pagetable)
    80004de8:	a011                	j	80004dec <kexec+0x336>
    80004dea:	7dba                	ld	s11,424(sp)
    proc_freepagetable(pagetable, sz);
    80004dec:	e0843583          	ld	a1,-504(s0)
    80004df0:	855a                	mv	a0,s6
    80004df2:	ca9fc0ef          	jal	80001a9a <proc_freepagetable>
  return -1;
    80004df6:	557d                	li	a0,-1
  if(ip){
    80004df8:	000a1b63          	bnez	s4,80004e0e <kexec+0x358>
    80004dfc:	79be                	ld	s3,488(sp)
    80004dfe:	7a1e                	ld	s4,480(sp)
    80004e00:	6afe                	ld	s5,472(sp)
    80004e02:	6b5e                	ld	s6,464(sp)
    80004e04:	6bbe                	ld	s7,456(sp)
    80004e06:	6c1e                	ld	s8,448(sp)
    80004e08:	7cfa                	ld	s9,440(sp)
    80004e0a:	7d5a                	ld	s10,432(sp)
    80004e0c:	bb21                	j	80004b24 <kexec+0x6e>
    80004e0e:	79be                	ld	s3,488(sp)
    80004e10:	6afe                	ld	s5,472(sp)
    80004e12:	6b5e                	ld	s6,464(sp)
    80004e14:	6bbe                	ld	s7,456(sp)
    80004e16:	6c1e                	ld	s8,448(sp)
    80004e18:	7cfa                	ld	s9,440(sp)
    80004e1a:	7d5a                	ld	s10,432(sp)
    80004e1c:	b9ed                	j	80004b16 <kexec+0x60>
    80004e1e:	6b5e                	ld	s6,464(sp)
    80004e20:	b9dd                	j	80004b16 <kexec+0x60>
  sz = sz1;
    80004e22:	e0843983          	ld	s3,-504(s0)
    80004e26:	b595                	j	80004c8a <kexec+0x1d4>

0000000080004e28 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004e28:	7179                	addi	sp,sp,-48
    80004e2a:	f406                	sd	ra,40(sp)
    80004e2c:	f022                	sd	s0,32(sp)
    80004e2e:	ec26                	sd	s1,24(sp)
    80004e30:	e84a                	sd	s2,16(sp)
    80004e32:	1800                	addi	s0,sp,48
    80004e34:	892e                	mv	s2,a1
    80004e36:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004e38:	fdc40593          	addi	a1,s0,-36
    80004e3c:	dcbfd0ef          	jal	80002c06 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004e40:	fdc42703          	lw	a4,-36(s0)
    80004e44:	47bd                	li	a5,15
    80004e46:	02e7e963          	bltu	a5,a4,80004e78 <argfd+0x50>
    80004e4a:	ac7fc0ef          	jal	80001910 <myproc>
    80004e4e:	fdc42703          	lw	a4,-36(s0)
    80004e52:	01a70793          	addi	a5,a4,26
    80004e56:	078e                	slli	a5,a5,0x3
    80004e58:	953e                	add	a0,a0,a5
    80004e5a:	611c                	ld	a5,0(a0)
    80004e5c:	c385                	beqz	a5,80004e7c <argfd+0x54>
    return -1;
  if(pfd)
    80004e5e:	00090463          	beqz	s2,80004e66 <argfd+0x3e>
    *pfd = fd;
    80004e62:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004e66:	4501                	li	a0,0
  if(pf)
    80004e68:	c091                	beqz	s1,80004e6c <argfd+0x44>
    *pf = f;
    80004e6a:	e09c                	sd	a5,0(s1)
}
    80004e6c:	70a2                	ld	ra,40(sp)
    80004e6e:	7402                	ld	s0,32(sp)
    80004e70:	64e2                	ld	s1,24(sp)
    80004e72:	6942                	ld	s2,16(sp)
    80004e74:	6145                	addi	sp,sp,48
    80004e76:	8082                	ret
    return -1;
    80004e78:	557d                	li	a0,-1
    80004e7a:	bfcd                	j	80004e6c <argfd+0x44>
    80004e7c:	557d                	li	a0,-1
    80004e7e:	b7fd                	j	80004e6c <argfd+0x44>

0000000080004e80 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004e80:	1101                	addi	sp,sp,-32
    80004e82:	ec06                	sd	ra,24(sp)
    80004e84:	e822                	sd	s0,16(sp)
    80004e86:	e426                	sd	s1,8(sp)
    80004e88:	1000                	addi	s0,sp,32
    80004e8a:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004e8c:	a85fc0ef          	jal	80001910 <myproc>
    80004e90:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004e92:	0d050793          	addi	a5,a0,208
    80004e96:	4501                	li	a0,0
    80004e98:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004e9a:	6398                	ld	a4,0(a5)
    80004e9c:	cb19                	beqz	a4,80004eb2 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004e9e:	2505                	addiw	a0,a0,1
    80004ea0:	07a1                	addi	a5,a5,8
    80004ea2:	fed51ce3          	bne	a0,a3,80004e9a <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004ea6:	557d                	li	a0,-1
}
    80004ea8:	60e2                	ld	ra,24(sp)
    80004eaa:	6442                	ld	s0,16(sp)
    80004eac:	64a2                	ld	s1,8(sp)
    80004eae:	6105                	addi	sp,sp,32
    80004eb0:	8082                	ret
      p->ofile[fd] = f;
    80004eb2:	01a50793          	addi	a5,a0,26
    80004eb6:	078e                	slli	a5,a5,0x3
    80004eb8:	963e                	add	a2,a2,a5
    80004eba:	e204                	sd	s1,0(a2)
      return fd;
    80004ebc:	b7f5                	j	80004ea8 <fdalloc+0x28>

0000000080004ebe <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004ebe:	715d                	addi	sp,sp,-80
    80004ec0:	e486                	sd	ra,72(sp)
    80004ec2:	e0a2                	sd	s0,64(sp)
    80004ec4:	fc26                	sd	s1,56(sp)
    80004ec6:	f84a                	sd	s2,48(sp)
    80004ec8:	f44e                	sd	s3,40(sp)
    80004eca:	ec56                	sd	s5,24(sp)
    80004ecc:	e85a                	sd	s6,16(sp)
    80004ece:	0880                	addi	s0,sp,80
    80004ed0:	8b2e                	mv	s6,a1
    80004ed2:	89b2                	mv	s3,a2
    80004ed4:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004ed6:	fb040593          	addi	a1,s0,-80
    80004eda:	80eff0ef          	jal	80003ee8 <nameiparent>
    80004ede:	84aa                	mv	s1,a0
    80004ee0:	10050a63          	beqz	a0,80004ff4 <create+0x136>
    return 0;

  ilock(dp);
    80004ee4:	fd4fe0ef          	jal	800036b8 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004ee8:	4601                	li	a2,0
    80004eea:	fb040593          	addi	a1,s0,-80
    80004eee:	8526                	mv	a0,s1
    80004ef0:	d79fe0ef          	jal	80003c68 <dirlookup>
    80004ef4:	8aaa                	mv	s5,a0
    80004ef6:	c129                	beqz	a0,80004f38 <create+0x7a>
    iunlockput(dp);
    80004ef8:	8526                	mv	a0,s1
    80004efa:	9c9fe0ef          	jal	800038c2 <iunlockput>
    ilock(ip);
    80004efe:	8556                	mv	a0,s5
    80004f00:	fb8fe0ef          	jal	800036b8 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004f04:	4789                	li	a5,2
    80004f06:	02fb1463          	bne	s6,a5,80004f2e <create+0x70>
    80004f0a:	044ad783          	lhu	a5,68(s5)
    80004f0e:	37f9                	addiw	a5,a5,-2
    80004f10:	17c2                	slli	a5,a5,0x30
    80004f12:	93c1                	srli	a5,a5,0x30
    80004f14:	4705                	li	a4,1
    80004f16:	00f76c63          	bltu	a4,a5,80004f2e <create+0x70>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004f1a:	8556                	mv	a0,s5
    80004f1c:	60a6                	ld	ra,72(sp)
    80004f1e:	6406                	ld	s0,64(sp)
    80004f20:	74e2                	ld	s1,56(sp)
    80004f22:	7942                	ld	s2,48(sp)
    80004f24:	79a2                	ld	s3,40(sp)
    80004f26:	6ae2                	ld	s5,24(sp)
    80004f28:	6b42                	ld	s6,16(sp)
    80004f2a:	6161                	addi	sp,sp,80
    80004f2c:	8082                	ret
    iunlockput(ip);
    80004f2e:	8556                	mv	a0,s5
    80004f30:	993fe0ef          	jal	800038c2 <iunlockput>
    return 0;
    80004f34:	4a81                	li	s5,0
    80004f36:	b7d5                	j	80004f1a <create+0x5c>
    80004f38:	f052                	sd	s4,32(sp)
  if((ip = ialloc(dp->dev, type)) == 0){
    80004f3a:	85da                	mv	a1,s6
    80004f3c:	4088                	lw	a0,0(s1)
    80004f3e:	e0afe0ef          	jal	80003548 <ialloc>
    80004f42:	8a2a                	mv	s4,a0
    80004f44:	cd15                	beqz	a0,80004f80 <create+0xc2>
  ilock(ip);
    80004f46:	f72fe0ef          	jal	800036b8 <ilock>
  ip->major = major;
    80004f4a:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80004f4e:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80004f52:	4905                	li	s2,1
    80004f54:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80004f58:	8552                	mv	a0,s4
    80004f5a:	eaafe0ef          	jal	80003604 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004f5e:	032b0763          	beq	s6,s2,80004f8c <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004f62:	004a2603          	lw	a2,4(s4)
    80004f66:	fb040593          	addi	a1,s0,-80
    80004f6a:	8526                	mv	a0,s1
    80004f6c:	ec9fe0ef          	jal	80003e34 <dirlink>
    80004f70:	06054563          	bltz	a0,80004fda <create+0x11c>
  iunlockput(dp);
    80004f74:	8526                	mv	a0,s1
    80004f76:	94dfe0ef          	jal	800038c2 <iunlockput>
  return ip;
    80004f7a:	8ad2                	mv	s5,s4
    80004f7c:	7a02                	ld	s4,32(sp)
    80004f7e:	bf71                	j	80004f1a <create+0x5c>
    iunlockput(dp);
    80004f80:	8526                	mv	a0,s1
    80004f82:	941fe0ef          	jal	800038c2 <iunlockput>
    return 0;
    80004f86:	8ad2                	mv	s5,s4
    80004f88:	7a02                	ld	s4,32(sp)
    80004f8a:	bf41                	j	80004f1a <create+0x5c>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004f8c:	004a2603          	lw	a2,4(s4)
    80004f90:	00002597          	auipc	a1,0x2
    80004f94:	6a058593          	addi	a1,a1,1696 # 80007630 <etext+0x630>
    80004f98:	8552                	mv	a0,s4
    80004f9a:	e9bfe0ef          	jal	80003e34 <dirlink>
    80004f9e:	02054e63          	bltz	a0,80004fda <create+0x11c>
    80004fa2:	40d0                	lw	a2,4(s1)
    80004fa4:	00002597          	auipc	a1,0x2
    80004fa8:	69458593          	addi	a1,a1,1684 # 80007638 <etext+0x638>
    80004fac:	8552                	mv	a0,s4
    80004fae:	e87fe0ef          	jal	80003e34 <dirlink>
    80004fb2:	02054463          	bltz	a0,80004fda <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80004fb6:	004a2603          	lw	a2,4(s4)
    80004fba:	fb040593          	addi	a1,s0,-80
    80004fbe:	8526                	mv	a0,s1
    80004fc0:	e75fe0ef          	jal	80003e34 <dirlink>
    80004fc4:	00054b63          	bltz	a0,80004fda <create+0x11c>
    dp->nlink++;  // for ".."
    80004fc8:	04a4d783          	lhu	a5,74(s1)
    80004fcc:	2785                	addiw	a5,a5,1
    80004fce:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004fd2:	8526                	mv	a0,s1
    80004fd4:	e30fe0ef          	jal	80003604 <iupdate>
    80004fd8:	bf71                	j	80004f74 <create+0xb6>
  ip->nlink = 0;
    80004fda:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80004fde:	8552                	mv	a0,s4
    80004fe0:	e24fe0ef          	jal	80003604 <iupdate>
  iunlockput(ip);
    80004fe4:	8552                	mv	a0,s4
    80004fe6:	8ddfe0ef          	jal	800038c2 <iunlockput>
  iunlockput(dp);
    80004fea:	8526                	mv	a0,s1
    80004fec:	8d7fe0ef          	jal	800038c2 <iunlockput>
  return 0;
    80004ff0:	7a02                	ld	s4,32(sp)
    80004ff2:	b725                	j	80004f1a <create+0x5c>
    return 0;
    80004ff4:	8aaa                	mv	s5,a0
    80004ff6:	b715                	j	80004f1a <create+0x5c>

0000000080004ff8 <sys_dup>:
{
    80004ff8:	7179                	addi	sp,sp,-48
    80004ffa:	f406                	sd	ra,40(sp)
    80004ffc:	f022                	sd	s0,32(sp)
    80004ffe:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80005000:	fd840613          	addi	a2,s0,-40
    80005004:	4581                	li	a1,0
    80005006:	4501                	li	a0,0
    80005008:	e21ff0ef          	jal	80004e28 <argfd>
    return -1;
    8000500c:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    8000500e:	02054363          	bltz	a0,80005034 <sys_dup+0x3c>
    80005012:	ec26                	sd	s1,24(sp)
    80005014:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80005016:	fd843903          	ld	s2,-40(s0)
    8000501a:	854a                	mv	a0,s2
    8000501c:	e65ff0ef          	jal	80004e80 <fdalloc>
    80005020:	84aa                	mv	s1,a0
    return -1;
    80005022:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80005024:	00054d63          	bltz	a0,8000503e <sys_dup+0x46>
  filedup(f);
    80005028:	854a                	mv	a0,s2
    8000502a:	c3eff0ef          	jal	80004468 <filedup>
  return fd;
    8000502e:	87a6                	mv	a5,s1
    80005030:	64e2                	ld	s1,24(sp)
    80005032:	6942                	ld	s2,16(sp)
}
    80005034:	853e                	mv	a0,a5
    80005036:	70a2                	ld	ra,40(sp)
    80005038:	7402                	ld	s0,32(sp)
    8000503a:	6145                	addi	sp,sp,48
    8000503c:	8082                	ret
    8000503e:	64e2                	ld	s1,24(sp)
    80005040:	6942                	ld	s2,16(sp)
    80005042:	bfcd                	j	80005034 <sys_dup+0x3c>

0000000080005044 <sys_read>:
{
    80005044:	7179                	addi	sp,sp,-48
    80005046:	f406                	sd	ra,40(sp)
    80005048:	f022                	sd	s0,32(sp)
    8000504a:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    8000504c:	fd840593          	addi	a1,s0,-40
    80005050:	4505                	li	a0,1
    80005052:	bd1fd0ef          	jal	80002c22 <argaddr>
  argint(2, &n);
    80005056:	fe440593          	addi	a1,s0,-28
    8000505a:	4509                	li	a0,2
    8000505c:	babfd0ef          	jal	80002c06 <argint>
  if(argfd(0, 0, &f) < 0)
    80005060:	fe840613          	addi	a2,s0,-24
    80005064:	4581                	li	a1,0
    80005066:	4501                	li	a0,0
    80005068:	dc1ff0ef          	jal	80004e28 <argfd>
    8000506c:	87aa                	mv	a5,a0
    return -1;
    8000506e:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80005070:	0007ca63          	bltz	a5,80005084 <sys_read+0x40>
  return fileread(f, p, n);
    80005074:	fe442603          	lw	a2,-28(s0)
    80005078:	fd843583          	ld	a1,-40(s0)
    8000507c:	fe843503          	ld	a0,-24(s0)
    80005080:	d4eff0ef          	jal	800045ce <fileread>
}
    80005084:	70a2                	ld	ra,40(sp)
    80005086:	7402                	ld	s0,32(sp)
    80005088:	6145                	addi	sp,sp,48
    8000508a:	8082                	ret

000000008000508c <sys_write>:
{
    8000508c:	7179                	addi	sp,sp,-48
    8000508e:	f406                	sd	ra,40(sp)
    80005090:	f022                	sd	s0,32(sp)
    80005092:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80005094:	fd840593          	addi	a1,s0,-40
    80005098:	4505                	li	a0,1
    8000509a:	b89fd0ef          	jal	80002c22 <argaddr>
  argint(2, &n);
    8000509e:	fe440593          	addi	a1,s0,-28
    800050a2:	4509                	li	a0,2
    800050a4:	b63fd0ef          	jal	80002c06 <argint>
  if(argfd(0, 0, &f) < 0)
    800050a8:	fe840613          	addi	a2,s0,-24
    800050ac:	4581                	li	a1,0
    800050ae:	4501                	li	a0,0
    800050b0:	d79ff0ef          	jal	80004e28 <argfd>
    800050b4:	87aa                	mv	a5,a0
    return -1;
    800050b6:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800050b8:	0007ca63          	bltz	a5,800050cc <sys_write+0x40>
  return filewrite(f, p, n);
    800050bc:	fe442603          	lw	a2,-28(s0)
    800050c0:	fd843583          	ld	a1,-40(s0)
    800050c4:	fe843503          	ld	a0,-24(s0)
    800050c8:	dc4ff0ef          	jal	8000468c <filewrite>
}
    800050cc:	70a2                	ld	ra,40(sp)
    800050ce:	7402                	ld	s0,32(sp)
    800050d0:	6145                	addi	sp,sp,48
    800050d2:	8082                	ret

00000000800050d4 <sys_close>:
{
    800050d4:	1101                	addi	sp,sp,-32
    800050d6:	ec06                	sd	ra,24(sp)
    800050d8:	e822                	sd	s0,16(sp)
    800050da:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    800050dc:	fe040613          	addi	a2,s0,-32
    800050e0:	fec40593          	addi	a1,s0,-20
    800050e4:	4501                	li	a0,0
    800050e6:	d43ff0ef          	jal	80004e28 <argfd>
    return -1;
    800050ea:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    800050ec:	02054063          	bltz	a0,8000510c <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    800050f0:	821fc0ef          	jal	80001910 <myproc>
    800050f4:	fec42783          	lw	a5,-20(s0)
    800050f8:	07e9                	addi	a5,a5,26
    800050fa:	078e                	slli	a5,a5,0x3
    800050fc:	953e                	add	a0,a0,a5
    800050fe:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80005102:	fe043503          	ld	a0,-32(s0)
    80005106:	ba8ff0ef          	jal	800044ae <fileclose>
  return 0;
    8000510a:	4781                	li	a5,0
}
    8000510c:	853e                	mv	a0,a5
    8000510e:	60e2                	ld	ra,24(sp)
    80005110:	6442                	ld	s0,16(sp)
    80005112:	6105                	addi	sp,sp,32
    80005114:	8082                	ret

0000000080005116 <sys_fstat>:
{
    80005116:	1101                	addi	sp,sp,-32
    80005118:	ec06                	sd	ra,24(sp)
    8000511a:	e822                	sd	s0,16(sp)
    8000511c:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    8000511e:	fe040593          	addi	a1,s0,-32
    80005122:	4505                	li	a0,1
    80005124:	afffd0ef          	jal	80002c22 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80005128:	fe840613          	addi	a2,s0,-24
    8000512c:	4581                	li	a1,0
    8000512e:	4501                	li	a0,0
    80005130:	cf9ff0ef          	jal	80004e28 <argfd>
    80005134:	87aa                	mv	a5,a0
    return -1;
    80005136:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80005138:	0007c863          	bltz	a5,80005148 <sys_fstat+0x32>
  return filestat(f, st);
    8000513c:	fe043583          	ld	a1,-32(s0)
    80005140:	fe843503          	ld	a0,-24(s0)
    80005144:	c2cff0ef          	jal	80004570 <filestat>
}
    80005148:	60e2                	ld	ra,24(sp)
    8000514a:	6442                	ld	s0,16(sp)
    8000514c:	6105                	addi	sp,sp,32
    8000514e:	8082                	ret

0000000080005150 <sys_link>:
{
    80005150:	7169                	addi	sp,sp,-304
    80005152:	f606                	sd	ra,296(sp)
    80005154:	f222                	sd	s0,288(sp)
    80005156:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005158:	08000613          	li	a2,128
    8000515c:	ed040593          	addi	a1,s0,-304
    80005160:	4501                	li	a0,0
    80005162:	addfd0ef          	jal	80002c3e <argstr>
    return -1;
    80005166:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005168:	0c054e63          	bltz	a0,80005244 <sys_link+0xf4>
    8000516c:	08000613          	li	a2,128
    80005170:	f5040593          	addi	a1,s0,-176
    80005174:	4505                	li	a0,1
    80005176:	ac9fd0ef          	jal	80002c3e <argstr>
    return -1;
    8000517a:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000517c:	0c054463          	bltz	a0,80005244 <sys_link+0xf4>
    80005180:	ee26                	sd	s1,280(sp)
  begin_op();
    80005182:	f21fe0ef          	jal	800040a2 <begin_op>
  if((ip = namei(old)) == 0){
    80005186:	ed040513          	addi	a0,s0,-304
    8000518a:	d45fe0ef          	jal	80003ece <namei>
    8000518e:	84aa                	mv	s1,a0
    80005190:	c53d                	beqz	a0,800051fe <sys_link+0xae>
  ilock(ip);
    80005192:	d26fe0ef          	jal	800036b8 <ilock>
  if(ip->type == T_DIR){
    80005196:	04449703          	lh	a4,68(s1)
    8000519a:	4785                	li	a5,1
    8000519c:	06f70663          	beq	a4,a5,80005208 <sys_link+0xb8>
    800051a0:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    800051a2:	04a4d783          	lhu	a5,74(s1)
    800051a6:	2785                	addiw	a5,a5,1
    800051a8:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800051ac:	8526                	mv	a0,s1
    800051ae:	c56fe0ef          	jal	80003604 <iupdate>
  iunlock(ip);
    800051b2:	8526                	mv	a0,s1
    800051b4:	db2fe0ef          	jal	80003766 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    800051b8:	fd040593          	addi	a1,s0,-48
    800051bc:	f5040513          	addi	a0,s0,-176
    800051c0:	d29fe0ef          	jal	80003ee8 <nameiparent>
    800051c4:	892a                	mv	s2,a0
    800051c6:	cd21                	beqz	a0,8000521e <sys_link+0xce>
  ilock(dp);
    800051c8:	cf0fe0ef          	jal	800036b8 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    800051cc:	00092703          	lw	a4,0(s2)
    800051d0:	409c                	lw	a5,0(s1)
    800051d2:	04f71363          	bne	a4,a5,80005218 <sys_link+0xc8>
    800051d6:	40d0                	lw	a2,4(s1)
    800051d8:	fd040593          	addi	a1,s0,-48
    800051dc:	854a                	mv	a0,s2
    800051de:	c57fe0ef          	jal	80003e34 <dirlink>
    800051e2:	02054b63          	bltz	a0,80005218 <sys_link+0xc8>
  iunlockput(dp);
    800051e6:	854a                	mv	a0,s2
    800051e8:	edafe0ef          	jal	800038c2 <iunlockput>
  iput(ip);
    800051ec:	8526                	mv	a0,s1
    800051ee:	e4cfe0ef          	jal	8000383a <iput>
  end_op();
    800051f2:	f1bfe0ef          	jal	8000410c <end_op>
  return 0;
    800051f6:	4781                	li	a5,0
    800051f8:	64f2                	ld	s1,280(sp)
    800051fa:	6952                	ld	s2,272(sp)
    800051fc:	a0a1                	j	80005244 <sys_link+0xf4>
    end_op();
    800051fe:	f0ffe0ef          	jal	8000410c <end_op>
    return -1;
    80005202:	57fd                	li	a5,-1
    80005204:	64f2                	ld	s1,280(sp)
    80005206:	a83d                	j	80005244 <sys_link+0xf4>
    iunlockput(ip);
    80005208:	8526                	mv	a0,s1
    8000520a:	eb8fe0ef          	jal	800038c2 <iunlockput>
    end_op();
    8000520e:	efffe0ef          	jal	8000410c <end_op>
    return -1;
    80005212:	57fd                	li	a5,-1
    80005214:	64f2                	ld	s1,280(sp)
    80005216:	a03d                	j	80005244 <sys_link+0xf4>
    iunlockput(dp);
    80005218:	854a                	mv	a0,s2
    8000521a:	ea8fe0ef          	jal	800038c2 <iunlockput>
  ilock(ip);
    8000521e:	8526                	mv	a0,s1
    80005220:	c98fe0ef          	jal	800036b8 <ilock>
  ip->nlink--;
    80005224:	04a4d783          	lhu	a5,74(s1)
    80005228:	37fd                	addiw	a5,a5,-1
    8000522a:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    8000522e:	8526                	mv	a0,s1
    80005230:	bd4fe0ef          	jal	80003604 <iupdate>
  iunlockput(ip);
    80005234:	8526                	mv	a0,s1
    80005236:	e8cfe0ef          	jal	800038c2 <iunlockput>
  end_op();
    8000523a:	ed3fe0ef          	jal	8000410c <end_op>
  return -1;
    8000523e:	57fd                	li	a5,-1
    80005240:	64f2                	ld	s1,280(sp)
    80005242:	6952                	ld	s2,272(sp)
}
    80005244:	853e                	mv	a0,a5
    80005246:	70b2                	ld	ra,296(sp)
    80005248:	7412                	ld	s0,288(sp)
    8000524a:	6155                	addi	sp,sp,304
    8000524c:	8082                	ret

000000008000524e <sys_unlink>:
{
    8000524e:	7151                	addi	sp,sp,-240
    80005250:	f586                	sd	ra,232(sp)
    80005252:	f1a2                	sd	s0,224(sp)
    80005254:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80005256:	08000613          	li	a2,128
    8000525a:	f3040593          	addi	a1,s0,-208
    8000525e:	4501                	li	a0,0
    80005260:	9dffd0ef          	jal	80002c3e <argstr>
    80005264:	16054063          	bltz	a0,800053c4 <sys_unlink+0x176>
    80005268:	eda6                	sd	s1,216(sp)
  begin_op();
    8000526a:	e39fe0ef          	jal	800040a2 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    8000526e:	fb040593          	addi	a1,s0,-80
    80005272:	f3040513          	addi	a0,s0,-208
    80005276:	c73fe0ef          	jal	80003ee8 <nameiparent>
    8000527a:	84aa                	mv	s1,a0
    8000527c:	c945                	beqz	a0,8000532c <sys_unlink+0xde>
  ilock(dp);
    8000527e:	c3afe0ef          	jal	800036b8 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80005282:	00002597          	auipc	a1,0x2
    80005286:	3ae58593          	addi	a1,a1,942 # 80007630 <etext+0x630>
    8000528a:	fb040513          	addi	a0,s0,-80
    8000528e:	9c5fe0ef          	jal	80003c52 <namecmp>
    80005292:	10050e63          	beqz	a0,800053ae <sys_unlink+0x160>
    80005296:	00002597          	auipc	a1,0x2
    8000529a:	3a258593          	addi	a1,a1,930 # 80007638 <etext+0x638>
    8000529e:	fb040513          	addi	a0,s0,-80
    800052a2:	9b1fe0ef          	jal	80003c52 <namecmp>
    800052a6:	10050463          	beqz	a0,800053ae <sys_unlink+0x160>
    800052aa:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    800052ac:	f2c40613          	addi	a2,s0,-212
    800052b0:	fb040593          	addi	a1,s0,-80
    800052b4:	8526                	mv	a0,s1
    800052b6:	9b3fe0ef          	jal	80003c68 <dirlookup>
    800052ba:	892a                	mv	s2,a0
    800052bc:	0e050863          	beqz	a0,800053ac <sys_unlink+0x15e>
  ilock(ip);
    800052c0:	bf8fe0ef          	jal	800036b8 <ilock>
  if(ip->nlink < 1)
    800052c4:	04a91783          	lh	a5,74(s2)
    800052c8:	06f05763          	blez	a5,80005336 <sys_unlink+0xe8>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800052cc:	04491703          	lh	a4,68(s2)
    800052d0:	4785                	li	a5,1
    800052d2:	06f70963          	beq	a4,a5,80005344 <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    800052d6:	4641                	li	a2,16
    800052d8:	4581                	li	a1,0
    800052da:	fc040513          	addi	a0,s0,-64
    800052de:	a07fb0ef          	jal	80000ce4 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800052e2:	4741                	li	a4,16
    800052e4:	f2c42683          	lw	a3,-212(s0)
    800052e8:	fc040613          	addi	a2,s0,-64
    800052ec:	4581                	li	a1,0
    800052ee:	8526                	mv	a0,s1
    800052f0:	855fe0ef          	jal	80003b44 <writei>
    800052f4:	47c1                	li	a5,16
    800052f6:	08f51b63          	bne	a0,a5,8000538c <sys_unlink+0x13e>
  if(ip->type == T_DIR){
    800052fa:	04491703          	lh	a4,68(s2)
    800052fe:	4785                	li	a5,1
    80005300:	08f70d63          	beq	a4,a5,8000539a <sys_unlink+0x14c>
  iunlockput(dp);
    80005304:	8526                	mv	a0,s1
    80005306:	dbcfe0ef          	jal	800038c2 <iunlockput>
  ip->nlink--;
    8000530a:	04a95783          	lhu	a5,74(s2)
    8000530e:	37fd                	addiw	a5,a5,-1
    80005310:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80005314:	854a                	mv	a0,s2
    80005316:	aeefe0ef          	jal	80003604 <iupdate>
  iunlockput(ip);
    8000531a:	854a                	mv	a0,s2
    8000531c:	da6fe0ef          	jal	800038c2 <iunlockput>
  end_op();
    80005320:	dedfe0ef          	jal	8000410c <end_op>
  return 0;
    80005324:	4501                	li	a0,0
    80005326:	64ee                	ld	s1,216(sp)
    80005328:	694e                	ld	s2,208(sp)
    8000532a:	a849                	j	800053bc <sys_unlink+0x16e>
    end_op();
    8000532c:	de1fe0ef          	jal	8000410c <end_op>
    return -1;
    80005330:	557d                	li	a0,-1
    80005332:	64ee                	ld	s1,216(sp)
    80005334:	a061                	j	800053bc <sys_unlink+0x16e>
    80005336:	e5ce                	sd	s3,200(sp)
    panic("unlink: nlink < 1");
    80005338:	00002517          	auipc	a0,0x2
    8000533c:	30850513          	addi	a0,a0,776 # 80007640 <etext+0x640>
    80005340:	ca0fb0ef          	jal	800007e0 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005344:	04c92703          	lw	a4,76(s2)
    80005348:	02000793          	li	a5,32
    8000534c:	f8e7f5e3          	bgeu	a5,a4,800052d6 <sys_unlink+0x88>
    80005350:	e5ce                	sd	s3,200(sp)
    80005352:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005356:	4741                	li	a4,16
    80005358:	86ce                	mv	a3,s3
    8000535a:	f1840613          	addi	a2,s0,-232
    8000535e:	4581                	li	a1,0
    80005360:	854a                	mv	a0,s2
    80005362:	ee6fe0ef          	jal	80003a48 <readi>
    80005366:	47c1                	li	a5,16
    80005368:	00f51c63          	bne	a0,a5,80005380 <sys_unlink+0x132>
    if(de.inum != 0)
    8000536c:	f1845783          	lhu	a5,-232(s0)
    80005370:	efa1                	bnez	a5,800053c8 <sys_unlink+0x17a>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005372:	29c1                	addiw	s3,s3,16
    80005374:	04c92783          	lw	a5,76(s2)
    80005378:	fcf9efe3          	bltu	s3,a5,80005356 <sys_unlink+0x108>
    8000537c:	69ae                	ld	s3,200(sp)
    8000537e:	bfa1                	j	800052d6 <sys_unlink+0x88>
      panic("isdirempty: readi");
    80005380:	00002517          	auipc	a0,0x2
    80005384:	2d850513          	addi	a0,a0,728 # 80007658 <etext+0x658>
    80005388:	c58fb0ef          	jal	800007e0 <panic>
    8000538c:	e5ce                	sd	s3,200(sp)
    panic("unlink: writei");
    8000538e:	00002517          	auipc	a0,0x2
    80005392:	2e250513          	addi	a0,a0,738 # 80007670 <etext+0x670>
    80005396:	c4afb0ef          	jal	800007e0 <panic>
    dp->nlink--;
    8000539a:	04a4d783          	lhu	a5,74(s1)
    8000539e:	37fd                	addiw	a5,a5,-1
    800053a0:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800053a4:	8526                	mv	a0,s1
    800053a6:	a5efe0ef          	jal	80003604 <iupdate>
    800053aa:	bfa9                	j	80005304 <sys_unlink+0xb6>
    800053ac:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800053ae:	8526                	mv	a0,s1
    800053b0:	d12fe0ef          	jal	800038c2 <iunlockput>
  end_op();
    800053b4:	d59fe0ef          	jal	8000410c <end_op>
  return -1;
    800053b8:	557d                	li	a0,-1
    800053ba:	64ee                	ld	s1,216(sp)
}
    800053bc:	70ae                	ld	ra,232(sp)
    800053be:	740e                	ld	s0,224(sp)
    800053c0:	616d                	addi	sp,sp,240
    800053c2:	8082                	ret
    return -1;
    800053c4:	557d                	li	a0,-1
    800053c6:	bfdd                	j	800053bc <sys_unlink+0x16e>
    iunlockput(ip);
    800053c8:	854a                	mv	a0,s2
    800053ca:	cf8fe0ef          	jal	800038c2 <iunlockput>
    goto bad;
    800053ce:	694e                	ld	s2,208(sp)
    800053d0:	69ae                	ld	s3,200(sp)
    800053d2:	bff1                	j	800053ae <sys_unlink+0x160>

00000000800053d4 <sys_open>:

uint64
sys_open(void)
{
    800053d4:	7131                	addi	sp,sp,-192
    800053d6:	fd06                	sd	ra,184(sp)
    800053d8:	f922                	sd	s0,176(sp)
    800053da:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800053dc:	f4c40593          	addi	a1,s0,-180
    800053e0:	4505                	li	a0,1
    800053e2:	825fd0ef          	jal	80002c06 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800053e6:	08000613          	li	a2,128
    800053ea:	f5040593          	addi	a1,s0,-176
    800053ee:	4501                	li	a0,0
    800053f0:	84ffd0ef          	jal	80002c3e <argstr>
    800053f4:	87aa                	mv	a5,a0
    return -1;
    800053f6:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    800053f8:	0a07c263          	bltz	a5,8000549c <sys_open+0xc8>
    800053fc:	f526                	sd	s1,168(sp)

  begin_op();
    800053fe:	ca5fe0ef          	jal	800040a2 <begin_op>

  if(omode & O_CREATE){
    80005402:	f4c42783          	lw	a5,-180(s0)
    80005406:	2007f793          	andi	a5,a5,512
    8000540a:	c3d5                	beqz	a5,800054ae <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    8000540c:	4681                	li	a3,0
    8000540e:	4601                	li	a2,0
    80005410:	4589                	li	a1,2
    80005412:	f5040513          	addi	a0,s0,-176
    80005416:	aa9ff0ef          	jal	80004ebe <create>
    8000541a:	84aa                	mv	s1,a0
    if(ip == 0){
    8000541c:	c541                	beqz	a0,800054a4 <sys_open+0xd0>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    8000541e:	04449703          	lh	a4,68(s1)
    80005422:	478d                	li	a5,3
    80005424:	00f71763          	bne	a4,a5,80005432 <sys_open+0x5e>
    80005428:	0464d703          	lhu	a4,70(s1)
    8000542c:	47a5                	li	a5,9
    8000542e:	0ae7ed63          	bltu	a5,a4,800054e8 <sys_open+0x114>
    80005432:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80005434:	fd7fe0ef          	jal	8000440a <filealloc>
    80005438:	892a                	mv	s2,a0
    8000543a:	c179                	beqz	a0,80005500 <sys_open+0x12c>
    8000543c:	ed4e                	sd	s3,152(sp)
    8000543e:	a43ff0ef          	jal	80004e80 <fdalloc>
    80005442:	89aa                	mv	s3,a0
    80005444:	0a054a63          	bltz	a0,800054f8 <sys_open+0x124>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80005448:	04449703          	lh	a4,68(s1)
    8000544c:	478d                	li	a5,3
    8000544e:	0cf70263          	beq	a4,a5,80005512 <sys_open+0x13e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005452:	4789                	li	a5,2
    80005454:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80005458:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    8000545c:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80005460:	f4c42783          	lw	a5,-180(s0)
    80005464:	0017c713          	xori	a4,a5,1
    80005468:	8b05                	andi	a4,a4,1
    8000546a:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000546e:	0037f713          	andi	a4,a5,3
    80005472:	00e03733          	snez	a4,a4
    80005476:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    8000547a:	4007f793          	andi	a5,a5,1024
    8000547e:	c791                	beqz	a5,8000548a <sys_open+0xb6>
    80005480:	04449703          	lh	a4,68(s1)
    80005484:	4789                	li	a5,2
    80005486:	08f70d63          	beq	a4,a5,80005520 <sys_open+0x14c>
    itrunc(ip);
  }

  iunlock(ip);
    8000548a:	8526                	mv	a0,s1
    8000548c:	adafe0ef          	jal	80003766 <iunlock>
  end_op();
    80005490:	c7dfe0ef          	jal	8000410c <end_op>

  return fd;
    80005494:	854e                	mv	a0,s3
    80005496:	74aa                	ld	s1,168(sp)
    80005498:	790a                	ld	s2,160(sp)
    8000549a:	69ea                	ld	s3,152(sp)
}
    8000549c:	70ea                	ld	ra,184(sp)
    8000549e:	744a                	ld	s0,176(sp)
    800054a0:	6129                	addi	sp,sp,192
    800054a2:	8082                	ret
      end_op();
    800054a4:	c69fe0ef          	jal	8000410c <end_op>
      return -1;
    800054a8:	557d                	li	a0,-1
    800054aa:	74aa                	ld	s1,168(sp)
    800054ac:	bfc5                	j	8000549c <sys_open+0xc8>
    if((ip = namei(path)) == 0){
    800054ae:	f5040513          	addi	a0,s0,-176
    800054b2:	a1dfe0ef          	jal	80003ece <namei>
    800054b6:	84aa                	mv	s1,a0
    800054b8:	c11d                	beqz	a0,800054de <sys_open+0x10a>
    ilock(ip);
    800054ba:	9fefe0ef          	jal	800036b8 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800054be:	04449703          	lh	a4,68(s1)
    800054c2:	4785                	li	a5,1
    800054c4:	f4f71de3          	bne	a4,a5,8000541e <sys_open+0x4a>
    800054c8:	f4c42783          	lw	a5,-180(s0)
    800054cc:	d3bd                	beqz	a5,80005432 <sys_open+0x5e>
      iunlockput(ip);
    800054ce:	8526                	mv	a0,s1
    800054d0:	bf2fe0ef          	jal	800038c2 <iunlockput>
      end_op();
    800054d4:	c39fe0ef          	jal	8000410c <end_op>
      return -1;
    800054d8:	557d                	li	a0,-1
    800054da:	74aa                	ld	s1,168(sp)
    800054dc:	b7c1                	j	8000549c <sys_open+0xc8>
      end_op();
    800054de:	c2ffe0ef          	jal	8000410c <end_op>
      return -1;
    800054e2:	557d                	li	a0,-1
    800054e4:	74aa                	ld	s1,168(sp)
    800054e6:	bf5d                	j	8000549c <sys_open+0xc8>
    iunlockput(ip);
    800054e8:	8526                	mv	a0,s1
    800054ea:	bd8fe0ef          	jal	800038c2 <iunlockput>
    end_op();
    800054ee:	c1ffe0ef          	jal	8000410c <end_op>
    return -1;
    800054f2:	557d                	li	a0,-1
    800054f4:	74aa                	ld	s1,168(sp)
    800054f6:	b75d                	j	8000549c <sys_open+0xc8>
      fileclose(f);
    800054f8:	854a                	mv	a0,s2
    800054fa:	fb5fe0ef          	jal	800044ae <fileclose>
    800054fe:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80005500:	8526                	mv	a0,s1
    80005502:	bc0fe0ef          	jal	800038c2 <iunlockput>
    end_op();
    80005506:	c07fe0ef          	jal	8000410c <end_op>
    return -1;
    8000550a:	557d                	li	a0,-1
    8000550c:	74aa                	ld	s1,168(sp)
    8000550e:	790a                	ld	s2,160(sp)
    80005510:	b771                	j	8000549c <sys_open+0xc8>
    f->type = FD_DEVICE;
    80005512:	00f92023          	sw	a5,0(s2)
    f->major = ip->major;
    80005516:	04649783          	lh	a5,70(s1)
    8000551a:	02f91223          	sh	a5,36(s2)
    8000551e:	bf3d                	j	8000545c <sys_open+0x88>
    itrunc(ip);
    80005520:	8526                	mv	a0,s1
    80005522:	a84fe0ef          	jal	800037a6 <itrunc>
    80005526:	b795                	j	8000548a <sys_open+0xb6>

0000000080005528 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005528:	7175                	addi	sp,sp,-144
    8000552a:	e506                	sd	ra,136(sp)
    8000552c:	e122                	sd	s0,128(sp)
    8000552e:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005530:	b73fe0ef          	jal	800040a2 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80005534:	08000613          	li	a2,128
    80005538:	f7040593          	addi	a1,s0,-144
    8000553c:	4501                	li	a0,0
    8000553e:	f00fd0ef          	jal	80002c3e <argstr>
    80005542:	02054363          	bltz	a0,80005568 <sys_mkdir+0x40>
    80005546:	4681                	li	a3,0
    80005548:	4601                	li	a2,0
    8000554a:	4585                	li	a1,1
    8000554c:	f7040513          	addi	a0,s0,-144
    80005550:	96fff0ef          	jal	80004ebe <create>
    80005554:	c911                	beqz	a0,80005568 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005556:	b6cfe0ef          	jal	800038c2 <iunlockput>
  end_op();
    8000555a:	bb3fe0ef          	jal	8000410c <end_op>
  return 0;
    8000555e:	4501                	li	a0,0
}
    80005560:	60aa                	ld	ra,136(sp)
    80005562:	640a                	ld	s0,128(sp)
    80005564:	6149                	addi	sp,sp,144
    80005566:	8082                	ret
    end_op();
    80005568:	ba5fe0ef          	jal	8000410c <end_op>
    return -1;
    8000556c:	557d                	li	a0,-1
    8000556e:	bfcd                	j	80005560 <sys_mkdir+0x38>

0000000080005570 <sys_mknod>:

uint64
sys_mknod(void)
{
    80005570:	7135                	addi	sp,sp,-160
    80005572:	ed06                	sd	ra,152(sp)
    80005574:	e922                	sd	s0,144(sp)
    80005576:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005578:	b2bfe0ef          	jal	800040a2 <begin_op>
  argint(1, &major);
    8000557c:	f6c40593          	addi	a1,s0,-148
    80005580:	4505                	li	a0,1
    80005582:	e84fd0ef          	jal	80002c06 <argint>
  argint(2, &minor);
    80005586:	f6840593          	addi	a1,s0,-152
    8000558a:	4509                	li	a0,2
    8000558c:	e7afd0ef          	jal	80002c06 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005590:	08000613          	li	a2,128
    80005594:	f7040593          	addi	a1,s0,-144
    80005598:	4501                	li	a0,0
    8000559a:	ea4fd0ef          	jal	80002c3e <argstr>
    8000559e:	02054563          	bltz	a0,800055c8 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    800055a2:	f6841683          	lh	a3,-152(s0)
    800055a6:	f6c41603          	lh	a2,-148(s0)
    800055aa:	458d                	li	a1,3
    800055ac:	f7040513          	addi	a0,s0,-144
    800055b0:	90fff0ef          	jal	80004ebe <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800055b4:	c911                	beqz	a0,800055c8 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800055b6:	b0cfe0ef          	jal	800038c2 <iunlockput>
  end_op();
    800055ba:	b53fe0ef          	jal	8000410c <end_op>
  return 0;
    800055be:	4501                	li	a0,0
}
    800055c0:	60ea                	ld	ra,152(sp)
    800055c2:	644a                	ld	s0,144(sp)
    800055c4:	610d                	addi	sp,sp,160
    800055c6:	8082                	ret
    end_op();
    800055c8:	b45fe0ef          	jal	8000410c <end_op>
    return -1;
    800055cc:	557d                	li	a0,-1
    800055ce:	bfcd                	j	800055c0 <sys_mknod+0x50>

00000000800055d0 <sys_chdir>:

uint64
sys_chdir(void)
{
    800055d0:	7135                	addi	sp,sp,-160
    800055d2:	ed06                	sd	ra,152(sp)
    800055d4:	e922                	sd	s0,144(sp)
    800055d6:	e14a                	sd	s2,128(sp)
    800055d8:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800055da:	b36fc0ef          	jal	80001910 <myproc>
    800055de:	892a                	mv	s2,a0
  
  begin_op();
    800055e0:	ac3fe0ef          	jal	800040a2 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800055e4:	08000613          	li	a2,128
    800055e8:	f6040593          	addi	a1,s0,-160
    800055ec:	4501                	li	a0,0
    800055ee:	e50fd0ef          	jal	80002c3e <argstr>
    800055f2:	04054363          	bltz	a0,80005638 <sys_chdir+0x68>
    800055f6:	e526                	sd	s1,136(sp)
    800055f8:	f6040513          	addi	a0,s0,-160
    800055fc:	8d3fe0ef          	jal	80003ece <namei>
    80005600:	84aa                	mv	s1,a0
    80005602:	c915                	beqz	a0,80005636 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80005604:	8b4fe0ef          	jal	800036b8 <ilock>
  if(ip->type != T_DIR){
    80005608:	04449703          	lh	a4,68(s1)
    8000560c:	4785                	li	a5,1
    8000560e:	02f71963          	bne	a4,a5,80005640 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80005612:	8526                	mv	a0,s1
    80005614:	952fe0ef          	jal	80003766 <iunlock>
  iput(p->cwd);
    80005618:	15093503          	ld	a0,336(s2)
    8000561c:	a1efe0ef          	jal	8000383a <iput>
  end_op();
    80005620:	aedfe0ef          	jal	8000410c <end_op>
  p->cwd = ip;
    80005624:	14993823          	sd	s1,336(s2)
  return 0;
    80005628:	4501                	li	a0,0
    8000562a:	64aa                	ld	s1,136(sp)
}
    8000562c:	60ea                	ld	ra,152(sp)
    8000562e:	644a                	ld	s0,144(sp)
    80005630:	690a                	ld	s2,128(sp)
    80005632:	610d                	addi	sp,sp,160
    80005634:	8082                	ret
    80005636:	64aa                	ld	s1,136(sp)
    end_op();
    80005638:	ad5fe0ef          	jal	8000410c <end_op>
    return -1;
    8000563c:	557d                	li	a0,-1
    8000563e:	b7fd                	j	8000562c <sys_chdir+0x5c>
    iunlockput(ip);
    80005640:	8526                	mv	a0,s1
    80005642:	a80fe0ef          	jal	800038c2 <iunlockput>
    end_op();
    80005646:	ac7fe0ef          	jal	8000410c <end_op>
    return -1;
    8000564a:	557d                	li	a0,-1
    8000564c:	64aa                	ld	s1,136(sp)
    8000564e:	bff9                	j	8000562c <sys_chdir+0x5c>

0000000080005650 <sys_exec>:

uint64
sys_exec(void)
{
    80005650:	7121                	addi	sp,sp,-448
    80005652:	ff06                	sd	ra,440(sp)
    80005654:	fb22                	sd	s0,432(sp)
    80005656:	0380                	addi	s0,sp,448
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005658:	e4840593          	addi	a1,s0,-440
    8000565c:	4505                	li	a0,1
    8000565e:	dc4fd0ef          	jal	80002c22 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005662:	08000613          	li	a2,128
    80005666:	f5040593          	addi	a1,s0,-176
    8000566a:	4501                	li	a0,0
    8000566c:	dd2fd0ef          	jal	80002c3e <argstr>
    80005670:	87aa                	mv	a5,a0
    return -1;
    80005672:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005674:	0c07c463          	bltz	a5,8000573c <sys_exec+0xec>
    80005678:	f726                	sd	s1,424(sp)
    8000567a:	f34a                	sd	s2,416(sp)
    8000567c:	ef4e                	sd	s3,408(sp)
    8000567e:	eb52                	sd	s4,400(sp)
  }
  memset(argv, 0, sizeof(argv));
    80005680:	10000613          	li	a2,256
    80005684:	4581                	li	a1,0
    80005686:	e5040513          	addi	a0,s0,-432
    8000568a:	e5afb0ef          	jal	80000ce4 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    8000568e:	e5040493          	addi	s1,s0,-432
  memset(argv, 0, sizeof(argv));
    80005692:	89a6                	mv	s3,s1
    80005694:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    80005696:	02000a13          	li	s4,32
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    8000569a:	00391513          	slli	a0,s2,0x3
    8000569e:	e4040593          	addi	a1,s0,-448
    800056a2:	e4843783          	ld	a5,-440(s0)
    800056a6:	953e                	add	a0,a0,a5
    800056a8:	cd4fd0ef          	jal	80002b7c <fetchaddr>
    800056ac:	02054663          	bltz	a0,800056d8 <sys_exec+0x88>
      goto bad;
    }
    if(uarg == 0){
    800056b0:	e4043783          	ld	a5,-448(s0)
    800056b4:	c3a9                	beqz	a5,800056f6 <sys_exec+0xa6>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    800056b6:	c48fb0ef          	jal	80000afe <kalloc>
    800056ba:	85aa                	mv	a1,a0
    800056bc:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800056c0:	cd01                	beqz	a0,800056d8 <sys_exec+0x88>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800056c2:	6605                	lui	a2,0x1
    800056c4:	e4043503          	ld	a0,-448(s0)
    800056c8:	cfefd0ef          	jal	80002bc6 <fetchstr>
    800056cc:	00054663          	bltz	a0,800056d8 <sys_exec+0x88>
    if(i >= NELEM(argv)){
    800056d0:	0905                	addi	s2,s2,1
    800056d2:	09a1                	addi	s3,s3,8
    800056d4:	fd4913e3          	bne	s2,s4,8000569a <sys_exec+0x4a>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800056d8:	f5040913          	addi	s2,s0,-176
    800056dc:	6088                	ld	a0,0(s1)
    800056de:	c931                	beqz	a0,80005732 <sys_exec+0xe2>
    kfree(argv[i]);
    800056e0:	b3cfb0ef          	jal	80000a1c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800056e4:	04a1                	addi	s1,s1,8
    800056e6:	ff249be3          	bne	s1,s2,800056dc <sys_exec+0x8c>
  return -1;
    800056ea:	557d                	li	a0,-1
    800056ec:	74ba                	ld	s1,424(sp)
    800056ee:	791a                	ld	s2,416(sp)
    800056f0:	69fa                	ld	s3,408(sp)
    800056f2:	6a5a                	ld	s4,400(sp)
    800056f4:	a0a1                	j	8000573c <sys_exec+0xec>
      argv[i] = 0;
    800056f6:	0009079b          	sext.w	a5,s2
    800056fa:	078e                	slli	a5,a5,0x3
    800056fc:	fd078793          	addi	a5,a5,-48
    80005700:	97a2                	add	a5,a5,s0
    80005702:	e807b023          	sd	zero,-384(a5)
  int ret = kexec(path, argv);
    80005706:	e5040593          	addi	a1,s0,-432
    8000570a:	f5040513          	addi	a0,s0,-176
    8000570e:	ba8ff0ef          	jal	80004ab6 <kexec>
    80005712:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005714:	f5040993          	addi	s3,s0,-176
    80005718:	6088                	ld	a0,0(s1)
    8000571a:	c511                	beqz	a0,80005726 <sys_exec+0xd6>
    kfree(argv[i]);
    8000571c:	b00fb0ef          	jal	80000a1c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005720:	04a1                	addi	s1,s1,8
    80005722:	ff349be3          	bne	s1,s3,80005718 <sys_exec+0xc8>
  return ret;
    80005726:	854a                	mv	a0,s2
    80005728:	74ba                	ld	s1,424(sp)
    8000572a:	791a                	ld	s2,416(sp)
    8000572c:	69fa                	ld	s3,408(sp)
    8000572e:	6a5a                	ld	s4,400(sp)
    80005730:	a031                	j	8000573c <sys_exec+0xec>
  return -1;
    80005732:	557d                	li	a0,-1
    80005734:	74ba                	ld	s1,424(sp)
    80005736:	791a                	ld	s2,416(sp)
    80005738:	69fa                	ld	s3,408(sp)
    8000573a:	6a5a                	ld	s4,400(sp)
}
    8000573c:	70fa                	ld	ra,440(sp)
    8000573e:	745a                	ld	s0,432(sp)
    80005740:	6139                	addi	sp,sp,448
    80005742:	8082                	ret

0000000080005744 <sys_pipe>:

uint64
sys_pipe(void)
{
    80005744:	7139                	addi	sp,sp,-64
    80005746:	fc06                	sd	ra,56(sp)
    80005748:	f822                	sd	s0,48(sp)
    8000574a:	f426                	sd	s1,40(sp)
    8000574c:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    8000574e:	9c2fc0ef          	jal	80001910 <myproc>
    80005752:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005754:	fd840593          	addi	a1,s0,-40
    80005758:	4501                	li	a0,0
    8000575a:	cc8fd0ef          	jal	80002c22 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    8000575e:	fc840593          	addi	a1,s0,-56
    80005762:	fd040513          	addi	a0,s0,-48
    80005766:	852ff0ef          	jal	800047b8 <pipealloc>
    return -1;
    8000576a:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    8000576c:	0a054463          	bltz	a0,80005814 <sys_pipe+0xd0>
  fd0 = -1;
    80005770:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80005774:	fd043503          	ld	a0,-48(s0)
    80005778:	f08ff0ef          	jal	80004e80 <fdalloc>
    8000577c:	fca42223          	sw	a0,-60(s0)
    80005780:	08054163          	bltz	a0,80005802 <sys_pipe+0xbe>
    80005784:	fc843503          	ld	a0,-56(s0)
    80005788:	ef8ff0ef          	jal	80004e80 <fdalloc>
    8000578c:	fca42023          	sw	a0,-64(s0)
    80005790:	06054063          	bltz	a0,800057f0 <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005794:	4691                	li	a3,4
    80005796:	fc440613          	addi	a2,s0,-60
    8000579a:	fd843583          	ld	a1,-40(s0)
    8000579e:	68a8                	ld	a0,80(s1)
    800057a0:	e85fb0ef          	jal	80001624 <copyout>
    800057a4:	00054e63          	bltz	a0,800057c0 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    800057a8:	4691                	li	a3,4
    800057aa:	fc040613          	addi	a2,s0,-64
    800057ae:	fd843583          	ld	a1,-40(s0)
    800057b2:	0591                	addi	a1,a1,4
    800057b4:	68a8                	ld	a0,80(s1)
    800057b6:	e6ffb0ef          	jal	80001624 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800057ba:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800057bc:	04055c63          	bgez	a0,80005814 <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    800057c0:	fc442783          	lw	a5,-60(s0)
    800057c4:	07e9                	addi	a5,a5,26
    800057c6:	078e                	slli	a5,a5,0x3
    800057c8:	97a6                	add	a5,a5,s1
    800057ca:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800057ce:	fc042783          	lw	a5,-64(s0)
    800057d2:	07e9                	addi	a5,a5,26
    800057d4:	078e                	slli	a5,a5,0x3
    800057d6:	94be                	add	s1,s1,a5
    800057d8:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    800057dc:	fd043503          	ld	a0,-48(s0)
    800057e0:	ccffe0ef          	jal	800044ae <fileclose>
    fileclose(wf);
    800057e4:	fc843503          	ld	a0,-56(s0)
    800057e8:	cc7fe0ef          	jal	800044ae <fileclose>
    return -1;
    800057ec:	57fd                	li	a5,-1
    800057ee:	a01d                	j	80005814 <sys_pipe+0xd0>
    if(fd0 >= 0)
    800057f0:	fc442783          	lw	a5,-60(s0)
    800057f4:	0007c763          	bltz	a5,80005802 <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    800057f8:	07e9                	addi	a5,a5,26
    800057fa:	078e                	slli	a5,a5,0x3
    800057fc:	97a6                	add	a5,a5,s1
    800057fe:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005802:	fd043503          	ld	a0,-48(s0)
    80005806:	ca9fe0ef          	jal	800044ae <fileclose>
    fileclose(wf);
    8000580a:	fc843503          	ld	a0,-56(s0)
    8000580e:	ca1fe0ef          	jal	800044ae <fileclose>
    return -1;
    80005812:	57fd                	li	a5,-1
}
    80005814:	853e                	mv	a0,a5
    80005816:	70e2                	ld	ra,56(sp)
    80005818:	7442                	ld	s0,48(sp)
    8000581a:	74a2                	ld	s1,40(sp)
    8000581c:	6121                	addi	sp,sp,64
    8000581e:	8082                	ret

0000000080005820 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005820:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005822:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005824:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    80005826:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    80005828:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    8000582a:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000582c:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000582e:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005830:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005832:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005834:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005836:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005838:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    8000583a:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000583c:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000583e:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    80005840:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005842:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005844:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005846:	a46fd0ef          	jal	80002a8c <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    8000584a:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000584c:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000584e:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    80005850:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005852:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005854:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005856:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005858:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    8000585a:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000585c:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000585e:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    80005860:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005862:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005864:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005866:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005868:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    8000586a:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000586c:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000586e:	10200073          	sret
	...

000000008000587e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000587e:	1141                	addi	sp,sp,-16
    80005880:	e422                	sd	s0,8(sp)
    80005882:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005884:	0c0007b7          	lui	a5,0xc000
    80005888:	4705                	li	a4,1
    8000588a:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000588c:	0c0007b7          	lui	a5,0xc000
    80005890:	c3d8                	sw	a4,4(a5)
}
    80005892:	6422                	ld	s0,8(sp)
    80005894:	0141                	addi	sp,sp,16
    80005896:	8082                	ret

0000000080005898 <plicinithart>:

void
plicinithart(void)
{
    80005898:	1141                	addi	sp,sp,-16
    8000589a:	e406                	sd	ra,8(sp)
    8000589c:	e022                	sd	s0,0(sp)
    8000589e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800058a0:	844fc0ef          	jal	800018e4 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800058a4:	0085171b          	slliw	a4,a0,0x8
    800058a8:	0c0027b7          	lui	a5,0xc002
    800058ac:	97ba                	add	a5,a5,a4
    800058ae:	40200713          	li	a4,1026
    800058b2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800058b6:	00d5151b          	slliw	a0,a0,0xd
    800058ba:	0c2017b7          	lui	a5,0xc201
    800058be:	97aa                	add	a5,a5,a0
    800058c0:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    800058c4:	60a2                	ld	ra,8(sp)
    800058c6:	6402                	ld	s0,0(sp)
    800058c8:	0141                	addi	sp,sp,16
    800058ca:	8082                	ret

00000000800058cc <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800058cc:	1141                	addi	sp,sp,-16
    800058ce:	e406                	sd	ra,8(sp)
    800058d0:	e022                	sd	s0,0(sp)
    800058d2:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800058d4:	810fc0ef          	jal	800018e4 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800058d8:	00d5151b          	slliw	a0,a0,0xd
    800058dc:	0c2017b7          	lui	a5,0xc201
    800058e0:	97aa                	add	a5,a5,a0
  return irq;
}
    800058e2:	43c8                	lw	a0,4(a5)
    800058e4:	60a2                	ld	ra,8(sp)
    800058e6:	6402                	ld	s0,0(sp)
    800058e8:	0141                	addi	sp,sp,16
    800058ea:	8082                	ret

00000000800058ec <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800058ec:	1101                	addi	sp,sp,-32
    800058ee:	ec06                	sd	ra,24(sp)
    800058f0:	e822                	sd	s0,16(sp)
    800058f2:	e426                	sd	s1,8(sp)
    800058f4:	1000                	addi	s0,sp,32
    800058f6:	84aa                	mv	s1,a0
  int hart = cpuid();
    800058f8:	fedfb0ef          	jal	800018e4 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800058fc:	00d5151b          	slliw	a0,a0,0xd
    80005900:	0c2017b7          	lui	a5,0xc201
    80005904:	97aa                	add	a5,a5,a0
    80005906:	c3c4                	sw	s1,4(a5)
}
    80005908:	60e2                	ld	ra,24(sp)
    8000590a:	6442                	ld	s0,16(sp)
    8000590c:	64a2                	ld	s1,8(sp)
    8000590e:	6105                	addi	sp,sp,32
    80005910:	8082                	ret

0000000080005912 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005912:	1141                	addi	sp,sp,-16
    80005914:	e406                	sd	ra,8(sp)
    80005916:	e022                	sd	s0,0(sp)
    80005918:	0800                	addi	s0,sp,16
  if(i >= NUM)
    8000591a:	479d                	li	a5,7
    8000591c:	04a7ca63          	blt	a5,a0,80005970 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005920:	0001b797          	auipc	a5,0x1b
    80005924:	1d878793          	addi	a5,a5,472 # 80020af8 <disk>
    80005928:	97aa                	add	a5,a5,a0
    8000592a:	0187c783          	lbu	a5,24(a5)
    8000592e:	e7b9                	bnez	a5,8000597c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005930:	00451693          	slli	a3,a0,0x4
    80005934:	0001b797          	auipc	a5,0x1b
    80005938:	1c478793          	addi	a5,a5,452 # 80020af8 <disk>
    8000593c:	6398                	ld	a4,0(a5)
    8000593e:	9736                	add	a4,a4,a3
    80005940:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    80005944:	6398                	ld	a4,0(a5)
    80005946:	9736                	add	a4,a4,a3
    80005948:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000594c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005950:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005954:	97aa                	add	a5,a5,a0
    80005956:	4705                	li	a4,1
    80005958:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000595c:	0001b517          	auipc	a0,0x1b
    80005960:	1b450513          	addi	a0,a0,436 # 80020b10 <disk+0x18>
    80005964:	e06fc0ef          	jal	80001f6a <wakeup>
}
    80005968:	60a2                	ld	ra,8(sp)
    8000596a:	6402                	ld	s0,0(sp)
    8000596c:	0141                	addi	sp,sp,16
    8000596e:	8082                	ret
    panic("free_desc 1");
    80005970:	00002517          	auipc	a0,0x2
    80005974:	d1050513          	addi	a0,a0,-752 # 80007680 <etext+0x680>
    80005978:	e69fa0ef          	jal	800007e0 <panic>
    panic("free_desc 2");
    8000597c:	00002517          	auipc	a0,0x2
    80005980:	d1450513          	addi	a0,a0,-748 # 80007690 <etext+0x690>
    80005984:	e5dfa0ef          	jal	800007e0 <panic>

0000000080005988 <virtio_disk_init>:
{
    80005988:	1101                	addi	sp,sp,-32
    8000598a:	ec06                	sd	ra,24(sp)
    8000598c:	e822                	sd	s0,16(sp)
    8000598e:	e426                	sd	s1,8(sp)
    80005990:	e04a                	sd	s2,0(sp)
    80005992:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005994:	00002597          	auipc	a1,0x2
    80005998:	d0c58593          	addi	a1,a1,-756 # 800076a0 <etext+0x6a0>
    8000599c:	0001b517          	auipc	a0,0x1b
    800059a0:	28450513          	addi	a0,a0,644 # 80020c20 <disk+0x128>
    800059a4:	9ecfb0ef          	jal	80000b90 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800059a8:	100017b7          	lui	a5,0x10001
    800059ac:	4398                	lw	a4,0(a5)
    800059ae:	2701                	sext.w	a4,a4
    800059b0:	747277b7          	lui	a5,0x74727
    800059b4:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800059b8:	18f71063          	bne	a4,a5,80005b38 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800059bc:	100017b7          	lui	a5,0x10001
    800059c0:	0791                	addi	a5,a5,4 # 10001004 <_entry-0x6fffeffc>
    800059c2:	439c                	lw	a5,0(a5)
    800059c4:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800059c6:	4709                	li	a4,2
    800059c8:	16e79863          	bne	a5,a4,80005b38 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800059cc:	100017b7          	lui	a5,0x10001
    800059d0:	07a1                	addi	a5,a5,8 # 10001008 <_entry-0x6fffeff8>
    800059d2:	439c                	lw	a5,0(a5)
    800059d4:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800059d6:	16e79163          	bne	a5,a4,80005b38 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800059da:	100017b7          	lui	a5,0x10001
    800059de:	47d8                	lw	a4,12(a5)
    800059e0:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800059e2:	554d47b7          	lui	a5,0x554d4
    800059e6:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800059ea:	14f71763          	bne	a4,a5,80005b38 <virtio_disk_init+0x1b0>
  *R(VIRTIO_MMIO_STATUS) = status;
    800059ee:	100017b7          	lui	a5,0x10001
    800059f2:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    800059f6:	4705                	li	a4,1
    800059f8:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800059fa:	470d                	li	a4,3
    800059fc:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800059fe:	10001737          	lui	a4,0x10001
    80005a02:	4b14                	lw	a3,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005a04:	c7ffe737          	lui	a4,0xc7ffe
    80005a08:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fddb27>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005a0c:	8ef9                	and	a3,a3,a4
    80005a0e:	10001737          	lui	a4,0x10001
    80005a12:	d314                	sw	a3,32(a4)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005a14:	472d                	li	a4,11
    80005a16:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005a18:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80005a1c:	439c                	lw	a5,0(a5)
    80005a1e:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005a22:	8ba1                	andi	a5,a5,8
    80005a24:	12078063          	beqz	a5,80005b44 <virtio_disk_init+0x1bc>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005a28:	100017b7          	lui	a5,0x10001
    80005a2c:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005a30:	100017b7          	lui	a5,0x10001
    80005a34:	04478793          	addi	a5,a5,68 # 10001044 <_entry-0x6fffefbc>
    80005a38:	439c                	lw	a5,0(a5)
    80005a3a:	2781                	sext.w	a5,a5
    80005a3c:	10079a63          	bnez	a5,80005b50 <virtio_disk_init+0x1c8>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005a40:	100017b7          	lui	a5,0x10001
    80005a44:	03478793          	addi	a5,a5,52 # 10001034 <_entry-0x6fffefcc>
    80005a48:	439c                	lw	a5,0(a5)
    80005a4a:	2781                	sext.w	a5,a5
  if(max == 0)
    80005a4c:	10078863          	beqz	a5,80005b5c <virtio_disk_init+0x1d4>
  if(max < NUM)
    80005a50:	471d                	li	a4,7
    80005a52:	10f77b63          	bgeu	a4,a5,80005b68 <virtio_disk_init+0x1e0>
  disk.desc = kalloc();
    80005a56:	8a8fb0ef          	jal	80000afe <kalloc>
    80005a5a:	0001b497          	auipc	s1,0x1b
    80005a5e:	09e48493          	addi	s1,s1,158 # 80020af8 <disk>
    80005a62:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005a64:	89afb0ef          	jal	80000afe <kalloc>
    80005a68:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80005a6a:	894fb0ef          	jal	80000afe <kalloc>
    80005a6e:	87aa                	mv	a5,a0
    80005a70:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005a72:	6088                	ld	a0,0(s1)
    80005a74:	10050063          	beqz	a0,80005b74 <virtio_disk_init+0x1ec>
    80005a78:	0001b717          	auipc	a4,0x1b
    80005a7c:	08873703          	ld	a4,136(a4) # 80020b00 <disk+0x8>
    80005a80:	0e070a63          	beqz	a4,80005b74 <virtio_disk_init+0x1ec>
    80005a84:	0e078863          	beqz	a5,80005b74 <virtio_disk_init+0x1ec>
  memset(disk.desc, 0, PGSIZE);
    80005a88:	6605                	lui	a2,0x1
    80005a8a:	4581                	li	a1,0
    80005a8c:	a58fb0ef          	jal	80000ce4 <memset>
  memset(disk.avail, 0, PGSIZE);
    80005a90:	0001b497          	auipc	s1,0x1b
    80005a94:	06848493          	addi	s1,s1,104 # 80020af8 <disk>
    80005a98:	6605                	lui	a2,0x1
    80005a9a:	4581                	li	a1,0
    80005a9c:	6488                	ld	a0,8(s1)
    80005a9e:	a46fb0ef          	jal	80000ce4 <memset>
  memset(disk.used, 0, PGSIZE);
    80005aa2:	6605                	lui	a2,0x1
    80005aa4:	4581                	li	a1,0
    80005aa6:	6888                	ld	a0,16(s1)
    80005aa8:	a3cfb0ef          	jal	80000ce4 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005aac:	100017b7          	lui	a5,0x10001
    80005ab0:	4721                	li	a4,8
    80005ab2:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80005ab4:	4098                	lw	a4,0(s1)
    80005ab6:	100017b7          	lui	a5,0x10001
    80005aba:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005abe:	40d8                	lw	a4,4(s1)
    80005ac0:	100017b7          	lui	a5,0x10001
    80005ac4:	08e7a223          	sw	a4,132(a5) # 10001084 <_entry-0x6fffef7c>
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005ac8:	649c                	ld	a5,8(s1)
    80005aca:	0007869b          	sext.w	a3,a5
    80005ace:	10001737          	lui	a4,0x10001
    80005ad2:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005ad6:	9781                	srai	a5,a5,0x20
    80005ad8:	10001737          	lui	a4,0x10001
    80005adc:	08f72a23          	sw	a5,148(a4) # 10001094 <_entry-0x6fffef6c>
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005ae0:	689c                	ld	a5,16(s1)
    80005ae2:	0007869b          	sext.w	a3,a5
    80005ae6:	10001737          	lui	a4,0x10001
    80005aea:	0ad72023          	sw	a3,160(a4) # 100010a0 <_entry-0x6fffef60>
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005aee:	9781                	srai	a5,a5,0x20
    80005af0:	10001737          	lui	a4,0x10001
    80005af4:	0af72223          	sw	a5,164(a4) # 100010a4 <_entry-0x6fffef5c>
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005af8:	10001737          	lui	a4,0x10001
    80005afc:	4785                	li	a5,1
    80005afe:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005b00:	00f48c23          	sb	a5,24(s1)
    80005b04:	00f48ca3          	sb	a5,25(s1)
    80005b08:	00f48d23          	sb	a5,26(s1)
    80005b0c:	00f48da3          	sb	a5,27(s1)
    80005b10:	00f48e23          	sb	a5,28(s1)
    80005b14:	00f48ea3          	sb	a5,29(s1)
    80005b18:	00f48f23          	sb	a5,30(s1)
    80005b1c:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005b20:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005b24:	100017b7          	lui	a5,0x10001
    80005b28:	0727a823          	sw	s2,112(a5) # 10001070 <_entry-0x6fffef90>
}
    80005b2c:	60e2                	ld	ra,24(sp)
    80005b2e:	6442                	ld	s0,16(sp)
    80005b30:	64a2                	ld	s1,8(sp)
    80005b32:	6902                	ld	s2,0(sp)
    80005b34:	6105                	addi	sp,sp,32
    80005b36:	8082                	ret
    panic("could not find virtio disk");
    80005b38:	00002517          	auipc	a0,0x2
    80005b3c:	b7850513          	addi	a0,a0,-1160 # 800076b0 <etext+0x6b0>
    80005b40:	ca1fa0ef          	jal	800007e0 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005b44:	00002517          	auipc	a0,0x2
    80005b48:	b8c50513          	addi	a0,a0,-1140 # 800076d0 <etext+0x6d0>
    80005b4c:	c95fa0ef          	jal	800007e0 <panic>
    panic("virtio disk should not be ready");
    80005b50:	00002517          	auipc	a0,0x2
    80005b54:	ba050513          	addi	a0,a0,-1120 # 800076f0 <etext+0x6f0>
    80005b58:	c89fa0ef          	jal	800007e0 <panic>
    panic("virtio disk has no queue 0");
    80005b5c:	00002517          	auipc	a0,0x2
    80005b60:	bb450513          	addi	a0,a0,-1100 # 80007710 <etext+0x710>
    80005b64:	c7dfa0ef          	jal	800007e0 <panic>
    panic("virtio disk max queue too short");
    80005b68:	00002517          	auipc	a0,0x2
    80005b6c:	bc850513          	addi	a0,a0,-1080 # 80007730 <etext+0x730>
    80005b70:	c71fa0ef          	jal	800007e0 <panic>
    panic("virtio disk kalloc");
    80005b74:	00002517          	auipc	a0,0x2
    80005b78:	bdc50513          	addi	a0,a0,-1060 # 80007750 <etext+0x750>
    80005b7c:	c65fa0ef          	jal	800007e0 <panic>

0000000080005b80 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005b80:	7159                	addi	sp,sp,-112
    80005b82:	f486                	sd	ra,104(sp)
    80005b84:	f0a2                	sd	s0,96(sp)
    80005b86:	eca6                	sd	s1,88(sp)
    80005b88:	e8ca                	sd	s2,80(sp)
    80005b8a:	e4ce                	sd	s3,72(sp)
    80005b8c:	e0d2                	sd	s4,64(sp)
    80005b8e:	fc56                	sd	s5,56(sp)
    80005b90:	f85a                	sd	s6,48(sp)
    80005b92:	f45e                	sd	s7,40(sp)
    80005b94:	f062                	sd	s8,32(sp)
    80005b96:	ec66                	sd	s9,24(sp)
    80005b98:	1880                	addi	s0,sp,112
    80005b9a:	8a2a                	mv	s4,a0
    80005b9c:	8bae                	mv	s7,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80005b9e:	00c52c83          	lw	s9,12(a0)
    80005ba2:	001c9c9b          	slliw	s9,s9,0x1
    80005ba6:	1c82                	slli	s9,s9,0x20
    80005ba8:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    80005bac:	0001b517          	auipc	a0,0x1b
    80005bb0:	07450513          	addi	a0,a0,116 # 80020c20 <disk+0x128>
    80005bb4:	85cfb0ef          	jal	80000c10 <acquire>
  for(int i = 0; i < 3; i++){
    80005bb8:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    80005bba:	44a1                	li	s1,8
      disk.free[i] = 0;
    80005bbc:	0001bb17          	auipc	s6,0x1b
    80005bc0:	f3cb0b13          	addi	s6,s6,-196 # 80020af8 <disk>
  for(int i = 0; i < 3; i++){
    80005bc4:	4a8d                	li	s5,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005bc6:	0001bc17          	auipc	s8,0x1b
    80005bca:	05ac0c13          	addi	s8,s8,90 # 80020c20 <disk+0x128>
    80005bce:	a8b9                	j	80005c2c <virtio_disk_rw+0xac>
      disk.free[i] = 0;
    80005bd0:	00fb0733          	add	a4,s6,a5
    80005bd4:	00070c23          	sb	zero,24(a4) # 10001018 <_entry-0x6fffefe8>
    idx[i] = alloc_desc();
    80005bd8:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80005bda:	0207c563          	bltz	a5,80005c04 <virtio_disk_rw+0x84>
  for(int i = 0; i < 3; i++){
    80005bde:	2905                	addiw	s2,s2,1
    80005be0:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005be2:	05590963          	beq	s2,s5,80005c34 <virtio_disk_rw+0xb4>
    idx[i] = alloc_desc();
    80005be6:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005be8:	0001b717          	auipc	a4,0x1b
    80005bec:	f1070713          	addi	a4,a4,-240 # 80020af8 <disk>
    80005bf0:	87ce                	mv	a5,s3
    if(disk.free[i]){
    80005bf2:	01874683          	lbu	a3,24(a4)
    80005bf6:	fee9                	bnez	a3,80005bd0 <virtio_disk_rw+0x50>
  for(int i = 0; i < NUM; i++){
    80005bf8:	2785                	addiw	a5,a5,1
    80005bfa:	0705                	addi	a4,a4,1
    80005bfc:	fe979be3          	bne	a5,s1,80005bf2 <virtio_disk_rw+0x72>
    idx[i] = alloc_desc();
    80005c00:	57fd                	li	a5,-1
    80005c02:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80005c04:	01205d63          	blez	s2,80005c1e <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005c08:	f9042503          	lw	a0,-112(s0)
    80005c0c:	d07ff0ef          	jal	80005912 <free_desc>
      for(int j = 0; j < i; j++)
    80005c10:	4785                	li	a5,1
    80005c12:	0127d663          	bge	a5,s2,80005c1e <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005c16:	f9442503          	lw	a0,-108(s0)
    80005c1a:	cf9ff0ef          	jal	80005912 <free_desc>
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005c1e:	85e2                	mv	a1,s8
    80005c20:	0001b517          	auipc	a0,0x1b
    80005c24:	ef050513          	addi	a0,a0,-272 # 80020b10 <disk+0x18>
    80005c28:	af6fc0ef          	jal	80001f1e <sleep>
  for(int i = 0; i < 3; i++){
    80005c2c:	f9040613          	addi	a2,s0,-112
    80005c30:	894e                	mv	s2,s3
    80005c32:	bf55                	j	80005be6 <virtio_disk_rw+0x66>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005c34:	f9042503          	lw	a0,-112(s0)
    80005c38:	00451693          	slli	a3,a0,0x4

  if(write)
    80005c3c:	0001b797          	auipc	a5,0x1b
    80005c40:	ebc78793          	addi	a5,a5,-324 # 80020af8 <disk>
    80005c44:	00a50713          	addi	a4,a0,10
    80005c48:	0712                	slli	a4,a4,0x4
    80005c4a:	973e                	add	a4,a4,a5
    80005c4c:	01703633          	snez	a2,s7
    80005c50:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005c52:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005c56:	01973823          	sd	s9,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80005c5a:	6398                	ld	a4,0(a5)
    80005c5c:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005c5e:	0a868613          	addi	a2,a3,168
    80005c62:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005c64:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005c66:	6390                	ld	a2,0(a5)
    80005c68:	00d605b3          	add	a1,a2,a3
    80005c6c:	4741                	li	a4,16
    80005c6e:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005c70:	4805                	li	a6,1
    80005c72:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    80005c76:	f9442703          	lw	a4,-108(s0)
    80005c7a:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80005c7e:	0712                	slli	a4,a4,0x4
    80005c80:	963a                	add	a2,a2,a4
    80005c82:	058a0593          	addi	a1,s4,88
    80005c86:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005c88:	0007b883          	ld	a7,0(a5)
    80005c8c:	9746                	add	a4,a4,a7
    80005c8e:	40000613          	li	a2,1024
    80005c92:	c710                	sw	a2,8(a4)
  if(write)
    80005c94:	001bb613          	seqz	a2,s7
    80005c98:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005c9c:	00166613          	ori	a2,a2,1
    80005ca0:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005ca4:	f9842583          	lw	a1,-104(s0)
    80005ca8:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005cac:	00250613          	addi	a2,a0,2
    80005cb0:	0612                	slli	a2,a2,0x4
    80005cb2:	963e                	add	a2,a2,a5
    80005cb4:	577d                	li	a4,-1
    80005cb6:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80005cba:	0592                	slli	a1,a1,0x4
    80005cbc:	98ae                	add	a7,a7,a1
    80005cbe:	03068713          	addi	a4,a3,48
    80005cc2:	973e                	add	a4,a4,a5
    80005cc4:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005cc8:	6398                	ld	a4,0(a5)
    80005cca:	972e                	add	a4,a4,a1
    80005ccc:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005cd0:	4689                	li	a3,2
    80005cd2:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005cd6:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005cda:	010a2223          	sw	a6,4(s4)
  disk.info[idx[0]].b = b;
    80005cde:	01463423          	sd	s4,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005ce2:	6794                	ld	a3,8(a5)
    80005ce4:	0026d703          	lhu	a4,2(a3)
    80005ce8:	8b1d                	andi	a4,a4,7
    80005cea:	0706                	slli	a4,a4,0x1
    80005cec:	96ba                	add	a3,a3,a4
    80005cee:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80005cf2:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005cf6:	6798                	ld	a4,8(a5)
    80005cf8:	00275783          	lhu	a5,2(a4)
    80005cfc:	2785                	addiw	a5,a5,1
    80005cfe:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005d02:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005d06:	100017b7          	lui	a5,0x10001
    80005d0a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80005d0e:	004a2783          	lw	a5,4(s4)
    sleep(b, &disk.vdisk_lock);
    80005d12:	0001b917          	auipc	s2,0x1b
    80005d16:	f0e90913          	addi	s2,s2,-242 # 80020c20 <disk+0x128>
  while(b->disk == 1) {
    80005d1a:	4485                	li	s1,1
    80005d1c:	01079a63          	bne	a5,a6,80005d30 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80005d20:	85ca                	mv	a1,s2
    80005d22:	8552                	mv	a0,s4
    80005d24:	9fafc0ef          	jal	80001f1e <sleep>
  while(b->disk == 1) {
    80005d28:	004a2783          	lw	a5,4(s4)
    80005d2c:	fe978ae3          	beq	a5,s1,80005d20 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80005d30:	f9042903          	lw	s2,-112(s0)
    80005d34:	00290713          	addi	a4,s2,2
    80005d38:	0712                	slli	a4,a4,0x4
    80005d3a:	0001b797          	auipc	a5,0x1b
    80005d3e:	dbe78793          	addi	a5,a5,-578 # 80020af8 <disk>
    80005d42:	97ba                	add	a5,a5,a4
    80005d44:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005d48:	0001b997          	auipc	s3,0x1b
    80005d4c:	db098993          	addi	s3,s3,-592 # 80020af8 <disk>
    80005d50:	00491713          	slli	a4,s2,0x4
    80005d54:	0009b783          	ld	a5,0(s3)
    80005d58:	97ba                	add	a5,a5,a4
    80005d5a:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005d5e:	854a                	mv	a0,s2
    80005d60:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005d64:	bafff0ef          	jal	80005912 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80005d68:	8885                	andi	s1,s1,1
    80005d6a:	f0fd                	bnez	s1,80005d50 <virtio_disk_rw+0x1d0>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005d6c:	0001b517          	auipc	a0,0x1b
    80005d70:	eb450513          	addi	a0,a0,-332 # 80020c20 <disk+0x128>
    80005d74:	f35fa0ef          	jal	80000ca8 <release>
}
    80005d78:	70a6                	ld	ra,104(sp)
    80005d7a:	7406                	ld	s0,96(sp)
    80005d7c:	64e6                	ld	s1,88(sp)
    80005d7e:	6946                	ld	s2,80(sp)
    80005d80:	69a6                	ld	s3,72(sp)
    80005d82:	6a06                	ld	s4,64(sp)
    80005d84:	7ae2                	ld	s5,56(sp)
    80005d86:	7b42                	ld	s6,48(sp)
    80005d88:	7ba2                	ld	s7,40(sp)
    80005d8a:	7c02                	ld	s8,32(sp)
    80005d8c:	6ce2                	ld	s9,24(sp)
    80005d8e:	6165                	addi	sp,sp,112
    80005d90:	8082                	ret

0000000080005d92 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005d92:	1101                	addi	sp,sp,-32
    80005d94:	ec06                	sd	ra,24(sp)
    80005d96:	e822                	sd	s0,16(sp)
    80005d98:	e426                	sd	s1,8(sp)
    80005d9a:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005d9c:	0001b497          	auipc	s1,0x1b
    80005da0:	d5c48493          	addi	s1,s1,-676 # 80020af8 <disk>
    80005da4:	0001b517          	auipc	a0,0x1b
    80005da8:	e7c50513          	addi	a0,a0,-388 # 80020c20 <disk+0x128>
    80005dac:	e65fa0ef          	jal	80000c10 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005db0:	100017b7          	lui	a5,0x10001
    80005db4:	53b8                	lw	a4,96(a5)
    80005db6:	8b0d                	andi	a4,a4,3
    80005db8:	100017b7          	lui	a5,0x10001
    80005dbc:	d3f8                	sw	a4,100(a5)

  __sync_synchronize();
    80005dbe:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005dc2:	689c                	ld	a5,16(s1)
    80005dc4:	0204d703          	lhu	a4,32(s1)
    80005dc8:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005dcc:	04f70663          	beq	a4,a5,80005e18 <virtio_disk_intr+0x86>
    __sync_synchronize();
    80005dd0:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005dd4:	6898                	ld	a4,16(s1)
    80005dd6:	0204d783          	lhu	a5,32(s1)
    80005dda:	8b9d                	andi	a5,a5,7
    80005ddc:	078e                	slli	a5,a5,0x3
    80005dde:	97ba                	add	a5,a5,a4
    80005de0:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005de2:	00278713          	addi	a4,a5,2
    80005de6:	0712                	slli	a4,a4,0x4
    80005de8:	9726                	add	a4,a4,s1
    80005dea:	01074703          	lbu	a4,16(a4)
    80005dee:	e321                	bnez	a4,80005e2e <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005df0:	0789                	addi	a5,a5,2
    80005df2:	0792                	slli	a5,a5,0x4
    80005df4:	97a6                	add	a5,a5,s1
    80005df6:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005df8:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005dfc:	96efc0ef          	jal	80001f6a <wakeup>

    disk.used_idx += 1;
    80005e00:	0204d783          	lhu	a5,32(s1)
    80005e04:	2785                	addiw	a5,a5,1
    80005e06:	17c2                	slli	a5,a5,0x30
    80005e08:	93c1                	srli	a5,a5,0x30
    80005e0a:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005e0e:	6898                	ld	a4,16(s1)
    80005e10:	00275703          	lhu	a4,2(a4)
    80005e14:	faf71ee3          	bne	a4,a5,80005dd0 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005e18:	0001b517          	auipc	a0,0x1b
    80005e1c:	e0850513          	addi	a0,a0,-504 # 80020c20 <disk+0x128>
    80005e20:	e89fa0ef          	jal	80000ca8 <release>
}
    80005e24:	60e2                	ld	ra,24(sp)
    80005e26:	6442                	ld	s0,16(sp)
    80005e28:	64a2                	ld	s1,8(sp)
    80005e2a:	6105                	addi	sp,sp,32
    80005e2c:	8082                	ret
      panic("virtio_disk_intr status");
    80005e2e:	00002517          	auipc	a0,0x2
    80005e32:	93a50513          	addi	a0,a0,-1734 # 80007768 <etext+0x768>
    80005e36:	9abfa0ef          	jal	800007e0 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
