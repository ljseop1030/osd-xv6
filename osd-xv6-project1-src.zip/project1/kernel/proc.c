#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"

struct cpu cpus[NCPU];

struct proc proc[NPROC];

struct proc *initproc;

int nextpid = 1;
struct spinlock pid_lock;

//Added for project 01
extern uint64 memory_available(void);
extern void forkret(void);
static void freeproc(struct proc *p);

extern char trampoline[]; // trampoline.S

// helps ensure that wakeups of wait()ing
// parents are not lost. helps obey the
// memory model when using p->parent.
// must be acquired before any p->lock.
struct spinlock wait_lock;

// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
  }
}

// initialize the proc table.
void
procinit(void)
{
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
  initlock(&wait_lock, "wait_lock");
  for(p = proc; p < &proc[NPROC]; p++) {
      initlock(&p->lock, "proc");
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
  }
}

// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
  int id = r_tp();
  return id;
}

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
  int id = cpuid();
  struct cpu *c = &cpus[id];
  return c;
}

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
  push_off();
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
  pop_off();
  return p;
}

int
allocpid()
{
  int pid;
  
  acquire(&pid_lock);
  pid = nextpid;
  nextpid = nextpid + 1;
  release(&pid_lock);

  return pid;
}

// Look in the process table for an UNUSED proc.
// If found, initialize state required to run in the kernel,
// and return with p->lock held.
// If there are no free procs, or a memory allocation fails, return 0.
static struct proc*
allocproc(void)
{
  struct proc *p;
  for(p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if(p->state == UNUSED) {
      goto found;
    } else {
      release(&p->lock);
    }
  }
  return 0;

found:
  p->pid = allocpid();
  p->state = USED;
  p->nice = 20;
  /* 
  AI Assisted:  
  Set the default nice value to 20 according to the assignment specification.  
  We added an int nice field to struct proc, but didn't assign an initial value when creating a process,
  which caused a malfunction due to an uninitialized nice value.  
  To fix this, we asked CLAUD why we have an error and modified the code to initialize nice to 20 at the time of process creation.  
  */

  // Allocate a trapframe page.
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  // An empty user page table.
  p->pagetable = proc_pagetable(p);
  if(p->pagetable == 0){
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  // Set up new context to start executing at forkret,
  // which returns to user space.
  memset(&p->context, 0, sizeof(p->context));
  p->context.ra = (uint64)forkret;
  p->context.sp = p->kstack + PGSIZE;

  return p;
}

// free a proc structure and the data hanging from it,
// including user pages.
// p->lock must be held.
static void
freeproc(struct proc *p)
{
  if(p->trapframe)
    kfree((void*)p->trapframe);
  p->trapframe = 0;
  if(p->pagetable)
    proc_freepagetable(p->pagetable, p->sz);
  p->pagetable = 0;
  p->sz = 0;
  p->pid = 0;
  p->parent = 0;
  p->name[0] = 0;
  p->chan = 0;
  p->killed = 0;
  p->xstate = 0;
  p->state = UNUSED;
}

// Create a user page table for a given process, with no user memory,
// but with trampoline and trapframe pages.
pagetable_t
proc_pagetable(struct proc *p)
{
  pagetable_t pagetable;

  // An empty page table.
  pagetable = uvmcreate();
  if(pagetable == 0)
    return 0;

  // map the trampoline code (for system call return)
  // at the highest user virtual address.
  // only the supervisor uses it, on the way
  // to/from user space, so not PTE_U.
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
              (uint64)trampoline, PTE_R | PTE_X) < 0){
    uvmfree(pagetable, 0);
    return 0;
  }

  // map the trapframe page just below the trampoline page, for
  // trampoline.S.
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
              (uint64)(p->trapframe), PTE_R | PTE_W) < 0){
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    uvmfree(pagetable, 0);
    return 0;
  }

  return pagetable;
}

// Free a process's page table, and free the
// physical memory it refers to.
void
proc_freepagetable(pagetable_t pagetable, uint64 sz)
{
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
  uvmfree(pagetable, sz);
}

// Set up first user process.
void
userinit(void)
{
  struct proc *p;

  p = allocproc();
  initproc = p;
  
  p->cwd = namei("/");

  p->state = RUNNABLE;

  release(&p->lock);
}

// Grow or shrink user memory by n bytes.
// Return 0 on success, -1 on failure.
int
growproc(int n)
{
  uint64 sz;
  struct proc *p = myproc();

  sz = p->sz;
  if(n > 0){
    if(sz + n > TRAPFRAME) {
      return -1;
    }
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
      return -1;
    }
  } else if(n < 0){
    sz = uvmdealloc(p->pagetable, sz, sz + n);
  }
  p->sz = sz;
  return 0;
}

// Create a new process, copying the parent.
// Sets up child kernel stack to return as if from fork() system call.
int
kfork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *p = myproc();

  // Allocate process.
  if((np = allocproc()) == 0){
    return -1;
  }

  // Copy user memory from parent to child.
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    freeproc(np);
    release(&np->lock);
    return -1;
  }
  np->sz = p->sz;

  // copy saved user registers.
  *(np->trapframe) = *(p->trapframe);

  // Cause fork to return 0 in the child.
  np->trapframe->a0 = 0;

  // increment reference counts on open file descriptors.
  for(i = 0; i < NOFILE; i++)
    if(p->ofile[i])
      np->ofile[i] = filedup(p->ofile[i]);
  np->cwd = idup(p->cwd);

  safestrcpy(np->name, p->name, sizeof(p->name));

  pid = np->pid;

  release(&np->lock);

  acquire(&wait_lock);
  np->parent = p;
  release(&wait_lock);

  acquire(&np->lock);
  np->state = RUNNABLE;
  release(&np->lock);

  return pid;
}

// Pass p's abandoned children to init.
// Caller must hold wait_lock.
void
reparent(struct proc *p)
{
  struct proc *pp;

  for(pp = proc; pp < &proc[NPROC]; pp++){
    if(pp->parent == p){
      pp->parent = initproc;
      wakeup(initproc);
    }
  }
}

// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait().
void
kexit(int status)
{
  struct proc *p = myproc();

  if(p == initproc)
    panic("init exiting");

  // Close all open files.
  for(int fd = 0; fd < NOFILE; fd++){
    if(p->ofile[fd]){
      struct file *f = p->ofile[fd];
      fileclose(f);
      p->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(p->cwd);
  end_op();
  p->cwd = 0;

  acquire(&wait_lock);

  // Give any children to init.
  reparent(p);

  // Parent might be sleeping in wait().
  wakeup(p->parent);
  
  acquire(&p->lock);

  p->xstate = status;
  p->state = ZOMBIE;

  release(&wait_lock);

  // Jump into the scheduler, never to return.
  sched();
  panic("zombie exit");
}

// Wait for a child process to exit and return its pid.
// Return -1 if this process has no children.
int
kwait(uint64 addr)
{
  struct proc *pp;
  int havekids, pid;
  struct proc *p = myproc();

  acquire(&wait_lock);

  for(;;){
    // Scan through table looking for exited children.
    havekids = 0;
    for(pp = proc; pp < &proc[NPROC]; pp++){
      if(pp->parent == p){
        // make sure the child isn't still in exit() or swtch().
        acquire(&pp->lock);

        havekids = 1;
        if(pp->state == ZOMBIE){
          // Found one.
          pid = pp->pid;
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
                                  sizeof(pp->xstate)) < 0) {
            release(&pp->lock);
            release(&wait_lock);
            return -1;
          }
          freeproc(pp);
          release(&pp->lock);
          release(&wait_lock);
          return pid;
        }
        release(&pp->lock);
      }
    }

    // No point waiting if we don't have any children.
    if(!havekids || killed(p)){
      release(&wait_lock);
      return -1;
    }
    
    // Wait for a child to exit.
    sleep(p, &wait_lock);  //DOC: wait-sleep
  }
}

// Per-CPU process scheduler.
// Each CPU calls scheduler() after setting itself up.
// Scheduler never returns.  It loops, doing:
//  - choose a process to run.
//  - swtch to start running that process.
//  - eventually that process transfers control
//    via swtch back to the scheduler.
void
scheduler(void)
{
  struct proc *p;
  struct cpu *c = mycpu();

  c->proc = 0;
  for(;;){
    // The most recent process to run may have had interrupts
    // turned off; enable them to avoid a deadlock if all
    // processes are waiting. Then turn them back off
    // to avoid a possible race between an interrupt
    // and wfi.
    intr_on();
    intr_off();

    int found = 0;
    for(p = proc; p < &proc[NPROC]; p++) {
      acquire(&p->lock);
      if(p->state == RUNNABLE) {
        // Switch to chosen process.  It is the process's job
        // to release its lock and then reacquire it
        // before jumping back to us.
        p->state = RUNNING;
        c->proc = p;
        swtch(&c->context, &p->context);

        // Process is done running for now.
        // It should have changed its p->state before coming back.
        c->proc = 0;
        found = 1;
      }
      release(&p->lock);
    }
    if(found == 0) {
      // nothing to run; stop running on this core until an interrupt.
      asm volatile("wfi");
    }
  }
}

// Switch to scheduler.  Must hold only p->lock
// and have changed proc->state. Saves and restores
// intena because intena is a property of this
// kernel thread, not this CPU. It should
// be proc->intena and proc->noff, but that would
// break in the few places where a lock is held but
// there's no process.
void
sched(void)
{
  int intena;
  struct proc *p = myproc();

  if(!holding(&p->lock))
    panic("sched p->lock");
  if(mycpu()->noff != 1)
    panic("sched locks");
  if(p->state == RUNNING)
    panic("sched RUNNING");
  if(intr_get())
    panic("sched interruptible");

  intena = mycpu()->intena;
  swtch(&p->context, &mycpu()->context);
  mycpu()->intena = intena;
}

// Give up the CPU for one scheduling round.
void
yield(void)
{
  struct proc *p = myproc();
  acquire(&p->lock);
  p->state = RUNNABLE;
  sched();
  release(&p->lock);
}

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();

  // Still holding p->lock from scheduler.
  release(&p->lock);

  if (first) {
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);

    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    if (p->trapframe->a0 == -1) {
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
  uint64 satp = MAKE_SATP(p->pagetable);
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
  ((void (*)(uint64))trampoline_userret)(satp);
}

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
  struct proc *p = myproc();
  
  // Must acquire p->lock in order to
  // change p->state and then call sched.
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
  release(lk);

  // Go to sleep.
  p->chan = chan;
  p->state = SLEEPING;

  sched();

  // Tidy up.
  p->chan = 0;

  // Reacquire original lock.
  release(&p->lock);
  acquire(lk);
}

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
        p->state = RUNNABLE;
      }
      release(&p->lock);
    }
  }
}

// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->pid == pid){
      p->killed = 1;
      if(p->state == SLEEPING){
        // Wake process from sleep().
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1;
}

void
setkilled(struct proc *p)
{
  acquire(&p->lock);
  p->killed = 1;
  release(&p->lock);
}

int
killed(struct proc *p)
{
  int k;
  
  acquire(&p->lock);
  k = p->killed;
  release(&p->lock);
  return k;
}

// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
  struct proc *p = myproc();
  if(user_dst){
    return copyout(p->pagetable, dst, src, len);
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}

// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
  struct proc *p = myproc();
  if(user_src){
    return copyin(p->pagetable, dst, src, len);
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}

// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
  static char *states[] = {
  [UNUSED]    "unused",
  [USED]      "used",
  [SLEEPING]  "sleep ",
  [RUNNABLE]  "runble",
  [RUNNING]   "run   ",
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
  for(p = proc; p < &proc[NPROC]; p++){
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    printf("%d %s %s", p->pid, state, p->name);
    printf("\n");
  }
}

/* 
1. getnice(int pid)
Reads and returns the nice value of the process with the given pid.

Call path: user app -> usys.S (ecall) -> sys_getnice()-> getnice()
*/
int
getnice(int pid)
{
    int i = 0; // Iterate through the proc[] array from 0
    while (i < NPROC) {  // NPROC = 64 (maximum numbers of process slots)
        struct proc *p = &proc[i]; 
        acquire(&p->lock); // Acquire the spinlock (prevents race condition)
        if (p->pid == pid) { // The pid of process matches the pid           
            int niceValue = p->nice; // Save nice value to a local variable before releasing the lock
            release(&p->lock);       // Release the lock before returning
            return niceValue;        // Success: return the nice value of the process
        }
        release(&p->lock); 
        i = i + 1;
    } // Finished scanning the entire table without finding the pid
    return -1; // Fail: no process with the given pid exists -> return -1
}

/* 
2. setnice(int pid, int value)
Changes the nice value of the process with the given pid to value.

Call path: user app -> usys.S (ecall) -> sys_setnice() -> setnice() 
*/
int
setnice(int pid, int value) // Valid range for nice values is 0–39
{
    if (value < 0 || value > 39) { //Fail: value out of range -> return -1
        return -1;  
    }
    int i = 0;
    while (i < NPROC) { // Iterate through the proc[] array to find the process with the given pid.

        struct proc *p = &proc[i];
        acquire(&p->lock); // Acquire the spinlock
        if (p->pid == pid) { // The pid of process matches the pid
            p->nice = value; // Overwrite the nice value 
            release(&p->lock); // Release the lock
            return 0; //Success -> return 0
        }
        release(&p->lock);
        i = i + 1;
    } // No process with the given pid was found.
    return -1; // Fail -> return -1
}

/*
3. ps(int pid)
Prints the status of process(name, pid, state, nice value) to the console
If pid is 0, print all process
Prints the process with the matching pid
If no matching process, print nothing

Call path: user app -> usys.S (ecall) -> sys_ps() -> ps()

AI Assisted: 
There was an issue where returning without releasing the lock when the pid matched 
caused a panic later. We noticed the panic while running mytest, and solved the problem 
by modifying the code to skip lock acquisition for the current process (myproc). 
*/
void
ps(int pid)
{
  static char *states[] = { // String table for process state names.
    [UNUSED]    "UNUSED",
    [USED]      "USED",
    [SLEEPING]  "SLEEPING",
    [RUNNABLE]  "RUNNABLE",
    [RUNNING]   "RUNNING",
    [ZOMBIE]    "ZOMBIE"
  };

  int printed = 0; // Tracks whether the header line has been printed yet
  int i = 0;
  while (i < NPROC){
    struct proc *p = &proc[i];  
    /*
    Case 1: current process
    The process that called ps() — myproc() — is handled without acquiring lock
    Reason: calling acquire() on one's own lock would result in a
    double-acquire, which causes a panic in xv6's spinlock implementation
    */

    if(p == myproc()){
      if(pid == 0 || p->pid == pid){
        if(printed == 0){
          printf("name\t\tpid\tstate\t\tpriority\n"); // Print the header
          printed = 1; // Since the header is printed, change printed to 1
        }
        printf("%s\t\t%d\t%s\t\t%d\n", p->name, p->pid, states[p->state], p->nice); // Print info of process
        if(pid != 0) return; // Found a specific pid -> return
      }
      i++;
      continue;
    }
  
    // Case 2: any other process
    acquire(&p->lock); //Acquire the lock to ensure the process state does not change while we are reading its fields
    if(pid == 0){ // Case 2-1: Printing all processes
      if(p->state != UNUSED){ // Skip UNUSED slots
        if(printed == 0){ 
          printf("name\t\tpid\tstate\t\tpriority\n"); // Print header
          printed = 1; 
        }
        printf("%s\t\t%d\t%s\t\t%d\n", p->name, p->pid, states[p->state], p->nice); // Print info of process
      }
    } else { // Case 2-2: Printing single process
      if(p->pid == pid){
        printf("name\t\tpid\tstate\t\tpriority\n"); // Print header
        printf("%s\t\t%d\t%s\t\t%d\n", p->name, p->pid, states[p->state], p->nice); // Print info of process
        release(&p->lock); // Release lock
        return;
      }
    }
    release(&p->lock); // Release lock
    i++;
  } // Case 3: If pid is not 0 and no matching process was found, nothing is printed
}

/*
 4. meminfo()
Returns the amount of free physical memory in bytes.
Instead of accessing kmem directly, this function delegates to
memory_available() defined in kalloc.c.

Call path: user app -> usys.S (ecall) -> sys_meminfo() -> meminfo()
-> memory_available() [kalloc.c]

AI Assisted: 
We implemented the meminfo function in proc.c, but faced an issue that we couldn't 
access kmem directly from there. Through AI feedback, we learned that it is more appropriate 
to expose memory information through a function in kalloc.c, which actually manages that data. 
Therefore, we wrote the memory_available() function in kalloc.c and modified meminfo to call it. 
*/
uint64
meminfo(void)
{
  return memory_available(); // Simply forward the result from memory_available()
}


/*
5. waitpid(int pid)
Blocks the calling process until the child process with the given pid terminates
Returns 0 on success (target process has exited)
Returns -1 on failure 
(The given pid does not exist 
or the process with that pid is not a child of the caller)

Call path: user app -> usys.S (ecall) -> sys_waitpid() -> waitpid()

Difference from xv6's built-in wait():
wait()    — blocks until ANY child exits.
waitpid() — blocks until a SPECIFIC child (by pid) exits.

AI Assisted: 
In the initial implementation, we used a polling method that repeatedly called yield 
to check the child process's state. Through AI feedback, we found the following two problems: 
1. It only checked for the ZOMBIE state and exited with return 0, so the child process's resources were not reclaimed. 
2. It repeatedly woke up to check and yield until the child terminated, wasting CPU resources. 
To improve this, we modified the code to explicitly free resources using freeproc and used sleep to wait without unnecessarily occupying the CPU. 
*/
int
waitpid(int pid)
{
  struct proc *myp = myproc(); // myproc() returns a pointer to the currently running process (the caller)
  // Used to verify that the target process is a direct child of the caller.

  acquire(&wait_lock); // Held here to avoid missing a wakeup from kexit().
  // Without this lock, the child could call wakeup() before we call sleep(),
  // -> sleep forever waiting for a signal that already passed

  while (1){
    int found = 0; // 0: a child with the given pid not found, 1: found
    int i = 0;
    while (i < NPROC){ // Scan the entire process table to find the target child
      struct proc *p = &proc[i];
      acquire(&p->lock);
      if(p->pid == pid && p->parent == myp){ // p->pid matches the requested pid,
        // p->parent == myp — the process must be a direct child of the caller.
        found = 1;
        if(p->state == ZOMBIE){ // Case 2: The child has exited but its resources have not been reclaimed yet (ZOMBIE).
          freeproc(p); // Release the child's memory, pagetable, and reset the slot to UNUSED
          release(&p->lock);
          release(&wait_lock);
          return 0; // Success — child has exited and resources are reclaimed -> return 0
        }

        // Case 3: Child exists but has not exited yet
        release(&p->lock);
        break; // Break out and sleep below
      }
      release(&p->lock);
      i++;
    }

    if(found == 0){ // Case 1: The given pid does not exist or belongs to another process's child
      release(&wait_lock);
      return -1;
    }

    sleep(myp, &wait_lock); // The child is still running. Rather than busy-waiting,
    // we call sleep() to give up the CPU until the child exits.
    // When the child calls kexit(), it calls wakeup(p->parent) to wake us up.
    // sleep() releases wait_lock and suspends the caller,
    // then re-acquires wait_lock before returning.

    // Woke up — loop back to re-check whether the child has exited.
  }
}