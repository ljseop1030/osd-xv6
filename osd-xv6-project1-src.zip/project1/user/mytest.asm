
user/_mytest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <check>:

int passed = 0;
int failed = 0;

void check(const char *test, int actual, int expected)
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
   8:	86ae                	mv	a3,a1
  if (actual == expected) {
   a:	02c58463          	beq	a1,a2,32 <check+0x32>
    printf("[PASS] %s : got %d\n", test, actual);
    passed++;
  } else {
    printf("[FAIL] %s : expected %d, got %d\n", test, expected, actual);
   e:	85aa                	mv	a1,a0
  10:	00001517          	auipc	a0,0x1
  14:	dd850513          	addi	a0,a0,-552 # de8 <malloc+0x114>
  18:	409000ef          	jal	c20 <printf>
    failed++;
  1c:	00002717          	auipc	a4,0x2
  20:	fe470713          	addi	a4,a4,-28 # 2000 <failed>
  24:	431c                	lw	a5,0(a4)
  26:	2785                	addiw	a5,a5,1
  28:	c31c                	sw	a5,0(a4)
  }
}
  2a:	60a2                	ld	ra,8(sp)
  2c:	6402                	ld	s0,0(sp)
  2e:	0141                	addi	sp,sp,16
  30:	8082                	ret
    printf("[PASS] %s : got %d\n", test, actual);
  32:	862e                	mv	a2,a1
  34:	85aa                	mv	a1,a0
  36:	00001517          	auipc	a0,0x1
  3a:	d9a50513          	addi	a0,a0,-614 # dd0 <malloc+0xfc>
  3e:	3e3000ef          	jal	c20 <printf>
    passed++;
  42:	00002717          	auipc	a4,0x2
  46:	fc270713          	addi	a4,a4,-62 # 2004 <passed>
  4a:	431c                	lw	a5,0(a4)
  4c:	2785                	addiw	a5,a5,1
  4e:	c31c                	sw	a5,0(a4)
  50:	bfe9                	j	2a <check+0x2a>

0000000000000052 <main>:

int main()
{
  52:	1101                	addi	sp,sp,-32
  54:	ec06                	sd	ra,24(sp)
  56:	e822                	sd	s0,16(sp)
  58:	e426                	sd	s1,8(sp)
  5a:	1000                	addi	s0,sp,32
  int ret;
  int mypid = getpid();
  5c:	7f4000ef          	jal	850 <getpid>
  60:	84aa                	mv	s1,a0

  printf("[INFO] init(pid 1) and sh(pid 2) are created during boot.\n");
  62:	00001517          	auipc	a0,0x1
  66:	dae50513          	addi	a0,a0,-594 # e10 <malloc+0x13c>
  6a:	3b7000ef          	jal	c20 <printf>
  printf("[INFO] mytest(pid %d) is the current test program.\n", mypid);
  6e:	85a6                	mv	a1,s1
  70:	00001517          	auipc	a0,0x1
  74:	de050513          	addi	a0,a0,-544 # e50 <malloc+0x17c>
  78:	3a9000ef          	jal	c20 <printf>

  // ============================================================
  printf("========== Current Process State ==========\n");
  7c:	00001517          	auipc	a0,0x1
  80:	e0c50513          	addi	a0,a0,-500 # e88 <malloc+0x1b4>
  84:	39d000ef          	jal	c20 <printf>
  // ============================================================
  printf("[INFO] The following processes are already running:\n");
  88:	00001517          	auipc	a0,0x1
  8c:	e3050513          	addi	a0,a0,-464 # eb8 <malloc+0x1e4>
  90:	391000ef          	jal	c20 <printf>
  ps(0);
  94:	4501                	li	a0,0
  96:	7ea000ef          	jal	880 <ps>
  printf("\n");
  9a:	00001517          	auipc	a0,0x1
  9e:	e5650513          	addi	a0,a0,-426 # ef0 <malloc+0x21c>
  a2:	37f000ef          	jal	c20 <printf>

  // ============================================================
  printf("========== Testing getnice() ==========\n");
  a6:	00001517          	auipc	a0,0x1
  aa:	e5250513          	addi	a0,a0,-430 # ef8 <malloc+0x224>
  ae:	373000ef          	jal	c20 <printf>
  // ============================================================

  // pid 1 (init) exists, default nice = 20
  ret = getnice(1);
  b2:	4505                	li	a0,1
  b4:	7bc000ef          	jal	870 <getnice>
  b8:	85aa                	mv	a1,a0
  check("getnice(1) - init default nice", ret, 20);
  ba:	4651                	li	a2,20
  bc:	00001517          	auipc	a0,0x1
  c0:	e6c50513          	addi	a0,a0,-404 # f28 <malloc+0x254>
  c4:	f3dff0ef          	jal	0 <check>

  // pid 2 (sh) exists, default nice = 20
  ret = getnice(2);
  c8:	4509                	li	a0,2
  ca:	7a6000ef          	jal	870 <getnice>
  ce:	85aa                	mv	a1,a0
  check("getnice(2) - sh default nice", ret, 20);
  d0:	4651                	li	a2,20
  d2:	00001517          	auipc	a0,0x1
  d6:	e7650513          	addi	a0,a0,-394 # f48 <malloc+0x274>
  da:	f27ff0ef          	jal	0 <check>

  // mytest itself, default nice = 20
  ret = getnice(mypid);
  de:	8526                	mv	a0,s1
  e0:	790000ef          	jal	870 <getnice>
  e4:	85aa                	mv	a1,a0
  check("getnice(mytest) - mytest default nice", ret, 20);
  e6:	4651                	li	a2,20
  e8:	00001517          	auipc	a0,0x1
  ec:	e8050513          	addi	a0,a0,-384 # f68 <malloc+0x294>
  f0:	f11ff0ef          	jal	0 <check>

  // pid 12 does not exist → should return -1
  ret = getnice(12);
  f4:	4531                	li	a0,12
  f6:	77a000ef          	jal	870 <getnice>
  fa:	85aa                	mv	a1,a0
  check("getnice(12) - no such process", ret, -1);
  fc:	567d                	li	a2,-1
  fe:	00001517          	auipc	a0,0x1
 102:	e9250513          	addi	a0,a0,-366 # f90 <malloc+0x2bc>
 106:	efbff0ef          	jal	0 <check>

  printf("\n");
 10a:	00001517          	auipc	a0,0x1
 10e:	de650513          	addi	a0,a0,-538 # ef0 <malloc+0x21c>
 112:	30f000ef          	jal	c20 <printf>

  // ============================================================
  printf("========== Testing setnice() ==========\n");
 116:	00001517          	auipc	a0,0x1
 11a:	e9a50513          	addi	a0,a0,-358 # fb0 <malloc+0x2dc>
 11e:	303000ef          	jal	c20 <printf>
  // ============================================================

  // Set nice of pid 1 (init) to 10 → should succeed (return 0)
  ret = setnice(1, 10);
 122:	45a9                	li	a1,10
 124:	4505                	li	a0,1
 126:	752000ef          	jal	878 <setnice>
 12a:	85aa                	mv	a1,a0
  check("setnice(1, 10) - valid", ret, 0);
 12c:	4601                	li	a2,0
 12e:	00001517          	auipc	a0,0x1
 132:	eb250513          	addi	a0,a0,-334 # fe0 <malloc+0x30c>
 136:	ecbff0ef          	jal	0 <check>

  // Verify the change
  ret = getnice(1);
 13a:	4505                	li	a0,1
 13c:	734000ef          	jal	870 <getnice>
 140:	85aa                	mv	a1,a0
  check("getnice(1) - after setnice to 10", ret, 10);
 142:	4629                	li	a2,10
 144:	00001517          	auipc	a0,0x1
 148:	eb450513          	addi	a0,a0,-332 # ff8 <malloc+0x324>
 14c:	eb5ff0ef          	jal	0 <check>

  // Restore to default
  ret = setnice(1, 20);
 150:	45d1                	li	a1,20
 152:	4505                	li	a0,1
 154:	724000ef          	jal	878 <setnice>
 158:	85aa                	mv	a1,a0
  check("setnice(1, 20) - restore default", ret, 0);
 15a:	4601                	li	a2,0
 15c:	00001517          	auipc	a0,0x1
 160:	ec450513          	addi	a0,a0,-316 # 1020 <malloc+0x34c>
 164:	e9dff0ef          	jal	0 <check>

  // pid 12 does not exist → should return -1
  ret = setnice(12, 10);
 168:	45a9                	li	a1,10
 16a:	4531                	li	a0,12
 16c:	70c000ef          	jal	878 <setnice>
 170:	85aa                	mv	a1,a0
  check("setnice(12, 10) - no such process", ret, -1);
 172:	567d                	li	a2,-1
 174:	00001517          	auipc	a0,0x1
 178:	ed450513          	addi	a0,a0,-300 # 1048 <malloc+0x374>
 17c:	e85ff0ef          	jal	0 <check>

  // nice value 40 is out of range (valid: 0–39) → should return -1
  ret = setnice(1, 40);
 180:	02800593          	li	a1,40
 184:	4505                	li	a0,1
 186:	6f2000ef          	jal	878 <setnice>
 18a:	85aa                	mv	a1,a0
  check("setnice(1, 40) - invalid nice value", ret, -1);
 18c:	567d                	li	a2,-1
 18e:	00001517          	auipc	a0,0x1
 192:	ee250513          	addi	a0,a0,-286 # 1070 <malloc+0x39c>
 196:	e6bff0ef          	jal	0 <check>

  // nice value -1 is out of range → should return -1
  ret = setnice(1, -1);
 19a:	55fd                	li	a1,-1
 19c:	4505                	li	a0,1
 19e:	6da000ef          	jal	878 <setnice>
 1a2:	85aa                	mv	a1,a0
  check("setnice(1, -1) - negative nice value", ret, -1);
 1a4:	567d                	li	a2,-1
 1a6:	00001517          	auipc	a0,0x1
 1aa:	ef250513          	addi	a0,a0,-270 # 1098 <malloc+0x3c4>
 1ae:	e53ff0ef          	jal	0 <check>

  // Boundary: minimum valid nice value (0)
  ret = setnice(1, 0);
 1b2:	4581                	li	a1,0
 1b4:	4505                	li	a0,1
 1b6:	6c2000ef          	jal	878 <setnice>
 1ba:	85aa                	mv	a1,a0
  check("setnice(1, 0) - minimum valid", ret, 0);
 1bc:	4601                	li	a2,0
 1be:	00001517          	auipc	a0,0x1
 1c2:	f0250513          	addi	a0,a0,-254 # 10c0 <malloc+0x3ec>
 1c6:	e3bff0ef          	jal	0 <check>
  ret = getnice(1);
 1ca:	4505                	li	a0,1
 1cc:	6a4000ef          	jal	870 <getnice>
 1d0:	85aa                	mv	a1,a0
  check("getnice(1) - after setnice to 0", ret, 0);
 1d2:	4601                	li	a2,0
 1d4:	00001517          	auipc	a0,0x1
 1d8:	f0c50513          	addi	a0,a0,-244 # 10e0 <malloc+0x40c>
 1dc:	e25ff0ef          	jal	0 <check>
  setnice(1, 20); // restore
 1e0:	45d1                	li	a1,20
 1e2:	4505                	li	a0,1
 1e4:	694000ef          	jal	878 <setnice>

  // Boundary: maximum valid nice value (39)
  ret = setnice(1, 39);
 1e8:	02700593          	li	a1,39
 1ec:	4505                	li	a0,1
 1ee:	68a000ef          	jal	878 <setnice>
 1f2:	85aa                	mv	a1,a0
  check("setnice(1, 39) - maximum valid", ret, 0);
 1f4:	4601                	li	a2,0
 1f6:	00001517          	auipc	a0,0x1
 1fa:	f0a50513          	addi	a0,a0,-246 # 1100 <malloc+0x42c>
 1fe:	e03ff0ef          	jal	0 <check>
  ret = getnice(1);
 202:	4505                	li	a0,1
 204:	66c000ef          	jal	870 <getnice>
 208:	85aa                	mv	a1,a0
  check("getnice(1) - after setnice to 39", ret, 39);
 20a:	02700613          	li	a2,39
 20e:	00001517          	auipc	a0,0x1
 212:	f1250513          	addi	a0,a0,-238 # 1120 <malloc+0x44c>
 216:	debff0ef          	jal	0 <check>
  setnice(1, 20); // restore
 21a:	45d1                	li	a1,20
 21c:	4505                	li	a0,1
 21e:	65a000ef          	jal	878 <setnice>

  printf("\n");
 222:	00001517          	auipc	a0,0x1
 226:	cce50513          	addi	a0,a0,-818 # ef0 <malloc+0x21c>
 22a:	1f7000ef          	jal	c20 <printf>

  // ============================================================
  printf("========== Testing getnice() / setnice() on self ==========\n");
 22e:	00001517          	auipc	a0,0x1
 232:	f1a50513          	addi	a0,a0,-230 # 1148 <malloc+0x474>
 236:	1eb000ef          	jal	c20 <printf>
  // ============================================================
  // mytest itself — test that a process can read and modify its own nice value

  ret = setnice(mypid, 5);
 23a:	4595                	li	a1,5
 23c:	8526                	mv	a0,s1
 23e:	63a000ef          	jal	878 <setnice>
 242:	85aa                	mv	a1,a0
  check("setnice(mytest, 5) - set mytest priority", ret, 0);
 244:	4601                	li	a2,0
 246:	00001517          	auipc	a0,0x1
 24a:	f4250513          	addi	a0,a0,-190 # 1188 <malloc+0x4b4>
 24e:	db3ff0ef          	jal	0 <check>

  ret = getnice(mypid);
 252:	8526                	mv	a0,s1
 254:	61c000ef          	jal	870 <getnice>
 258:	85aa                	mv	a1,a0
  check("getnice(mytest) - after setnice to 5", ret, 5);
 25a:	4615                	li	a2,5
 25c:	00001517          	auipc	a0,0x1
 260:	f5c50513          	addi	a0,a0,-164 # 11b8 <malloc+0x4e4>
 264:	d9dff0ef          	jal	0 <check>

  printf("[INFO] ps(%d) - mytest should show priority 5:\n", mypid);
 268:	85a6                	mv	a1,s1
 26a:	00001517          	auipc	a0,0x1
 26e:	f7650513          	addi	a0,a0,-138 # 11e0 <malloc+0x50c>
 272:	1af000ef          	jal	c20 <printf>
  ps(mypid);
 276:	8526                	mv	a0,s1
 278:	608000ef          	jal	880 <ps>

  ret = setnice(mypid, 20);
 27c:	45d1                	li	a1,20
 27e:	8526                	mv	a0,s1
 280:	5f8000ef          	jal	878 <setnice>
 284:	85aa                	mv	a1,a0
  check("setnice(mytest, 20) - restore mytest nice", ret, 0);
 286:	4601                	li	a2,0
 288:	00001517          	auipc	a0,0x1
 28c:	f8850513          	addi	a0,a0,-120 # 1210 <malloc+0x53c>
 290:	d71ff0ef          	jal	0 <check>

  printf("\n");
 294:	00001517          	auipc	a0,0x1
 298:	c5c50513          	addi	a0,a0,-932 # ef0 <malloc+0x21c>
 29c:	185000ef          	jal	c20 <printf>

  // ============================================================
  printf("========== Testing ps() ==========\n");
 2a0:	00001517          	auipc	a0,0x1
 2a4:	fa050513          	addi	a0,a0,-96 # 1240 <malloc+0x56c>
 2a8:	179000ef          	jal	c20 <printf>
  // ============================================================

  // ps(0) prints all processes — verify visually
  printf("[INFO] ps(0) - should print all processes (init, sh, mytest):\n");
 2ac:	00001517          	auipc	a0,0x1
 2b0:	fbc50513          	addi	a0,a0,-68 # 1268 <malloc+0x594>
 2b4:	16d000ef          	jal	c20 <printf>
  ps(0);
 2b8:	4501                	li	a0,0
 2ba:	5c6000ef          	jal	880 <ps>
  printf("\n");
 2be:	00001517          	auipc	a0,0x1
 2c2:	c3250513          	addi	a0,a0,-974 # ef0 <malloc+0x21c>
 2c6:	15b000ef          	jal	c20 <printf>

  // ps(1) prints only init
  printf("[INFO] ps(1) - should print only init:\n");
 2ca:	00001517          	auipc	a0,0x1
 2ce:	fde50513          	addi	a0,a0,-34 # 12a8 <malloc+0x5d4>
 2d2:	14f000ef          	jal	c20 <printf>
  ps(1);
 2d6:	4505                	li	a0,1
 2d8:	5a8000ef          	jal	880 <ps>
  printf("\n");
 2dc:	00001517          	auipc	a0,0x1
 2e0:	c1450513          	addi	a0,a0,-1004 # ef0 <malloc+0x21c>
 2e4:	13d000ef          	jal	c20 <printf>

  // ps(12) — no such process, should print nothing
  printf("[INFO] ps(12) - no such process, should print nothing:\n");
 2e8:	00001517          	auipc	a0,0x1
 2ec:	fe850513          	addi	a0,a0,-24 # 12d0 <malloc+0x5fc>
 2f0:	131000ef          	jal	c20 <printf>
  ps(12);
 2f4:	4531                	li	a0,12
 2f6:	58a000ef          	jal	880 <ps>
  printf("[INFO] (no output expected above)\n");
 2fa:	00001517          	auipc	a0,0x1
 2fe:	00e50513          	addi	a0,a0,14 # 1308 <malloc+0x634>
 302:	11f000ef          	jal	c20 <printf>
  printf("\n");
 306:	00001517          	auipc	a0,0x1
 30a:	bea50513          	addi	a0,a0,-1046 # ef0 <malloc+0x21c>
 30e:	113000ef          	jal	c20 <printf>

  // ps reflects setnice changes — set init nice to 7, verify visually, restore
  setnice(1, 7);
 312:	459d                	li	a1,7
 314:	4505                	li	a0,1
 316:	562000ef          	jal	878 <setnice>
  printf("[INFO] ps(1) - init priority should show 7:\n");
 31a:	00001517          	auipc	a0,0x1
 31e:	01650513          	addi	a0,a0,22 # 1330 <malloc+0x65c>
 322:	0ff000ef          	jal	c20 <printf>
  ps(1);
 326:	4505                	li	a0,1
 328:	558000ef          	jal	880 <ps>
  setnice(1, 20);
 32c:	45d1                	li	a1,20
 32e:	4505                	li	a0,1
 330:	548000ef          	jal	878 <setnice>
  printf("[INFO] ps(1) - init priority restored to 20:\n");
 334:	00001517          	auipc	a0,0x1
 338:	02c50513          	addi	a0,a0,44 # 1360 <malloc+0x68c>
 33c:	0e5000ef          	jal	c20 <printf>
  ps(1);
 340:	4505                	li	a0,1
 342:	53e000ef          	jal	880 <ps>

  printf("\n");
 346:	00001517          	auipc	a0,0x1
 34a:	baa50513          	addi	a0,a0,-1110 # ef0 <malloc+0x21c>
 34e:	0d3000ef          	jal	c20 <printf>

  // ============================================================
  printf("========== Testing meminfo() ==========\n");
 352:	00001517          	auipc	a0,0x1
 356:	03e50513          	addi	a0,a0,62 # 1390 <malloc+0x6bc>
 35a:	0c7000ef          	jal	c20 <printf>
  // ============================================================

  uint64 mem = meminfo();
 35e:	52a000ef          	jal	888 <meminfo>
  if (mem > 0) {
 362:	c925                	beqz	a0,3d2 <main+0x380>
 364:	85aa                	mv	a1,a0
    printf("[PASS] meminfo() - free memory: %lu bytes\n", mem);
 366:	00001517          	auipc	a0,0x1
 36a:	05a50513          	addi	a0,a0,90 # 13c0 <malloc+0x6ec>
 36e:	0b3000ef          	jal	c20 <printf>
    passed++;
 372:	00002717          	auipc	a4,0x2
 376:	c9270713          	addi	a4,a4,-878 # 2004 <passed>
 37a:	431c                	lw	a5,0(a4)
 37c:	2785                	addiw	a5,a5,1
 37e:	c31c                	sw	a5,0(a4)
    printf("[FAIL] meminfo() - expected > 0, got %lu\n", mem);
    failed++;
  }

  // Call meminfo twice — both results should be positive and consistent
  uint64 mem1 = meminfo();
 380:	508000ef          	jal	888 <meminfo>
 384:	84aa                	mv	s1,a0
  uint64 mem2 = meminfo();
 386:	502000ef          	jal	888 <meminfo>
 38a:	862a                	mv	a2,a0
  if (mem1 > 0 && mem2 > 0) {
 38c:	c091                	beqz	s1,390 <main+0x33e>
 38e:	e12d                	bnez	a0,3f0 <main+0x39e>
    printf("[PASS] meminfo() - consistent: %lu / %lu bytes\n", mem1, mem2);
    passed++;
  } else {
    printf("[FAIL] meminfo() - inconsistent or zero: %lu / %lu\n", mem1, mem2);
 390:	85a6                	mv	a1,s1
 392:	00001517          	auipc	a0,0x1
 396:	0be50513          	addi	a0,a0,190 # 1450 <malloc+0x77c>
 39a:	087000ef          	jal	c20 <printf>
    failed++;
 39e:	00002717          	auipc	a4,0x2
 3a2:	c6270713          	addi	a4,a4,-926 # 2000 <failed>
 3a6:	431c                	lw	a5,0(a4)
 3a8:	2785                	addiw	a5,a5,1
 3aa:	c31c                	sw	a5,0(a4)
  }

  printf("\n");
 3ac:	00001517          	auipc	a0,0x1
 3b0:	b4450513          	addi	a0,a0,-1212 # ef0 <malloc+0x21c>
 3b4:	06d000ef          	jal	c20 <printf>

  // ============================================================
  printf("========== Testing waitpid() ==========\n");
 3b8:	00001517          	auipc	a0,0x1
 3bc:	0d050513          	addi	a0,a0,208 # 1488 <malloc+0x7b4>
 3c0:	061000ef          	jal	c20 <printf>
  // ============================================================

  // Test 1: fork a child, then waitpid for it
  int pid1 = fork();
 3c4:	404000ef          	jal	7c8 <fork>
  if (pid1 < 0) {
 3c8:	04054363          	bltz	a0,40e <main+0x3bc>
    printf("[FAIL] fork() failed\n");
    failed++;
  } else if (pid1 == 0) {
 3cc:	ed39                	bnez	a0,42a <main+0x3d8>
    exit(0);
 3ce:	402000ef          	jal	7d0 <exit>
    printf("[FAIL] meminfo() - expected > 0, got %lu\n", mem);
 3d2:	4581                	li	a1,0
 3d4:	00001517          	auipc	a0,0x1
 3d8:	01c50513          	addi	a0,a0,28 # 13f0 <malloc+0x71c>
 3dc:	045000ef          	jal	c20 <printf>
    failed++;
 3e0:	00002717          	auipc	a4,0x2
 3e4:	c2070713          	addi	a4,a4,-992 # 2000 <failed>
 3e8:	431c                	lw	a5,0(a4)
 3ea:	2785                	addiw	a5,a5,1
 3ec:	c31c                	sw	a5,0(a4)
 3ee:	bf49                	j	380 <main+0x32e>
    printf("[PASS] meminfo() - consistent: %lu / %lu bytes\n", mem1, mem2);
 3f0:	85a6                	mv	a1,s1
 3f2:	00001517          	auipc	a0,0x1
 3f6:	02e50513          	addi	a0,a0,46 # 1420 <malloc+0x74c>
 3fa:	027000ef          	jal	c20 <printf>
    passed++;
 3fe:	00002717          	auipc	a4,0x2
 402:	c0670713          	addi	a4,a4,-1018 # 2004 <passed>
 406:	431c                	lw	a5,0(a4)
 408:	2785                	addiw	a5,a5,1
 40a:	c31c                	sw	a5,0(a4)
 40c:	b745                	j	3ac <main+0x35a>
    printf("[FAIL] fork() failed\n");
 40e:	00001517          	auipc	a0,0x1
 412:	0aa50513          	addi	a0,a0,170 # 14b8 <malloc+0x7e4>
 416:	00b000ef          	jal	c20 <printf>
    failed++;
 41a:	00002717          	auipc	a4,0x2
 41e:	be670713          	addi	a4,a4,-1050 # 2000 <failed>
 422:	431c                	lw	a5,0(a4)
 424:	2785                	addiw	a5,a5,1
 426:	c31c                	sw	a5,0(a4)
 428:	a819                	j	43e <main+0x3ec>
  } else {
    ret = waitpid(pid1);
 42a:	466000ef          	jal	890 <waitpid>
 42e:	85aa                	mv	a1,a0
    check("waitpid(pid1) - child exited", ret, 0);
 430:	4601                	li	a2,0
 432:	00001517          	auipc	a0,0x1
 436:	09e50513          	addi	a0,a0,158 # 14d0 <malloc+0x7fc>
 43a:	bc7ff0ef          	jal	0 <check>
  }

  // Test 2: fork another child, waitpid for it
  int pid2 = fork();
 43e:	38a000ef          	jal	7c8 <fork>
  if (pid2 < 0) {
 442:	00054563          	bltz	a0,44c <main+0x3fa>
    printf("[FAIL] fork() failed\n");
    failed++;
  } else if (pid2 == 0) {
 446:	e10d                	bnez	a0,468 <main+0x416>
    exit(0);
 448:	388000ef          	jal	7d0 <exit>
    printf("[FAIL] fork() failed\n");
 44c:	00001517          	auipc	a0,0x1
 450:	06c50513          	addi	a0,a0,108 # 14b8 <malloc+0x7e4>
 454:	7cc000ef          	jal	c20 <printf>
    failed++;
 458:	00002717          	auipc	a4,0x2
 45c:	ba870713          	addi	a4,a4,-1112 # 2000 <failed>
 460:	431c                	lw	a5,0(a4)
 462:	2785                	addiw	a5,a5,1
 464:	c31c                	sw	a5,0(a4)
 466:	a819                	j	47c <main+0x42a>
  } else {
    ret = waitpid(pid2);
 468:	428000ef          	jal	890 <waitpid>
 46c:	85aa                	mv	a1,a0
    check("waitpid(pid2) - child exited", ret, 0);
 46e:	4601                	li	a2,0
 470:	00001517          	auipc	a0,0x1
 474:	08050513          	addi	a0,a0,128 # 14f0 <malloc+0x81c>
 478:	b89ff0ef          	jal	0 <check>
  }

  // Test 3: waitpid for init (pid 1) — not our child, should fail
  ret = waitpid(1);
 47c:	4505                	li	a0,1
 47e:	412000ef          	jal	890 <waitpid>
 482:	85aa                	mv	a1,a0
  check("waitpid(1) - not our child", ret, -1);
 484:	567d                	li	a2,-1
 486:	00001517          	auipc	a0,0x1
 48a:	08a50513          	addi	a0,a0,138 # 1510 <malloc+0x83c>
 48e:	b73ff0ef          	jal	0 <check>

  // Test 4: waitpid for non-existent pid — should fail
  ret = waitpid(99);
 492:	06300513          	li	a0,99
 496:	3fa000ef          	jal	890 <waitpid>
 49a:	85aa                	mv	a1,a0
  check("waitpid(99) - no such process", ret, -1);
 49c:	567d                	li	a2,-1
 49e:	00001517          	auipc	a0,0x1
 4a2:	09250513          	addi	a0,a0,146 # 1530 <malloc+0x85c>
 4a6:	b5bff0ef          	jal	0 <check>

  // Test 5: waitpid twice on the same pid — second call should fail
  // after freeproc(), the process slot is released and the pid no longer exists
  int pid3 = fork();
 4aa:	31e000ef          	jal	7c8 <fork>
 4ae:	84aa                	mv	s1,a0
  if (pid3 < 0) {
 4b0:	00054663          	bltz	a0,4bc <main+0x46a>
    printf("[FAIL] fork() failed\n");
    failed++;
  } else if (pid3 == 0) {
 4b4:	e115                	bnez	a0,4d8 <main+0x486>
    exit(0);
 4b6:	4501                	li	a0,0
 4b8:	318000ef          	jal	7d0 <exit>
    printf("[FAIL] fork() failed\n");
 4bc:	00001517          	auipc	a0,0x1
 4c0:	ffc50513          	addi	a0,a0,-4 # 14b8 <malloc+0x7e4>
 4c4:	75c000ef          	jal	c20 <printf>
    failed++;
 4c8:	00002717          	auipc	a4,0x2
 4cc:	b3870713          	addi	a4,a4,-1224 # 2000 <failed>
 4d0:	431c                	lw	a5,0(a4)
 4d2:	2785                	addiw	a5,a5,1
 4d4:	c31c                	sw	a5,0(a4)
 4d6:	a035                	j	502 <main+0x4b0>
  } else {
    ret = waitpid(pid3);
 4d8:	3b8000ef          	jal	890 <waitpid>
 4dc:	85aa                	mv	a1,a0
    check("waitpid(pid3) - first wait", ret, 0);
 4de:	4601                	li	a2,0
 4e0:	00001517          	auipc	a0,0x1
 4e4:	07050513          	addi	a0,a0,112 # 1550 <malloc+0x87c>
 4e8:	b19ff0ef          	jal	0 <check>
    ret = waitpid(pid3);
 4ec:	8526                	mv	a0,s1
 4ee:	3a2000ef          	jal	890 <waitpid>
 4f2:	85aa                	mv	a1,a0
    check("waitpid(pid3) - already reaped", ret, -1);
 4f4:	567d                	li	a2,-1
 4f6:	00001517          	auipc	a0,0x1
 4fa:	07a50513          	addi	a0,a0,122 # 1570 <malloc+0x89c>
 4fe:	b03ff0ef          	jal	0 <check>
  }

  printf("\n");
 502:	00001517          	auipc	a0,0x1
 506:	9ee50513          	addi	a0,a0,-1554 # ef0 <malloc+0x21c>
 50a:	716000ef          	jal	c20 <printf>

  // ============================================================
  printf("========== Summary ==========\n");
 50e:	00001517          	auipc	a0,0x1
 512:	08250513          	addi	a0,a0,130 # 1590 <malloc+0x8bc>
 516:	70a000ef          	jal	c20 <printf>
  // ============================================================
  printf("Total: %d passed, %d failed\n", passed, failed);
 51a:	00002617          	auipc	a2,0x2
 51e:	ae662603          	lw	a2,-1306(a2) # 2000 <failed>
 522:	00002597          	auipc	a1,0x2
 526:	ae25a583          	lw	a1,-1310(a1) # 2004 <passed>
 52a:	00001517          	auipc	a0,0x1
 52e:	08650513          	addi	a0,a0,134 # 15b0 <malloc+0x8dc>
 532:	6ee000ef          	jal	c20 <printf>

  exit(0);
 536:	4501                	li	a0,0
 538:	298000ef          	jal	7d0 <exit>

000000000000053c <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 53c:	1141                	addi	sp,sp,-16
 53e:	e406                	sd	ra,8(sp)
 540:	e022                	sd	s0,0(sp)
 542:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 544:	b0fff0ef          	jal	52 <main>
  exit(r);
 548:	288000ef          	jal	7d0 <exit>

000000000000054c <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 54c:	1141                	addi	sp,sp,-16
 54e:	e422                	sd	s0,8(sp)
 550:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 552:	87aa                	mv	a5,a0
 554:	0585                	addi	a1,a1,1
 556:	0785                	addi	a5,a5,1
 558:	fff5c703          	lbu	a4,-1(a1)
 55c:	fee78fa3          	sb	a4,-1(a5)
 560:	fb75                	bnez	a4,554 <strcpy+0x8>
    ;
  return os;
}
 562:	6422                	ld	s0,8(sp)
 564:	0141                	addi	sp,sp,16
 566:	8082                	ret

0000000000000568 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 568:	1141                	addi	sp,sp,-16
 56a:	e422                	sd	s0,8(sp)
 56c:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 56e:	00054783          	lbu	a5,0(a0)
 572:	cb91                	beqz	a5,586 <strcmp+0x1e>
 574:	0005c703          	lbu	a4,0(a1)
 578:	00f71763          	bne	a4,a5,586 <strcmp+0x1e>
    p++, q++;
 57c:	0505                	addi	a0,a0,1
 57e:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 580:	00054783          	lbu	a5,0(a0)
 584:	fbe5                	bnez	a5,574 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 586:	0005c503          	lbu	a0,0(a1)
}
 58a:	40a7853b          	subw	a0,a5,a0
 58e:	6422                	ld	s0,8(sp)
 590:	0141                	addi	sp,sp,16
 592:	8082                	ret

0000000000000594 <strlen>:

uint
strlen(const char *s)
{
 594:	1141                	addi	sp,sp,-16
 596:	e422                	sd	s0,8(sp)
 598:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 59a:	00054783          	lbu	a5,0(a0)
 59e:	cf91                	beqz	a5,5ba <strlen+0x26>
 5a0:	0505                	addi	a0,a0,1
 5a2:	87aa                	mv	a5,a0
 5a4:	86be                	mv	a3,a5
 5a6:	0785                	addi	a5,a5,1
 5a8:	fff7c703          	lbu	a4,-1(a5)
 5ac:	ff65                	bnez	a4,5a4 <strlen+0x10>
 5ae:	40a6853b          	subw	a0,a3,a0
 5b2:	2505                	addiw	a0,a0,1
    ;
  return n;
}
 5b4:	6422                	ld	s0,8(sp)
 5b6:	0141                	addi	sp,sp,16
 5b8:	8082                	ret
  for(n = 0; s[n]; n++)
 5ba:	4501                	li	a0,0
 5bc:	bfe5                	j	5b4 <strlen+0x20>

00000000000005be <memset>:

void*
memset(void *dst, int c, uint n)
{
 5be:	1141                	addi	sp,sp,-16
 5c0:	e422                	sd	s0,8(sp)
 5c2:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 5c4:	ca19                	beqz	a2,5da <memset+0x1c>
 5c6:	87aa                	mv	a5,a0
 5c8:	1602                	slli	a2,a2,0x20
 5ca:	9201                	srli	a2,a2,0x20
 5cc:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 5d0:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 5d4:	0785                	addi	a5,a5,1
 5d6:	fee79de3          	bne	a5,a4,5d0 <memset+0x12>
  }
  return dst;
}
 5da:	6422                	ld	s0,8(sp)
 5dc:	0141                	addi	sp,sp,16
 5de:	8082                	ret

00000000000005e0 <strchr>:

char*
strchr(const char *s, char c)
{
 5e0:	1141                	addi	sp,sp,-16
 5e2:	e422                	sd	s0,8(sp)
 5e4:	0800                	addi	s0,sp,16
  for(; *s; s++)
 5e6:	00054783          	lbu	a5,0(a0)
 5ea:	cb99                	beqz	a5,600 <strchr+0x20>
    if(*s == c)
 5ec:	00f58763          	beq	a1,a5,5fa <strchr+0x1a>
  for(; *s; s++)
 5f0:	0505                	addi	a0,a0,1
 5f2:	00054783          	lbu	a5,0(a0)
 5f6:	fbfd                	bnez	a5,5ec <strchr+0xc>
      return (char*)s;
  return 0;
 5f8:	4501                	li	a0,0
}
 5fa:	6422                	ld	s0,8(sp)
 5fc:	0141                	addi	sp,sp,16
 5fe:	8082                	ret
  return 0;
 600:	4501                	li	a0,0
 602:	bfe5                	j	5fa <strchr+0x1a>

0000000000000604 <gets>:

char*
gets(char *buf, int max)
{
 604:	711d                	addi	sp,sp,-96
 606:	ec86                	sd	ra,88(sp)
 608:	e8a2                	sd	s0,80(sp)
 60a:	e4a6                	sd	s1,72(sp)
 60c:	e0ca                	sd	s2,64(sp)
 60e:	fc4e                	sd	s3,56(sp)
 610:	f852                	sd	s4,48(sp)
 612:	f456                	sd	s5,40(sp)
 614:	f05a                	sd	s6,32(sp)
 616:	ec5e                	sd	s7,24(sp)
 618:	1080                	addi	s0,sp,96
 61a:	8baa                	mv	s7,a0
 61c:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 61e:	892a                	mv	s2,a0
 620:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 622:	4aa9                	li	s5,10
 624:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 626:	89a6                	mv	s3,s1
 628:	2485                	addiw	s1,s1,1
 62a:	0344d663          	bge	s1,s4,656 <gets+0x52>
    cc = read(0, &c, 1);
 62e:	4605                	li	a2,1
 630:	faf40593          	addi	a1,s0,-81
 634:	4501                	li	a0,0
 636:	1b2000ef          	jal	7e8 <read>
    if(cc < 1)
 63a:	00a05e63          	blez	a0,656 <gets+0x52>
    buf[i++] = c;
 63e:	faf44783          	lbu	a5,-81(s0)
 642:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 646:	01578763          	beq	a5,s5,654 <gets+0x50>
 64a:	0905                	addi	s2,s2,1
 64c:	fd679de3          	bne	a5,s6,626 <gets+0x22>
    buf[i++] = c;
 650:	89a6                	mv	s3,s1
 652:	a011                	j	656 <gets+0x52>
 654:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 656:	99de                	add	s3,s3,s7
 658:	00098023          	sb	zero,0(s3)
  return buf;
}
 65c:	855e                	mv	a0,s7
 65e:	60e6                	ld	ra,88(sp)
 660:	6446                	ld	s0,80(sp)
 662:	64a6                	ld	s1,72(sp)
 664:	6906                	ld	s2,64(sp)
 666:	79e2                	ld	s3,56(sp)
 668:	7a42                	ld	s4,48(sp)
 66a:	7aa2                	ld	s5,40(sp)
 66c:	7b02                	ld	s6,32(sp)
 66e:	6be2                	ld	s7,24(sp)
 670:	6125                	addi	sp,sp,96
 672:	8082                	ret

0000000000000674 <stat>:

int
stat(const char *n, struct stat *st)
{
 674:	1101                	addi	sp,sp,-32
 676:	ec06                	sd	ra,24(sp)
 678:	e822                	sd	s0,16(sp)
 67a:	e04a                	sd	s2,0(sp)
 67c:	1000                	addi	s0,sp,32
 67e:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 680:	4581                	li	a1,0
 682:	18e000ef          	jal	810 <open>
  if(fd < 0)
 686:	02054263          	bltz	a0,6aa <stat+0x36>
 68a:	e426                	sd	s1,8(sp)
 68c:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 68e:	85ca                	mv	a1,s2
 690:	198000ef          	jal	828 <fstat>
 694:	892a                	mv	s2,a0
  close(fd);
 696:	8526                	mv	a0,s1
 698:	160000ef          	jal	7f8 <close>
  return r;
 69c:	64a2                	ld	s1,8(sp)
}
 69e:	854a                	mv	a0,s2
 6a0:	60e2                	ld	ra,24(sp)
 6a2:	6442                	ld	s0,16(sp)
 6a4:	6902                	ld	s2,0(sp)
 6a6:	6105                	addi	sp,sp,32
 6a8:	8082                	ret
    return -1;
 6aa:	597d                	li	s2,-1
 6ac:	bfcd                	j	69e <stat+0x2a>

00000000000006ae <atoi>:

int
atoi(const char *s)
{
 6ae:	1141                	addi	sp,sp,-16
 6b0:	e422                	sd	s0,8(sp)
 6b2:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 6b4:	00054683          	lbu	a3,0(a0)
 6b8:	fd06879b          	addiw	a5,a3,-48
 6bc:	0ff7f793          	zext.b	a5,a5
 6c0:	4625                	li	a2,9
 6c2:	02f66863          	bltu	a2,a5,6f2 <atoi+0x44>
 6c6:	872a                	mv	a4,a0
  n = 0;
 6c8:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 6ca:	0705                	addi	a4,a4,1
 6cc:	0025179b          	slliw	a5,a0,0x2
 6d0:	9fa9                	addw	a5,a5,a0
 6d2:	0017979b          	slliw	a5,a5,0x1
 6d6:	9fb5                	addw	a5,a5,a3
 6d8:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 6dc:	00074683          	lbu	a3,0(a4)
 6e0:	fd06879b          	addiw	a5,a3,-48
 6e4:	0ff7f793          	zext.b	a5,a5
 6e8:	fef671e3          	bgeu	a2,a5,6ca <atoi+0x1c>
  return n;
}
 6ec:	6422                	ld	s0,8(sp)
 6ee:	0141                	addi	sp,sp,16
 6f0:	8082                	ret
  n = 0;
 6f2:	4501                	li	a0,0
 6f4:	bfe5                	j	6ec <atoi+0x3e>

00000000000006f6 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 6f6:	1141                	addi	sp,sp,-16
 6f8:	e422                	sd	s0,8(sp)
 6fa:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 6fc:	02b57463          	bgeu	a0,a1,724 <memmove+0x2e>
    while(n-- > 0)
 700:	00c05f63          	blez	a2,71e <memmove+0x28>
 704:	1602                	slli	a2,a2,0x20
 706:	9201                	srli	a2,a2,0x20
 708:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 70c:	872a                	mv	a4,a0
      *dst++ = *src++;
 70e:	0585                	addi	a1,a1,1
 710:	0705                	addi	a4,a4,1
 712:	fff5c683          	lbu	a3,-1(a1)
 716:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 71a:	fef71ae3          	bne	a4,a5,70e <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 71e:	6422                	ld	s0,8(sp)
 720:	0141                	addi	sp,sp,16
 722:	8082                	ret
    dst += n;
 724:	00c50733          	add	a4,a0,a2
    src += n;
 728:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 72a:	fec05ae3          	blez	a2,71e <memmove+0x28>
 72e:	fff6079b          	addiw	a5,a2,-1
 732:	1782                	slli	a5,a5,0x20
 734:	9381                	srli	a5,a5,0x20
 736:	fff7c793          	not	a5,a5
 73a:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 73c:	15fd                	addi	a1,a1,-1
 73e:	177d                	addi	a4,a4,-1
 740:	0005c683          	lbu	a3,0(a1)
 744:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 748:	fee79ae3          	bne	a5,a4,73c <memmove+0x46>
 74c:	bfc9                	j	71e <memmove+0x28>

000000000000074e <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 74e:	1141                	addi	sp,sp,-16
 750:	e422                	sd	s0,8(sp)
 752:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 754:	ca05                	beqz	a2,784 <memcmp+0x36>
 756:	fff6069b          	addiw	a3,a2,-1
 75a:	1682                	slli	a3,a3,0x20
 75c:	9281                	srli	a3,a3,0x20
 75e:	0685                	addi	a3,a3,1
 760:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 762:	00054783          	lbu	a5,0(a0)
 766:	0005c703          	lbu	a4,0(a1)
 76a:	00e79863          	bne	a5,a4,77a <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 76e:	0505                	addi	a0,a0,1
    p2++;
 770:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 772:	fed518e3          	bne	a0,a3,762 <memcmp+0x14>
  }
  return 0;
 776:	4501                	li	a0,0
 778:	a019                	j	77e <memcmp+0x30>
      return *p1 - *p2;
 77a:	40e7853b          	subw	a0,a5,a4
}
 77e:	6422                	ld	s0,8(sp)
 780:	0141                	addi	sp,sp,16
 782:	8082                	ret
  return 0;
 784:	4501                	li	a0,0
 786:	bfe5                	j	77e <memcmp+0x30>

0000000000000788 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 788:	1141                	addi	sp,sp,-16
 78a:	e406                	sd	ra,8(sp)
 78c:	e022                	sd	s0,0(sp)
 78e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 790:	f67ff0ef          	jal	6f6 <memmove>
}
 794:	60a2                	ld	ra,8(sp)
 796:	6402                	ld	s0,0(sp)
 798:	0141                	addi	sp,sp,16
 79a:	8082                	ret

000000000000079c <sbrk>:

char *
sbrk(int n) {
 79c:	1141                	addi	sp,sp,-16
 79e:	e406                	sd	ra,8(sp)
 7a0:	e022                	sd	s0,0(sp)
 7a2:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 7a4:	4585                	li	a1,1
 7a6:	0b2000ef          	jal	858 <sys_sbrk>
}
 7aa:	60a2                	ld	ra,8(sp)
 7ac:	6402                	ld	s0,0(sp)
 7ae:	0141                	addi	sp,sp,16
 7b0:	8082                	ret

00000000000007b2 <sbrklazy>:

char *
sbrklazy(int n) {
 7b2:	1141                	addi	sp,sp,-16
 7b4:	e406                	sd	ra,8(sp)
 7b6:	e022                	sd	s0,0(sp)
 7b8:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 7ba:	4589                	li	a1,2
 7bc:	09c000ef          	jal	858 <sys_sbrk>
}
 7c0:	60a2                	ld	ra,8(sp)
 7c2:	6402                	ld	s0,0(sp)
 7c4:	0141                	addi	sp,sp,16
 7c6:	8082                	ret

00000000000007c8 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 7c8:	4885                	li	a7,1
 ecall
 7ca:	00000073          	ecall
 ret
 7ce:	8082                	ret

00000000000007d0 <exit>:
.global exit
exit:
 li a7, SYS_exit
 7d0:	4889                	li	a7,2
 ecall
 7d2:	00000073          	ecall
 ret
 7d6:	8082                	ret

00000000000007d8 <wait>:
.global wait
wait:
 li a7, SYS_wait
 7d8:	488d                	li	a7,3
 ecall
 7da:	00000073          	ecall
 ret
 7de:	8082                	ret

00000000000007e0 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 7e0:	4891                	li	a7,4
 ecall
 7e2:	00000073          	ecall
 ret
 7e6:	8082                	ret

00000000000007e8 <read>:
.global read
read:
 li a7, SYS_read
 7e8:	4895                	li	a7,5
 ecall
 7ea:	00000073          	ecall
 ret
 7ee:	8082                	ret

00000000000007f0 <write>:
.global write
write:
 li a7, SYS_write
 7f0:	48c1                	li	a7,16
 ecall
 7f2:	00000073          	ecall
 ret
 7f6:	8082                	ret

00000000000007f8 <close>:
.global close
close:
 li a7, SYS_close
 7f8:	48d5                	li	a7,21
 ecall
 7fa:	00000073          	ecall
 ret
 7fe:	8082                	ret

0000000000000800 <kill>:
.global kill
kill:
 li a7, SYS_kill
 800:	4899                	li	a7,6
 ecall
 802:	00000073          	ecall
 ret
 806:	8082                	ret

0000000000000808 <exec>:
.global exec
exec:
 li a7, SYS_exec
 808:	489d                	li	a7,7
 ecall
 80a:	00000073          	ecall
 ret
 80e:	8082                	ret

0000000000000810 <open>:
.global open
open:
 li a7, SYS_open
 810:	48bd                	li	a7,15
 ecall
 812:	00000073          	ecall
 ret
 816:	8082                	ret

0000000000000818 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 818:	48c5                	li	a7,17
 ecall
 81a:	00000073          	ecall
 ret
 81e:	8082                	ret

0000000000000820 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 820:	48c9                	li	a7,18
 ecall
 822:	00000073          	ecall
 ret
 826:	8082                	ret

0000000000000828 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 828:	48a1                	li	a7,8
 ecall
 82a:	00000073          	ecall
 ret
 82e:	8082                	ret

0000000000000830 <link>:
.global link
link:
 li a7, SYS_link
 830:	48cd                	li	a7,19
 ecall
 832:	00000073          	ecall
 ret
 836:	8082                	ret

0000000000000838 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 838:	48d1                	li	a7,20
 ecall
 83a:	00000073          	ecall
 ret
 83e:	8082                	ret

0000000000000840 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 840:	48a5                	li	a7,9
 ecall
 842:	00000073          	ecall
 ret
 846:	8082                	ret

0000000000000848 <dup>:
.global dup
dup:
 li a7, SYS_dup
 848:	48a9                	li	a7,10
 ecall
 84a:	00000073          	ecall
 ret
 84e:	8082                	ret

0000000000000850 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 850:	48ad                	li	a7,11
 ecall
 852:	00000073          	ecall
 ret
 856:	8082                	ret

0000000000000858 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 858:	48b1                	li	a7,12
 ecall
 85a:	00000073          	ecall
 ret
 85e:	8082                	ret

0000000000000860 <pause>:
.global pause
pause:
 li a7, SYS_pause
 860:	48b5                	li	a7,13
 ecall
 862:	00000073          	ecall
 ret
 866:	8082                	ret

0000000000000868 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 868:	48b9                	li	a7,14
 ecall
 86a:	00000073          	ecall
 ret
 86e:	8082                	ret

0000000000000870 <getnice>:
.global getnice
getnice:
 li a7, SYS_getnice
 870:	48d9                	li	a7,22
 ecall
 872:	00000073          	ecall
 ret
 876:	8082                	ret

0000000000000878 <setnice>:
.global setnice
setnice:
 li a7, SYS_setnice
 878:	48dd                	li	a7,23
 ecall
 87a:	00000073          	ecall
 ret
 87e:	8082                	ret

0000000000000880 <ps>:
.global ps
ps:
 li a7, SYS_ps
 880:	48e1                	li	a7,24
 ecall
 882:	00000073          	ecall
 ret
 886:	8082                	ret

0000000000000888 <meminfo>:
.global meminfo
meminfo:
 li a7, SYS_meminfo
 888:	48e5                	li	a7,25
 ecall
 88a:	00000073          	ecall
 ret
 88e:	8082                	ret

0000000000000890 <waitpid>:
.global waitpid
waitpid:
 li a7, SYS_waitpid
 890:	48e9                	li	a7,26
 ecall
 892:	00000073          	ecall
 ret
 896:	8082                	ret

0000000000000898 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 898:	1101                	addi	sp,sp,-32
 89a:	ec06                	sd	ra,24(sp)
 89c:	e822                	sd	s0,16(sp)
 89e:	1000                	addi	s0,sp,32
 8a0:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 8a4:	4605                	li	a2,1
 8a6:	fef40593          	addi	a1,s0,-17
 8aa:	f47ff0ef          	jal	7f0 <write>
}
 8ae:	60e2                	ld	ra,24(sp)
 8b0:	6442                	ld	s0,16(sp)
 8b2:	6105                	addi	sp,sp,32
 8b4:	8082                	ret

00000000000008b6 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 8b6:	715d                	addi	sp,sp,-80
 8b8:	e486                	sd	ra,72(sp)
 8ba:	e0a2                	sd	s0,64(sp)
 8bc:	f84a                	sd	s2,48(sp)
 8be:	0880                	addi	s0,sp,80
 8c0:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 8c2:	c299                	beqz	a3,8c8 <printint+0x12>
 8c4:	0805c363          	bltz	a1,94a <printint+0x94>
  neg = 0;
 8c8:	4881                	li	a7,0
 8ca:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 8ce:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 8d0:	00001517          	auipc	a0,0x1
 8d4:	d0850513          	addi	a0,a0,-760 # 15d8 <digits>
 8d8:	883e                	mv	a6,a5
 8da:	2785                	addiw	a5,a5,1
 8dc:	02c5f733          	remu	a4,a1,a2
 8e0:	972a                	add	a4,a4,a0
 8e2:	00074703          	lbu	a4,0(a4)
 8e6:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 8ea:	872e                	mv	a4,a1
 8ec:	02c5d5b3          	divu	a1,a1,a2
 8f0:	0685                	addi	a3,a3,1
 8f2:	fec773e3          	bgeu	a4,a2,8d8 <printint+0x22>
  if(neg)
 8f6:	00088b63          	beqz	a7,90c <printint+0x56>
    buf[i++] = '-';
 8fa:	fd078793          	addi	a5,a5,-48
 8fe:	97a2                	add	a5,a5,s0
 900:	02d00713          	li	a4,45
 904:	fee78423          	sb	a4,-24(a5)
 908:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 90c:	02f05a63          	blez	a5,940 <printint+0x8a>
 910:	fc26                	sd	s1,56(sp)
 912:	f44e                	sd	s3,40(sp)
 914:	fb840713          	addi	a4,s0,-72
 918:	00f704b3          	add	s1,a4,a5
 91c:	fff70993          	addi	s3,a4,-1
 920:	99be                	add	s3,s3,a5
 922:	37fd                	addiw	a5,a5,-1
 924:	1782                	slli	a5,a5,0x20
 926:	9381                	srli	a5,a5,0x20
 928:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 92c:	fff4c583          	lbu	a1,-1(s1)
 930:	854a                	mv	a0,s2
 932:	f67ff0ef          	jal	898 <putc>
  while(--i >= 0)
 936:	14fd                	addi	s1,s1,-1
 938:	ff349ae3          	bne	s1,s3,92c <printint+0x76>
 93c:	74e2                	ld	s1,56(sp)
 93e:	79a2                	ld	s3,40(sp)
}
 940:	60a6                	ld	ra,72(sp)
 942:	6406                	ld	s0,64(sp)
 944:	7942                	ld	s2,48(sp)
 946:	6161                	addi	sp,sp,80
 948:	8082                	ret
    x = -xx;
 94a:	40b005b3          	neg	a1,a1
    neg = 1;
 94e:	4885                	li	a7,1
    x = -xx;
 950:	bfad                	j	8ca <printint+0x14>

0000000000000952 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 952:	711d                	addi	sp,sp,-96
 954:	ec86                	sd	ra,88(sp)
 956:	e8a2                	sd	s0,80(sp)
 958:	e0ca                	sd	s2,64(sp)
 95a:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 95c:	0005c903          	lbu	s2,0(a1)
 960:	28090663          	beqz	s2,bec <vprintf+0x29a>
 964:	e4a6                	sd	s1,72(sp)
 966:	fc4e                	sd	s3,56(sp)
 968:	f852                	sd	s4,48(sp)
 96a:	f456                	sd	s5,40(sp)
 96c:	f05a                	sd	s6,32(sp)
 96e:	ec5e                	sd	s7,24(sp)
 970:	e862                	sd	s8,16(sp)
 972:	e466                	sd	s9,8(sp)
 974:	8b2a                	mv	s6,a0
 976:	8a2e                	mv	s4,a1
 978:	8bb2                	mv	s7,a2
  state = 0;
 97a:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 97c:	4481                	li	s1,0
 97e:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 980:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 984:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 988:	06c00c93          	li	s9,108
 98c:	a005                	j	9ac <vprintf+0x5a>
        putc(fd, c0);
 98e:	85ca                	mv	a1,s2
 990:	855a                	mv	a0,s6
 992:	f07ff0ef          	jal	898 <putc>
 996:	a019                	j	99c <vprintf+0x4a>
    } else if(state == '%'){
 998:	03598263          	beq	s3,s5,9bc <vprintf+0x6a>
  for(i = 0; fmt[i]; i++){
 99c:	2485                	addiw	s1,s1,1
 99e:	8726                	mv	a4,s1
 9a0:	009a07b3          	add	a5,s4,s1
 9a4:	0007c903          	lbu	s2,0(a5)
 9a8:	22090a63          	beqz	s2,bdc <vprintf+0x28a>
    c0 = fmt[i] & 0xff;
 9ac:	0009079b          	sext.w	a5,s2
    if(state == 0){
 9b0:	fe0994e3          	bnez	s3,998 <vprintf+0x46>
      if(c0 == '%'){
 9b4:	fd579de3          	bne	a5,s5,98e <vprintf+0x3c>
        state = '%';
 9b8:	89be                	mv	s3,a5
 9ba:	b7cd                	j	99c <vprintf+0x4a>
      if(c0) c1 = fmt[i+1] & 0xff;
 9bc:	00ea06b3          	add	a3,s4,a4
 9c0:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 9c4:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 9c6:	c681                	beqz	a3,9ce <vprintf+0x7c>
 9c8:	9752                	add	a4,a4,s4
 9ca:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 9ce:	05878363          	beq	a5,s8,a14 <vprintf+0xc2>
      } else if(c0 == 'l' && c1 == 'd'){
 9d2:	05978d63          	beq	a5,s9,a2c <vprintf+0xda>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 9d6:	07500713          	li	a4,117
 9da:	0ee78763          	beq	a5,a4,ac8 <vprintf+0x176>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 9de:	07800713          	li	a4,120
 9e2:	12e78963          	beq	a5,a4,b14 <vprintf+0x1c2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 9e6:	07000713          	li	a4,112
 9ea:	14e78e63          	beq	a5,a4,b46 <vprintf+0x1f4>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 9ee:	06300713          	li	a4,99
 9f2:	18e78e63          	beq	a5,a4,b8e <vprintf+0x23c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 9f6:	07300713          	li	a4,115
 9fa:	1ae78463          	beq	a5,a4,ba2 <vprintf+0x250>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 9fe:	02500713          	li	a4,37
 a02:	04e79563          	bne	a5,a4,a4c <vprintf+0xfa>
        putc(fd, '%');
 a06:	02500593          	li	a1,37
 a0a:	855a                	mv	a0,s6
 a0c:	e8dff0ef          	jal	898 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 a10:	4981                	li	s3,0
 a12:	b769                	j	99c <vprintf+0x4a>
        printint(fd, va_arg(ap, int), 10, 1);
 a14:	008b8913          	addi	s2,s7,8
 a18:	4685                	li	a3,1
 a1a:	4629                	li	a2,10
 a1c:	000ba583          	lw	a1,0(s7)
 a20:	855a                	mv	a0,s6
 a22:	e95ff0ef          	jal	8b6 <printint>
 a26:	8bca                	mv	s7,s2
      state = 0;
 a28:	4981                	li	s3,0
 a2a:	bf8d                	j	99c <vprintf+0x4a>
      } else if(c0 == 'l' && c1 == 'd'){
 a2c:	06400793          	li	a5,100
 a30:	02f68963          	beq	a3,a5,a62 <vprintf+0x110>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 a34:	06c00793          	li	a5,108
 a38:	04f68263          	beq	a3,a5,a7c <vprintf+0x12a>
      } else if(c0 == 'l' && c1 == 'u'){
 a3c:	07500793          	li	a5,117
 a40:	0af68063          	beq	a3,a5,ae0 <vprintf+0x18e>
      } else if(c0 == 'l' && c1 == 'x'){
 a44:	07800793          	li	a5,120
 a48:	0ef68263          	beq	a3,a5,b2c <vprintf+0x1da>
        putc(fd, '%');
 a4c:	02500593          	li	a1,37
 a50:	855a                	mv	a0,s6
 a52:	e47ff0ef          	jal	898 <putc>
        putc(fd, c0);
 a56:	85ca                	mv	a1,s2
 a58:	855a                	mv	a0,s6
 a5a:	e3fff0ef          	jal	898 <putc>
      state = 0;
 a5e:	4981                	li	s3,0
 a60:	bf35                	j	99c <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 a62:	008b8913          	addi	s2,s7,8
 a66:	4685                	li	a3,1
 a68:	4629                	li	a2,10
 a6a:	000bb583          	ld	a1,0(s7)
 a6e:	855a                	mv	a0,s6
 a70:	e47ff0ef          	jal	8b6 <printint>
        i += 1;
 a74:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 a76:	8bca                	mv	s7,s2
      state = 0;
 a78:	4981                	li	s3,0
        i += 1;
 a7a:	b70d                	j	99c <vprintf+0x4a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 a7c:	06400793          	li	a5,100
 a80:	02f60763          	beq	a2,a5,aae <vprintf+0x15c>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 a84:	07500793          	li	a5,117
 a88:	06f60963          	beq	a2,a5,afa <vprintf+0x1a8>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 a8c:	07800793          	li	a5,120
 a90:	faf61ee3          	bne	a2,a5,a4c <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 a94:	008b8913          	addi	s2,s7,8
 a98:	4681                	li	a3,0
 a9a:	4641                	li	a2,16
 a9c:	000bb583          	ld	a1,0(s7)
 aa0:	855a                	mv	a0,s6
 aa2:	e15ff0ef          	jal	8b6 <printint>
        i += 2;
 aa6:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 aa8:	8bca                	mv	s7,s2
      state = 0;
 aaa:	4981                	li	s3,0
        i += 2;
 aac:	bdc5                	j	99c <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 aae:	008b8913          	addi	s2,s7,8
 ab2:	4685                	li	a3,1
 ab4:	4629                	li	a2,10
 ab6:	000bb583          	ld	a1,0(s7)
 aba:	855a                	mv	a0,s6
 abc:	dfbff0ef          	jal	8b6 <printint>
        i += 2;
 ac0:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 ac2:	8bca                	mv	s7,s2
      state = 0;
 ac4:	4981                	li	s3,0
        i += 2;
 ac6:	bdd9                	j	99c <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 ac8:	008b8913          	addi	s2,s7,8
 acc:	4681                	li	a3,0
 ace:	4629                	li	a2,10
 ad0:	000be583          	lwu	a1,0(s7)
 ad4:	855a                	mv	a0,s6
 ad6:	de1ff0ef          	jal	8b6 <printint>
 ada:	8bca                	mv	s7,s2
      state = 0;
 adc:	4981                	li	s3,0
 ade:	bd7d                	j	99c <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 ae0:	008b8913          	addi	s2,s7,8
 ae4:	4681                	li	a3,0
 ae6:	4629                	li	a2,10
 ae8:	000bb583          	ld	a1,0(s7)
 aec:	855a                	mv	a0,s6
 aee:	dc9ff0ef          	jal	8b6 <printint>
        i += 1;
 af2:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 af4:	8bca                	mv	s7,s2
      state = 0;
 af6:	4981                	li	s3,0
        i += 1;
 af8:	b555                	j	99c <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 afa:	008b8913          	addi	s2,s7,8
 afe:	4681                	li	a3,0
 b00:	4629                	li	a2,10
 b02:	000bb583          	ld	a1,0(s7)
 b06:	855a                	mv	a0,s6
 b08:	dafff0ef          	jal	8b6 <printint>
        i += 2;
 b0c:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 b0e:	8bca                	mv	s7,s2
      state = 0;
 b10:	4981                	li	s3,0
        i += 2;
 b12:	b569                	j	99c <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 b14:	008b8913          	addi	s2,s7,8
 b18:	4681                	li	a3,0
 b1a:	4641                	li	a2,16
 b1c:	000be583          	lwu	a1,0(s7)
 b20:	855a                	mv	a0,s6
 b22:	d95ff0ef          	jal	8b6 <printint>
 b26:	8bca                	mv	s7,s2
      state = 0;
 b28:	4981                	li	s3,0
 b2a:	bd8d                	j	99c <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 b2c:	008b8913          	addi	s2,s7,8
 b30:	4681                	li	a3,0
 b32:	4641                	li	a2,16
 b34:	000bb583          	ld	a1,0(s7)
 b38:	855a                	mv	a0,s6
 b3a:	d7dff0ef          	jal	8b6 <printint>
        i += 1;
 b3e:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 b40:	8bca                	mv	s7,s2
      state = 0;
 b42:	4981                	li	s3,0
        i += 1;
 b44:	bda1                	j	99c <vprintf+0x4a>
 b46:	e06a                	sd	s10,0(sp)
        printptr(fd, va_arg(ap, uint64));
 b48:	008b8d13          	addi	s10,s7,8
 b4c:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 b50:	03000593          	li	a1,48
 b54:	855a                	mv	a0,s6
 b56:	d43ff0ef          	jal	898 <putc>
  putc(fd, 'x');
 b5a:	07800593          	li	a1,120
 b5e:	855a                	mv	a0,s6
 b60:	d39ff0ef          	jal	898 <putc>
 b64:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b66:	00001b97          	auipc	s7,0x1
 b6a:	a72b8b93          	addi	s7,s7,-1422 # 15d8 <digits>
 b6e:	03c9d793          	srli	a5,s3,0x3c
 b72:	97de                	add	a5,a5,s7
 b74:	0007c583          	lbu	a1,0(a5)
 b78:	855a                	mv	a0,s6
 b7a:	d1fff0ef          	jal	898 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 b7e:	0992                	slli	s3,s3,0x4
 b80:	397d                	addiw	s2,s2,-1
 b82:	fe0916e3          	bnez	s2,b6e <vprintf+0x21c>
        printptr(fd, va_arg(ap, uint64));
 b86:	8bea                	mv	s7,s10
      state = 0;
 b88:	4981                	li	s3,0
 b8a:	6d02                	ld	s10,0(sp)
 b8c:	bd01                	j	99c <vprintf+0x4a>
        putc(fd, va_arg(ap, uint32));
 b8e:	008b8913          	addi	s2,s7,8
 b92:	000bc583          	lbu	a1,0(s7)
 b96:	855a                	mv	a0,s6
 b98:	d01ff0ef          	jal	898 <putc>
 b9c:	8bca                	mv	s7,s2
      state = 0;
 b9e:	4981                	li	s3,0
 ba0:	bbf5                	j	99c <vprintf+0x4a>
        if((s = va_arg(ap, char*)) == 0)
 ba2:	008b8993          	addi	s3,s7,8
 ba6:	000bb903          	ld	s2,0(s7)
 baa:	00090f63          	beqz	s2,bc8 <vprintf+0x276>
        for(; *s; s++)
 bae:	00094583          	lbu	a1,0(s2)
 bb2:	c195                	beqz	a1,bd6 <vprintf+0x284>
          putc(fd, *s);
 bb4:	855a                	mv	a0,s6
 bb6:	ce3ff0ef          	jal	898 <putc>
        for(; *s; s++)
 bba:	0905                	addi	s2,s2,1
 bbc:	00094583          	lbu	a1,0(s2)
 bc0:	f9f5                	bnez	a1,bb4 <vprintf+0x262>
        if((s = va_arg(ap, char*)) == 0)
 bc2:	8bce                	mv	s7,s3
      state = 0;
 bc4:	4981                	li	s3,0
 bc6:	bbd9                	j	99c <vprintf+0x4a>
          s = "(null)";
 bc8:	00001917          	auipc	s2,0x1
 bcc:	a0890913          	addi	s2,s2,-1528 # 15d0 <malloc+0x8fc>
        for(; *s; s++)
 bd0:	02800593          	li	a1,40
 bd4:	b7c5                	j	bb4 <vprintf+0x262>
        if((s = va_arg(ap, char*)) == 0)
 bd6:	8bce                	mv	s7,s3
      state = 0;
 bd8:	4981                	li	s3,0
 bda:	b3c9                	j	99c <vprintf+0x4a>
 bdc:	64a6                	ld	s1,72(sp)
 bde:	79e2                	ld	s3,56(sp)
 be0:	7a42                	ld	s4,48(sp)
 be2:	7aa2                	ld	s5,40(sp)
 be4:	7b02                	ld	s6,32(sp)
 be6:	6be2                	ld	s7,24(sp)
 be8:	6c42                	ld	s8,16(sp)
 bea:	6ca2                	ld	s9,8(sp)
    }
  }
}
 bec:	60e6                	ld	ra,88(sp)
 bee:	6446                	ld	s0,80(sp)
 bf0:	6906                	ld	s2,64(sp)
 bf2:	6125                	addi	sp,sp,96
 bf4:	8082                	ret

0000000000000bf6 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 bf6:	715d                	addi	sp,sp,-80
 bf8:	ec06                	sd	ra,24(sp)
 bfa:	e822                	sd	s0,16(sp)
 bfc:	1000                	addi	s0,sp,32
 bfe:	e010                	sd	a2,0(s0)
 c00:	e414                	sd	a3,8(s0)
 c02:	e818                	sd	a4,16(s0)
 c04:	ec1c                	sd	a5,24(s0)
 c06:	03043023          	sd	a6,32(s0)
 c0a:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 c0e:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 c12:	8622                	mv	a2,s0
 c14:	d3fff0ef          	jal	952 <vprintf>
}
 c18:	60e2                	ld	ra,24(sp)
 c1a:	6442                	ld	s0,16(sp)
 c1c:	6161                	addi	sp,sp,80
 c1e:	8082                	ret

0000000000000c20 <printf>:

void
printf(const char *fmt, ...)
{
 c20:	711d                	addi	sp,sp,-96
 c22:	ec06                	sd	ra,24(sp)
 c24:	e822                	sd	s0,16(sp)
 c26:	1000                	addi	s0,sp,32
 c28:	e40c                	sd	a1,8(s0)
 c2a:	e810                	sd	a2,16(s0)
 c2c:	ec14                	sd	a3,24(s0)
 c2e:	f018                	sd	a4,32(s0)
 c30:	f41c                	sd	a5,40(s0)
 c32:	03043823          	sd	a6,48(s0)
 c36:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 c3a:	00840613          	addi	a2,s0,8
 c3e:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 c42:	85aa                	mv	a1,a0
 c44:	4505                	li	a0,1
 c46:	d0dff0ef          	jal	952 <vprintf>
}
 c4a:	60e2                	ld	ra,24(sp)
 c4c:	6442                	ld	s0,16(sp)
 c4e:	6125                	addi	sp,sp,96
 c50:	8082                	ret

0000000000000c52 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 c52:	1141                	addi	sp,sp,-16
 c54:	e422                	sd	s0,8(sp)
 c56:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 c58:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 c5c:	00001797          	auipc	a5,0x1
 c60:	3ac7b783          	ld	a5,940(a5) # 2008 <freep>
 c64:	a02d                	j	c8e <free+0x3c>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 c66:	4618                	lw	a4,8(a2)
 c68:	9f2d                	addw	a4,a4,a1
 c6a:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 c6e:	6398                	ld	a4,0(a5)
 c70:	6310                	ld	a2,0(a4)
 c72:	a83d                	j	cb0 <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 c74:	ff852703          	lw	a4,-8(a0)
 c78:	9f31                	addw	a4,a4,a2
 c7a:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 c7c:	ff053683          	ld	a3,-16(a0)
 c80:	a091                	j	cc4 <free+0x72>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 c82:	6398                	ld	a4,0(a5)
 c84:	00e7e463          	bltu	a5,a4,c8c <free+0x3a>
 c88:	00e6ea63          	bltu	a3,a4,c9c <free+0x4a>
{
 c8c:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 c8e:	fed7fae3          	bgeu	a5,a3,c82 <free+0x30>
 c92:	6398                	ld	a4,0(a5)
 c94:	00e6e463          	bltu	a3,a4,c9c <free+0x4a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 c98:	fee7eae3          	bltu	a5,a4,c8c <free+0x3a>
  if(bp + bp->s.size == p->s.ptr){
 c9c:	ff852583          	lw	a1,-8(a0)
 ca0:	6390                	ld	a2,0(a5)
 ca2:	02059813          	slli	a6,a1,0x20
 ca6:	01c85713          	srli	a4,a6,0x1c
 caa:	9736                	add	a4,a4,a3
 cac:	fae60de3          	beq	a2,a4,c66 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 cb0:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 cb4:	4790                	lw	a2,8(a5)
 cb6:	02061593          	slli	a1,a2,0x20
 cba:	01c5d713          	srli	a4,a1,0x1c
 cbe:	973e                	add	a4,a4,a5
 cc0:	fae68ae3          	beq	a3,a4,c74 <free+0x22>
    p->s.ptr = bp->s.ptr;
 cc4:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 cc6:	00001717          	auipc	a4,0x1
 cca:	34f73123          	sd	a5,834(a4) # 2008 <freep>
}
 cce:	6422                	ld	s0,8(sp)
 cd0:	0141                	addi	sp,sp,16
 cd2:	8082                	ret

0000000000000cd4 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 cd4:	7139                	addi	sp,sp,-64
 cd6:	fc06                	sd	ra,56(sp)
 cd8:	f822                	sd	s0,48(sp)
 cda:	f426                	sd	s1,40(sp)
 cdc:	ec4e                	sd	s3,24(sp)
 cde:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 ce0:	02051493          	slli	s1,a0,0x20
 ce4:	9081                	srli	s1,s1,0x20
 ce6:	04bd                	addi	s1,s1,15
 ce8:	8091                	srli	s1,s1,0x4
 cea:	0014899b          	addiw	s3,s1,1
 cee:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 cf0:	00001517          	auipc	a0,0x1
 cf4:	31853503          	ld	a0,792(a0) # 2008 <freep>
 cf8:	c915                	beqz	a0,d2c <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 cfa:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 cfc:	4798                	lw	a4,8(a5)
 cfe:	08977a63          	bgeu	a4,s1,d92 <malloc+0xbe>
 d02:	f04a                	sd	s2,32(sp)
 d04:	e852                	sd	s4,16(sp)
 d06:	e456                	sd	s5,8(sp)
 d08:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 d0a:	8a4e                	mv	s4,s3
 d0c:	0009871b          	sext.w	a4,s3
 d10:	6685                	lui	a3,0x1
 d12:	00d77363          	bgeu	a4,a3,d18 <malloc+0x44>
 d16:	6a05                	lui	s4,0x1
 d18:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 d1c:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 d20:	00001917          	auipc	s2,0x1
 d24:	2e890913          	addi	s2,s2,744 # 2008 <freep>
  if(p == SBRK_ERROR)
 d28:	5afd                	li	s5,-1
 d2a:	a081                	j	d6a <malloc+0x96>
 d2c:	f04a                	sd	s2,32(sp)
 d2e:	e852                	sd	s4,16(sp)
 d30:	e456                	sd	s5,8(sp)
 d32:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 d34:	00001797          	auipc	a5,0x1
 d38:	2dc78793          	addi	a5,a5,732 # 2010 <base>
 d3c:	00001717          	auipc	a4,0x1
 d40:	2cf73623          	sd	a5,716(a4) # 2008 <freep>
 d44:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 d46:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 d4a:	b7c1                	j	d0a <malloc+0x36>
        prevp->s.ptr = p->s.ptr;
 d4c:	6398                	ld	a4,0(a5)
 d4e:	e118                	sd	a4,0(a0)
 d50:	a8a9                	j	daa <malloc+0xd6>
  hp->s.size = nu;
 d52:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 d56:	0541                	addi	a0,a0,16
 d58:	efbff0ef          	jal	c52 <free>
  return freep;
 d5c:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 d60:	c12d                	beqz	a0,dc2 <malloc+0xee>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 d62:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 d64:	4798                	lw	a4,8(a5)
 d66:	02977263          	bgeu	a4,s1,d8a <malloc+0xb6>
    if(p == freep)
 d6a:	00093703          	ld	a4,0(s2)
 d6e:	853e                	mv	a0,a5
 d70:	fef719e3          	bne	a4,a5,d62 <malloc+0x8e>
  p = sbrk(nu * sizeof(Header));
 d74:	8552                	mv	a0,s4
 d76:	a27ff0ef          	jal	79c <sbrk>
  if(p == SBRK_ERROR)
 d7a:	fd551ce3          	bne	a0,s5,d52 <malloc+0x7e>
        return 0;
 d7e:	4501                	li	a0,0
 d80:	7902                	ld	s2,32(sp)
 d82:	6a42                	ld	s4,16(sp)
 d84:	6aa2                	ld	s5,8(sp)
 d86:	6b02                	ld	s6,0(sp)
 d88:	a03d                	j	db6 <malloc+0xe2>
 d8a:	7902                	ld	s2,32(sp)
 d8c:	6a42                	ld	s4,16(sp)
 d8e:	6aa2                	ld	s5,8(sp)
 d90:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 d92:	fae48de3          	beq	s1,a4,d4c <malloc+0x78>
        p->s.size -= nunits;
 d96:	4137073b          	subw	a4,a4,s3
 d9a:	c798                	sw	a4,8(a5)
        p += p->s.size;
 d9c:	02071693          	slli	a3,a4,0x20
 da0:	01c6d713          	srli	a4,a3,0x1c
 da4:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 da6:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 daa:	00001717          	auipc	a4,0x1
 dae:	24a73f23          	sd	a0,606(a4) # 2008 <freep>
      return (void*)(p + 1);
 db2:	01078513          	addi	a0,a5,16
  }
}
 db6:	70e2                	ld	ra,56(sp)
 db8:	7442                	ld	s0,48(sp)
 dba:	74a2                	ld	s1,40(sp)
 dbc:	69e2                	ld	s3,24(sp)
 dbe:	6121                	addi	sp,sp,64
 dc0:	8082                	ret
 dc2:	7902                	ld	s2,32(sp)
 dc4:	6a42                	ld	s4,16(sp)
 dc6:	6aa2                	ld	s5,8(sp)
 dc8:	6b02                	ld	s6,0(sp)
 dca:	b7f5                	j	db6 <malloc+0xe2>
